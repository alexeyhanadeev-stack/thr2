[Library Effect]
Lifetime=5
Version=2.00
Display Name=Orbx_ObstructionLight_White_Flash_4s
Radius=10000
Priority=0

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
LOD=0
Light=0
No Interpolate=0
Rate=0.25, 0.25
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=0.10, 0.10
Type=19
X Scale=6.00, 6.00
Y Scale=6.00, 6.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=0
Static=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_2_orbx_obs_hs.bmp
Bounce=0.00
Color Start=255, 255, 255, 160
Color End=255, 255, 255, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
LOD=0
Light=0
No Interpolate=0
Rate=0.25, 0.25
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=0.10, 0.10
Type=19
X Scale=5.00, 5.00
Y Scale=5.00, 5.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=0
Static=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_2_orbx_obs_hs.bmp
Bounce=0.00
Color Start=255, 255, 255, 190
Color End=255, 255, 255, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
LOD=0
Light=0
No Interpolate=0
Rate=0.25, 0.25
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.10, 0.10
Type=19
X Scale=4.00, 4.00
Y Scale=4.00, 4.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=0
Static=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2_orbx_obs_hs.bmp
Bounce=0.00
Color Start=255, 255, 255, 220
Color End=255, 255, 255, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
LOD=0
Light=0
No Interpolate=0
Rate=0.25, 0.25
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=0.10, 0.10
Type=19
X Scale=3.00, 3.00
Y Scale=3.00, 3.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=0
Static=1
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_2_orbx_obs_hs.bmp
Bounce=0.00
Color Start=255, 255, 255, 250
Color End=255, 255, 255, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00



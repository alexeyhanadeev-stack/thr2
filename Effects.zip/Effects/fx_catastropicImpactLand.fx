[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Exp_OilRig03.wav
MinAttenuationDistance=700.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.15, 0.20
Delay=0.00, 0.00
Bounce=0.00
Rate=400.00, 500.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-30.00, 30.00
Y Particle Velocity=30.00, 50.00
Z Particle Velocity=-30.00, 30.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=2.00, 3.00
Type=19
X Scale=1.00, 1.00
Y Scale=1.00, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.50
Y Scale Rate=0.50, 0.50
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.00, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-1000.00, 1000.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 200, 150, 255
Color End=100, 50, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=90.00
TempRate=-0.01
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.10, 0.10
Delay=0.10, 0.10
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=0.50, 0.50
Type=19
X Scale=20.00, 20.00
Y Scale=20.00, 20.00
Z Scale=0.00, 0.00
X Scale Rate=10.00, 10.00
Y Scale Rate=10.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.20, 0.50
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Ground Normal=1
Shade=1
Face=0, 0, 0

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=40, 40, 40, 255
Color End=10, 10, 10, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.50, 0.50
uv2=1.00, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.50, 0.50
Type=19
X Scale=40.00, 40.00
Y Scale=40.00, 40.00
Z Scale=0.00, 0.00
X Scale Rate=10.00, 10.00
Y Scale Rate=10.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.42, 0.60
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=200, 200, 200, 255
Color End=100, 100, 100, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=75.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-30.00, 30.00
Y Particle Velocity=20.00, 30.00
Z Particle Velocity=-30.00, 30.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=1.50, 2.00
Type=19
X Scale=5.00, 10.00
Y Scale=5.00, 10.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.20
Y Scale Rate=0.10, 0.20
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-10.00, 10.00
Y Offset=5.00, 5.00
Z Offset=-10.00, 10.00
Fade In=0.10, 0.20
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=78, 78, 78, 50
Color End=68, 68, 68, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=100.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-30.00, 30.00
Y Particle Velocity=20.00, 30.00
Z Particle Velocity=-30.00, 30.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=1.00, 2.00
Type=19
X Scale=4.00, 8.00
Y Scale=4.00, 8.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.20
Y Scale Rate=0.10, 0.20
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-10.00, 10.00
Y Offset=5.00, 5.00
Z Offset=-10.00, 10.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-100.00, 100.00
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=100, 50, 20, 100
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=6.00, 8.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=2.00, 4.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=4.00, 8.00
Type=19
X Scale=6.25, 10.50
Y Scale=6.25, 10.50
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.20, 0.40
X Offset=-7.50, 7.50
Y Offset=2.50, 5.00
Z Offset=-7.50, 7.50
Fade In=0.10, 0.60
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 200
Color End=20, 20, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=130.00
TempRate=-0.10
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=4.00, 6.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=16.00, 20.00
Type=19
X Scale=7.50, 15.00
Y Scale=7.50, 15.00
Z Scale=0.00, 0.00
X Scale Rate=0.03, 0.10
Y Scale Rate=0.03, 0.10
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 0.90
X Offset=-7.50, 7.50
Y Offset=10.00, 12.50
Z Offset=-7.50, 7.50
Fade In=0.70, 0.70
Fade Out=0.95, 0.95
Rotation=-20.00, 20.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.6]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=30, 30, 30, 170
Color End=43, 46, 49, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.50
Y Scale Goal=2.50
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.7]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=3.00, 6.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=2.00, 4.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=-10.00, 10.00
Y Offset=0.00, 0.00
Z Offset=-10.00, 10.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.7]
Lifetime=4.00, 6.00
Type=19
X Scale=6.25, 12.75
Y Scale=6.25, 12.75
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.25, 0.40
X Offset=-5.00, 5.00
Y Offset=2.50, 5.00
Z Offset=-5.00, 5.00
Fade In=0.10, 0.60
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.7]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 200
Color End=50, 50, 50, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=130.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.8]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=4.00, 6.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.8]
Lifetime=15.00, 18.00
Type=19
X Scale=6.25, 12.75
Y Scale=6.25, 12.75
Z Scale=0.00, 0.00
X Scale Rate=0.03, 0.10
Y Scale Rate=0.03, 0.10
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 0.90
X Offset=-5.00, 5.00
Y Offset=10.00, 12.50
Z Offset=-5.00, 5.00
Fade In=0.70, 0.70
Fade Out=0.95, 0.95
Rotation=-20.00, 20.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.8]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=50, 50, 50, 100
Color End=83, 90, 104, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.50
Y Scale Goal=2.50
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.9]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=8.00, 15.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.9]
Lifetime=2.00, 3.00
Type=19
X Scale=5.00, 7.50
Y Scale=2.50, 3.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=-3.75, 3.75
Y Offset=0.00, 0.00
Z Offset=-3.75, 3.75
Fade In=0.30, 0.30
Fade Out=0.80, 0.80
Rotation=0.00, 0.00
Face=0, 0, 1

[ParticleAttributes.9]
Blend Mode=1
Texture=fx_Firesheet01.bmp
Bounce=0.00
Color Start=255, 255, 255, 255
Color End=0, 0, 0, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.01
FPS=16.00
TextureSize=512
CellSize=128
CellStart=0
CellEnd=15
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.10]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=50.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.10]
Lifetime=2.00, 4.00
Type=19
X Scale=2.50, 5.75
Y Scale=2.50, 5.75
Z Scale=0.00, 0.00
X Scale Rate=0.01, 0.01
Y Scale Rate=0.01, 0.01
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.80, 1.00
X Offset=-7.50, 7.50
Y Offset=0.00, 0.00
Z Offset=-7.50, 7.50
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-100.00, 100.00
Face=1, 0, 1

[ParticleAttributes.10]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=50, 25, 10, 200
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=150.00
TempRate=-0.50
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=1.00
Y Scale Goal=1.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.11]
Lifetime=0.50, 1.00
Delay=0.30, 0.30
Bounce=0.00
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=2.00, 5.00
Z Particle Velocity=-5.00, 5.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.11]
Lifetime=8.00, 12.00
Type=19
X Scale=1.00, 3.00
Y Scale=1.00, 3.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.70
Y Scale Rate=0.50, 0.70
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.10
Fade Out=0.50, 0.60
Rotation=-30.00, 30.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.11]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=130, 111, 85, 100
Color End=94, 89, 62, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=105.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=7.00
Y Scale Goal=7.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.12]
Lifetime=0.15, 0.20
Delay=0.00, 0.00
Bounce=0.00
Rate=400.00, 500.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-20.00, 20.00
Y Particle Velocity=20.00, 60.00
Z Particle Velocity=-20.00, 20.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.12]
Lifetime=1.50, 2.00
Type=19
X Scale=0.05, 0.20
Y Scale=0.05, 0.20
Z Scale=0.00, 0.00
X Scale Rate=1.00, 1.00
Y Scale Rate=1.00, 1.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-1000.00, 1000.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.12]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=62, 46, 32, 255
Color End=52, 44, 31, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=70.00
TempRate=-0.01
uv1=0.75, 0.75
uv2=1.00, 1.00
X Scale Goal=4.00
Y Scale Goal=4.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.13]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.13]
Lifetime=0.15, 0.15
Type=19
X Scale=40.00, 60.00
Y Scale=40.00, 60.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.42, 0.60
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.13]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=64, 64, 64, 255
Color End=44, 44, 44, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.14]
Lifetime=0.50, 1.00
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=2.00, 5.00
Z Particle Velocity=-5.00, 5.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.14]
Lifetime=8.00, 12.00
Type=19
X Scale=1.00, 4.00
Y Scale=1.00, 4.00
Z Scale=0.00, 0.00
X Scale Rate=0.25, 0.35
Y Scale Rate=0.25, 0.35
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.10
Fade Out=0.50, 0.60
Rotation=-30.00, 30.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.14]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=91, 78, 60, 100
Color End=56, 53, 37, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=105.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=7.00
Y Scale Goal=7.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.15]
Lifetime=0.50, 0.60
Delay=0.00, 0.00
Bounce=0.00
Rate=50.00, 70.00
X Emitter Velocity=-1.00, 1.00
Y Emitter Velocity=3.50, 4.00
Z Emitter Velocity=-1.00, 1.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=10.00, 20.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.15]
Lifetime=2.00, 3.00
Type=19
X Scale=2.00, 4.00
Y Scale=2.00, 4.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.10
Fade Out=0.50, 0.60
Rotation=-30.00, 30.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.15]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=91, 78, 60, 100
Color End=56, 53, 37, 255
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=7.00
Y Scale Goal=7.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.16]
Lifetime=0.50, 0.60
Delay=0.00, 0.00
Bounce=0.00
Rate=30.00, 40.00
X Emitter Velocity=-1.00, 1.00
Y Emitter Velocity=3.50, 4.00
Z Emitter Velocity=-1.00, 1.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=5.00, 10.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.16]
Lifetime=2.00, 3.00
Type=19
X Scale=1.50, 3.40
Y Scale=1.50, 3.40
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.10
Fade Out=0.50, 0.60
Rotation=-30.00, 30.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.16]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=140, 120, 94, 100
Color End=119, 113, 79, 255
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=7.00
Y Scale Goal=7.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.17]
Lifetime=0.15, 0.30
Delay=0.00, 0.00
Bounce=0.00
Rate=50.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-20.00, 20.00
Y Particle Velocity=20.00, 60.00
Z Particle Velocity=-20.00, 20.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.17]
Lifetime=1.50, 2.00
Type=19
X Scale=0.10, 1.00
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-1000.00, 1000.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.17]
Blend Mode=1
Texture=fx_3.bmp
Bounce=0.75
Color Start=154, 154, 154, 255
Color End=154, 154, 154, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=70.00
TempRate=0.00
uv1=0.25, 0.75
uv2=0.38, 0.88
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.18]
Lifetime=0.15, 0.20
Delay=0.00, 0.00
Bounce=0.00
Rate=50.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-20.00, 20.00
Y Particle Velocity=20.00, 40.00
Z Particle Velocity=-20.00, 20.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.18]
Lifetime=1.50, 2.00
Type=19
X Scale=0.10, 0.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-1000.00, 1000.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.18]
Blend Mode=1
Texture=fx_3.bmp
Bounce=0.75
Color Start=126, 126, 126, 255
Color End=127, 127, 127, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=70.00
TempRate=0.00
uv1=0.38, 0.88
uv2=0.50, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


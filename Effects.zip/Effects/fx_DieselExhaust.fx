[Library Effect]
Lifetime=5
Version=2.00
Display Name=Smoke Stack
Radius=200
Priority=0

[Properties]
StopTemp=10.00

[Emitter.0]
Lifetime=600.00, 900.00
Delay=0.00, 0.00
Bounce=0.00
Rate=10.00, 20.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=9.00, 17.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=3.00, 6.00
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.20
Y Scale Rate=0.20, 0.20
Z Scale Rate=0.00, 0.00
Drag=-1.50, -1.50
Color Rate=0.50, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.80, 0.80
Rotation=-20.00, 20.00
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=40, 40, 40, 8
Color End=50, 50, 50, 255
Jitter Distance=0.03
Jitter Time=0.30
TempK=107.50
TempRate=0.11
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=300.00
Y Scale Goal=300.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


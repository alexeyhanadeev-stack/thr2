[Library Effect]
Lifetime=5
Version=2.00
Display Name=Muzzle Cannon
Radius=100
Priority=0
[Sound]
FileName=Exp_Gen01.wav
MinAttenuationDistance=200.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.10, 0.12
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=2.50, 3.00
Y Particle Velocity=-1.00, 1.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=0.50, 0.55
Type=19
X Scale=2.00, 2.50
Y Scale=2.00, 2.50
Z Scale=0.00, 0.00
X Scale Rate=30.00, 31.50
Y Scale Rate=30.00, 31.50
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.06
Fade Out=0.40, 0.45
Rotation=-50.00, 50.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=160, 155, 155, 75
Color End=95, 90, 90, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.75
Y Scale Goal=2.75
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.30, 0.35
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 25.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=2.00, 2.20
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=3.50, 4.00
Type=19
X Scale=2.00, 3.00
Y Scale=2.00, 3.00
Z Scale=0.00, 0.00
X Scale Rate=20.00, 42.50
Y Scale Rate=20.00, 42.50
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.95, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.12
Fade Out=0.50, 0.55
Rotation=-20.00, 20.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=130, 125, 125, 50
Color End=115, 110, 110, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.25
Y Scale Goal=2.25
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.50, 0.50
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-1.00, -0.98
X Particle Velocity=-3.00, 3.00
Y Particle Velocity=1.00, 10.00
Z Particle Velocity=-3.00, 3.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.30, 0.35
Type=19
X Scale=4.00, 4.20
Y Scale=4.00, 4.20
Z Scale=0.00, 0.00
X Scale Rate=5.00, 6.00
Y Scale Rate=5.00, 6.00
Z Scale Rate=0.00, 0.00
Drag=-2.00, -1.95
Color Rate=0.50, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.20, 0.22
Fade Out=0.50, 0.52
Rotation=0.00, 0.00
Shade=1
Face=0, 0, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=1.00
Color Start=80, 70, 56, 25
Color End=105, 94, 69, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.50, 0.50
uv2=0.75, 0.75
X Scale Goal=1.00
Y Scale Goal=1.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.05, 0.05
Delay=0.00, 0.00
Bounce=0.00
Rate=100.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.50, 1.00
Z Emitter Velocity=0.00, 0.00
Drag=-1.00, -0.75
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=2.00, 2.00
Type=19
X Scale=1.50, 1.75
Y Scale=1.50, 1.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 100.00
Y Scale Rate=0.00, 100.00
Z Scale Rate=0.00, 0.00
Drag=-1.50, -1.50
Color Rate=0.20, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=3.00, 3.00
Fade In=0.00, 0.06
Fade Out=0.40, 0.45
Rotation=-50.00, 50.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=200, 200, 200, 50
Color End=150, 150, 150, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.02, 0.02
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=0.02, 0.02
Type=19
X Scale=1.00, 1.10
Y Scale=1.00, 1.10
Z Scale=0.00, 0.00
X Scale Rate=0.00, 100.00
Y Scale Rate=0.00, 100.00
Z Scale Rate=0.00, 0.00
Drag=1.00, 1.00
Color Rate=0.70, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-60.00, 60.00
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 255, 255, 25
Color End=50, 50, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=-0.01
uv1=0.75, 0.00
uv2=1.00, 0.25
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.02, 0.02
Delay=0.00, 0.00
Bounce=0.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=0.01, 0.01
Type=19
X Scale=0.75, 1.00
Y Scale=0.75, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 10.00
Y Scale Rate=0.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=1.00, 1.00
Color Rate=0.70, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-50.00, 50.00
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 255, 255, 25
Color End=50, 50, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.75, 0.00
uv2=1.00, 0.25
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6]
Lifetime=0.50, 0.50
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=0.15, 0.15
Type=27
X Scale=20.00, 20.00
Y Scale=0.00, 0.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Face=0, 0, 0

[ParticleAttributes.6]
Color Start=30, 22, 20, 140
Color End=30, 22, 20, 140
Bounce=0.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Falloff Exponent=2.00
Inner Cone Angle=20.00
Outer Cone Angle=30.00


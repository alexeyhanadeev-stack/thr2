// Ted Wolfgang 'Rampey' 5-2-16

[Library Effect]
Lifetime=5
Version=2.00

	
[Properties]
Virtualcockpit=1
Cockpit=1	
Spot=1
Tower=1
	
//-------------------- Cranky DC3 TFF ---------------------------


//-------------------------Smoke 1----------------------------------

[Emitter.0]
Lifetime=2.00, 2.00     
Delay=0.00, 0.00    
Bounce=0.00
Rate=20.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-0.00, 0.00
Y Particle Velocity= -0.80, -0.10
Z Particle Velocity=-2.00, -1.00
X Offset=  0.00, 0.00
Y Offset= -0.51, -0.51
Z Offset= -2.20, -2.20

[Particle.0]
Lifetime=0.1, 0.3
Type=19
X Scale=0.07, 0.20
Y Scale=0.07, 0.20
Z Scale=0.07, 0.20
X Scale Rate=2.90, 3.900
Y Scale Rate=2.90, 3.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.99, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=200, 200, 240, 30
Color End=200, 200, 240, 0   
Jitter Distance=0.0
Jitter Time=0.00
TempK=103.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=4.50
Y Scale Goal=4.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00 

//-------------------------Smoke 2----------------------------------

[Emitter.1]
Lifetime=2.50, 2.50     
Delay=0.01, 0.01    
Bounce=0.00
Rate=20.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-0.00, 0.00
Y Particle Velocity= -0.80, -0.10
Z Particle Velocity=-2.00, -1.00
X Offset=  0.00, 0.00
Y Offset= -0.52, -0.52
Z Offset= -2.20, -2.20

[Particle.1]
Lifetime=0.1, 0.3
Type=19
X Scale=0.07, 0.20
Y Scale=0.07, 0.20
Z Scale=0.07, 0.20
X Scale Rate=2.90, 3.900
Y Scale Rate=2.90, 3.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.99, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=180, 180, 240, 30
Color End=200, 200, 240, 0   
Jitter Distance=0.0
Jitter Time=0.00
TempK=103.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=4.50
Y Scale Goal=4.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00 

//-------------------------Smoke 3----------------------------------


[Emitter.2]
Lifetime=2.00, 2.00  
Delay=0.10, 0.10
Bounce=0.00
Rate=20.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.500, 1.500
Y Particle Velocity= -0.30, 0.60
Z Particle Velocity=-10.00,-4.00
X Offset=  0.00, 0.00
Y Offset= -0.60, -0.60
Z Offset= -1.90, -1.90

[Particle.2]
Lifetime=1.00, 2.00
Type=19
X Scale=0.15, 0.30
Y Scale=0.15, 0.30
Z Scale=0.15, 0.30
X Scale Rate=2.90, 4.900
Y Scale Rate=2.90, 4.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.99, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=200, 200, 240, 40
Color End=200, 200, 240, 0  
Jitter Distance=0.1
Jitter Time=0.010
TempK=105.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00

//-------------------------Smoke 4----------------------------------


[Emitter.3]
Lifetime=2.00, 2.00  
Delay=1.00, 1.00
Bounce=0.00
Rate=20.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.500, 1.500
Y Particle Velocity= -0.30, 0.60
Z Particle Velocity=-10.00,-5.00
X Offset=  0.00, 0.00
Y Offset= -0.52, -0.52
Z Offset= -2.00, -2.00

[Particle.3]
Lifetime=1.00, 3.00
Type=19
X Scale=0.10, 0.30
Y Scale=0.10, 0.30
Z Scale=0.10, 0.30
X Scale Rate=2.90, 4.900
Y Scale Rate=2.90, 4.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.99, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=200, 200, 240, 20
Color End=200, 200, 240, 0  
Jitter Distance=0.1
Jitter Time=0.010
TempK=105.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00

//-------------------------Smoke 5----------------------------------


[Emitter.4]
Lifetime=6.00, 6.00  
Delay=1.00, 1.00
Bounce=0.00
Rate=20.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.500, 1.500
Y Particle Velocity= -0.30, 0.60
Z Particle Velocity=-10.00,-5.00
X Offset=  0.00, 0.00
Y Offset= -0.52, -0.52
Z Offset= -2.40, -2.40

[Particle.4]
Lifetime=1.00, 5.00
Type=19
X Scale=0.10, 0.30
Y Scale=0.10, 0.30
Z Scale=0.10, 0.30
X Scale Rate=2.90, 4.900
Y Scale Rate=2.90, 4.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.99, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=200, 200, 240, 5
Color End=200, 200, 240, 0  
Jitter Distance=0.1
Jitter Time=0.010
TempK=105.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00

//-------------------------Smoke 6----------------------------------


[Emitter.5]
Lifetime=1.50, 1.50  
Delay=1.50, 1.50
Bounce=0.00
Rate=20.00, 40.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.500, 1.500
Y Particle Velocity= -0.30, 0.60
Z Particle Velocity=-10.00,-5.00
X Offset=  0.00, 0.00
Y Offset= -0.52, -0.52
Z Offset= -4.00, -4.00

[Particle.5]
Lifetime=3.00, 10.00
Type=19
X Scale=0.10, 2.30
Y Scale=0.10, 2.30
Z Scale=0.10, 2.30
X Scale Rate=2.90, 4.900
Y Scale Rate=2.90, 4.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.95, 0.99
Rotation=-180.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=200, 200, 240, 5
Color End=200, 200, 240, 0  
Jitter Distance=0.1
Jitter Time=0.010
TempK=105.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00

//-------------------------Smoke 7----------------------------------


[Emitter.6]
Lifetime=1.50, 1.50  
Delay=1.50, 1.50
Bounce=0.00
Rate=20.00, 40.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.500, 1.500
Y Particle Velocity= -0.30, 0.60
Z Particle Velocity=-10.00,-5.00
X Offset=  0.00, 0.00
Y Offset= -0.52, -0.52
Z Offset= -4.00, -4.00

[Particle.6]
Lifetime=3.00, 10.00
Type=19
X Scale=0.10, 2.30
Y Scale=0.10, 2.30
Z Scale=0.10, 2.30
X Scale Rate=2.90, 4.900
Y Scale Rate=2.90, 4.900
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.050, 0.100
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.30
Fade Out=0.95, 0.95
Rotation=-80.00, 80.00
Shade=1
Face=1,0,1
DX9OrigFace=1, 1, 1

[ParticleAttributes.6]
Texture=fx_1.bmp
Blend Mode=1
Bounce=0.50
Color Start=200, 200, 240, 5
Color End=200, 200, 240, 0  
Jitter Distance=0.1
Jitter Time=0.010
TempK=105.250
TempRate=0.0
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00 
Extrude Pitch Max=0.00 
Extrude Heading Max=0.00














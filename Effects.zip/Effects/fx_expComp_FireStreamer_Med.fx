[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Exp_OilRig01.wav
MinAttenuationDistance=600.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=60.00, 80.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=5.00, 7.00
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-1.00, 1.00
Y Offset=0.00, 10.00
Z Offset=-1.00, 1.00
Fade In=0.20, 0.30
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=50, 50, 50, 150
Color End=10, 10, 10, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=109.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=5.00, 7.00
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-1.00, 1.00
Y Offset=0.00, 10.00
Z Offset=-1.00, 1.00
Fade In=0.10, 0.20
Fade Out=0.70, 0.80
Rotation=-100.00, 100.00
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=140, 147, 157, 100
Color End=108, 108, 108, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=109.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=150.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=3.00, 5.00
Type=19
X Scale=0.50, 1.50
Y Scale=0.50, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.25
Y Scale Rate=0.20, 0.25
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-1.00, 1.00
Y Offset=0.00, 10.00
Z Offset=-1.00, 1.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-100.00, 100.00
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=100, 50, 20, 100
Color End=75, 35, 15, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=109.00
TempRate=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=30.00, 50.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=3.00, 5.00
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-1.00, 1.00
Y Offset=0.00, 10.00
Z Offset=-1.00, 1.00
Fade In=0.00, 0.00
Fade Out=0.70, 0.80
Rotation=-200.00, 200.00
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_5.bmp
Bounce=0.00
Color Start=0, 0, 0, 40
Color End=20, 20, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=109.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.20, 0.40
Delay=0.00, 0.00
Bounce=0.00
Rate=30.00, 50.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=3.00, 5.00
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 1.00
X Offset=-1.00, 1.00
Y Offset=0.00, 10.00
Z Offset=-1.00, 1.00
Fade In=0.00, 0.00
Fade Out=0.70, 0.80
Rotation=-200.00, 200.00
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=0, 0, 0, 50
Color End=20, 20, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=109.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.50, 0.50
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=1.70, 1.70
Type=27
X Scale=30.00, 30.00
Y Scale=0.00, 0.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Static=1
Face=0, 0, 0

[ParticleAttributes.5]
Color Start=255, 170, 80, 130
Color End=255, 170, 80, 130
Bounce=0.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Falloff Exponent=2.00
Inner Cone Angle=0.00
Outer Cone Angle=0.00
Intensity Day=450.00
Intensity Night=450.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=4.00, 5.00
Delay=0.00, 0.00
Bounce=0.00
Rate=60.00, 70.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-100.00, 100.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=500.00, 600.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=15.00, 20.00
Type=19
X Scale=20.00, 30.00
Y Scale=20.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=5.00, 10.00
Y Scale Rate=5.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-4.00, -2.00
Color Rate=0.33, 0.45
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.05
Fade Out=0.55, 0.57
Rotation=-60.00, 60.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=184, 190, 190, 100
Color End=170, 180, 185, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=4.00, 5.00
Delay=0.00, 0.00
Bounce=0.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-200.00, 200.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-200.00, 200.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=15.00, 20.00
Type=19
X Scale=20.00, 30.00
Y Scale=20.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=5.00, 10.00
Y Scale Rate=5.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-4.00, -2.00
Color Rate=0.33, 0.45
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.05
Fade Out=0.55, 0.57
Rotation=-60.00, 60.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=190, 195, 195, 75
Color End=172, 185, 190, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=125.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=4.00, 5.00
Delay=0.00, 0.00
Bounce=0.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-100.00, 100.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-100.00, 100.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=15.00, 20.00
Type=19
X Scale=20.00, 40.00
Y Scale=20.00, 40.00
Z Scale=0.00, 0.00
X Scale Rate=5.00, 10.00
Y Scale Rate=5.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-4.00, 0.00
Color Rate=0.33, 0.45
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=-1.00, 1.00
Fade In=0.05, 0.05
Fade Out=0.55, 0.57
Rotation=-60.00, 60.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=208, 213, 213, 75
Color End=228, 232, 233, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


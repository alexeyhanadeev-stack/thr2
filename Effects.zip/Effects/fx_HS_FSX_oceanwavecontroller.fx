[Library Effect]
Lifetime=5
Version=2.00
Radius=0
Priority=0

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[controller.0]
type=2
Frequency=30,50
x offset=0,0
y offset=0,0
z offset=13,15
lifetime=0,0
delay=2,6
effect.0=fx_HS_FSX_oceanwaves, 0,0,0, 0,0,0, 1,2



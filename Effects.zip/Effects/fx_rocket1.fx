[Library Effect]
Display Name=Effect
Lifetime=6
Version=2.00
Radius=-1
Priority=0
[Properties]
[Sound]
FileName=rocket.wav
MinAttenuationDistance=1200.00
Looping=FALSE



[Emitter.0]
Lifetime=2.50, 2.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=5.00, 5.01
X Particle Velocity=0.00, 0.00
Y Particle Velocity=1.00, 1.00
Z Particle Velocity=50.00, 50.01  
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00

[Particle.0]
Lifetime=5.00, 5.01
Type=19
X Scale=1.20, 1.30
Y Scale=1.20, 1.30
Z Scale=-2.00,-2.00
X Scale Rate=0.15, 0.16
Y Scale Rate=0.15, 0.16
Z Scale Rate=0.00, 0.00
Drag=5.00, 5.01
Color Rate=0.00, 0.05
Fade In=0.05, 0.05
Fade Out=0.20, 0.20
Rotation=-0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=rocket.bmp
Bounce=0.00
Color Start=226, 222, 165, 255
Color End=211, 192, 118, 0
Jitter Distance=0.000
Jitter Time=0.0
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=10.00
Extrude Pitch Max=15.00
Extrude Heading Max=15.00

[Emitter.1]
Lifetime=1.50, 1.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=5.00, 5.00
Z Particle Velocity=50.00, 50.01
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=1.10, 4.50
Type=18
X Scale=10.00, 30.00
Y Scale=10.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.10, 0.10
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.10
Fade Out=0.50, 0.52
Rotation=-20.00, 20.00
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_1.bmp
Bounce=0.00
Color Start=80, 78, 82, 150
Color End=80, 78, 82, 255
Jitter Distance=1.02
Jitter Time=2.00
TempK=118.00
TempRate=-1.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=1.50, 1.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=5.00, 5.00
Z Particle Velocity=50.00, 50.01
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=1.10, 4.50
Type=18
X Scale=10.00, 30.00
Y Scale=10.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.10, 0.10
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.10
Fade Out=0.50, 0.52
Rotation=-20.00, 20.00
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=80, 78, 82, 150
Color End=80, 78, 82, 255
Jitter Distance=1.02
Jitter Time=2.00
TempK=118.00
TempRate=-1.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=1.50, 1.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=5.00, 5.00
Z Particle Velocity=50.00, 50.01
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=1.10, 4.50
Type=18
X Scale=10.00, 30.00
Y Scale=10.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.10, 0.10
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.10
Fade Out=0.50, 0.52
Rotation=-20.00, 20.00
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_3.bmp
Bounce=0.00
Color Start=80, 78, 82, 150
Color End=80, 78, 82, 255
Jitter Distance=1.02
Jitter Time=2.00
TempK=118.00
TempRate=-1.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=1.50, 1.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=5.00, 5.00
Z Particle Velocity=50.00, 50.01
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=1.10, 4.50
Type=18
X Scale=10.00, 30.00
Y Scale=10.00, 30.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.10, 0.10
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.10
Fade Out=0.50, 0.52
Rotation=-20.00, 20.00
Face=1, 1, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_1.bmp
Bounce=0.00
Color Start=80, 78, 82, 150
Color End=80, 78, 82, 255
Jitter Distance=1.02
Jitter Time=2.00
TempK=118.00
TempRate=-1.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.50, 0.50
Delay=0.0, 0.0
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=5.00, 5.01
X Particle Velocity=0.00, 0.00
Y Particle Velocity=1.00, 1.00
Z Particle Velocity=50.00, 50.01
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00

[Particle.5]
Lifetime=40.00, 40.01
Type=19
X Scale=1.20, 1.30
Y Scale=1.20, 1.30
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.11
Y Scale Rate=0.11, 0.12
Z Scale Rate=0.00, 0.00
Drag=5.00, 5.01
Color Rate=0.00, 0.01
Fade In=0.05, 0.05
Fade Out=0.95, 0.95
Rotation=-0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=95, 99, 99, 150
Color End=106, 111, 111, 255
Jitter Distance=0.001
Jitter Time=0.0
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=20.00
Extrude Pitch Max=15.00
Extrude Heading Max=15.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=190.00, 210.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, -5.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-2.00, -2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=12.00, 18.50
Type=19
X Scale=1.00, 1.00
Y Scale=1.00, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.00, 0.00
Drag=-2.00, -1.99
Color Rate=0.60, 0.95
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.20
Fade Out=0.55, 0.77
Rotation=-50.00, 50.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=255, 255, 255, 75
Color End=208, 208, 208, 150
Jitter Distance=0.00
Jitter Time=0.00
TempK=100.00
TempRate=0.00
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=8.00
Y Scale Goal=8.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


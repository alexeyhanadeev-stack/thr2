[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[controller.0]
lifetime=0.0, 0.0
type=3
distance=5000.00, 5000.00
delay=7200.00, 7200.00
x offset=0.00, 0.00
y offset=0.00, 0.00
z offset=0.00, 0.00
effect.0=fx_avalon_hangerwhitelight.fx, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00

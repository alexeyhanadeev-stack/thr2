[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Ray_gun.wav
MinAttenuationDistance=50.00
Looping=FALSE

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.01
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=100, 100
Type=21
X Scale=1, 1
Y Scale=1, 1
Z Scale=0.00, 0.00
X Scale Rate=5.00, 5.00
Y Scale Rate=5.00, 5.00
Z Scale Rate=0.00, 0.00
Drag=-999.00, -999.00
Color Rate=0.00, 0.05
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.05
Fade Out=0.95, 0.95
Face=0, 0, 0
Light=1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_laser_tracer.dds
Bounce=0.00
Color Start=0, 255, 0, 120
Color End=0, 255, 0, 120
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=1.00
Y Scale Goal=1.00
Z Scale Goal=1.00
Extrude Length=50.00
Extrude Pitch Max=2.00
Extrude Heading Max=2.00


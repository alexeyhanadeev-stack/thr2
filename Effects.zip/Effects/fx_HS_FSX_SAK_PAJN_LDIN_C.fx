[Library Effect]
Lifetime=5
Version=2.00
Display Name=ORBX FTX SAK - PAJN LDIN approach lights RW08 - Mendenhall Peninsula
Radius=10000
Priority=0

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1


// AFT STROBE LIGHT

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.10, 0.10
No Interpolate=1
Rate=2.00, 2.00

[Particle.0]
Lifetime=0.05, 0.05
Type=19
X Scale=3.00, 3.00
Y Scale=3.00, 3.00
Z Scale=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_2.bmp
Color Start=200, 200, 255, 200
Color End=200, 200, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.1]
Lifetime=0.00, 0.00
Delay=0.10, 0.10
No Interpolate=1
Rate=2.00, 2.00

[Particle.1]
Lifetime=0.05, 0.05
Type=19
X Scale=2.00, 2.00
Y Scale=2.00, 2.00
Z Scale=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
//Static=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_2.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.2]
Lifetime=0.00, 0.00
Delay=0.10, 0.10
No Interpolate=1
Rate=2.00, 2.00

[Particle.2]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00

[Emitter.3]
Lifetime=0.00, 0.00
Delay=0.10, 0.10
No Interpolate=1
Rate=2.00, 2.00

[Particle.3]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00


// CENTER STROBE LIGHT

[Emitter.4]
Lifetime=0.00, 0.00
Delay=0.30, 0.30
No Interpolate=1
Rate=2.00, 2.00

[Particle.4]
Lifetime=0.05, 0.05
Type=19
X Scale=3.00, 3.00
Y Scale=3.00, 3.00
Z Scale=0.00, 0.00
X Offset=122.00, 122.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
//Static=1
Face=1, 1, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_2.bmp
Color Start=200, 200, 255, 200
Color End=200, 200, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.5]
Lifetime=0.00, 0.00
Delay=0.30, 0.30
No Interpolate=1
Rate=2.00, 2.00

[Particle.5]
Lifetime=0.05, 0.05
Type=19
X Scale=2.00, 2.00
Y Scale=2.00, 2.00
Z Scale=0.00, 0.00
X Offset=122.00, 122.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
//Static=1
Face=1, 1, 1

[ParticleAttributes.5]
Blend Mode=2
Texture=fx_2.bmp
Color Start=200, 200, 255, 200
Color End=200, 200, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.6]
Lifetime=0.00, 0.00
Delay=0.30, 0.30
No Interpolate=1
Rate=2.00, 2.00

[Particle.6]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=122.00, 122.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.6]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00

[Emitter.7]
Lifetime=0.00, 0.00
Delay=0.30, 0.30
No Interpolate=1
Rate=2.00, 2.00

[Particle.7]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=122.00, 122.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.7]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00



// FORE STROBE LIGHT

[Emitter.8]
Lifetime=0.00, 0.00
Delay=0.60, 0.60
No Interpolate=1
Rate=2.00, 2.00

[Particle.8]
Lifetime=0.05, 0.05
Type=19
X Scale=3.00, 3.00
Y Scale=3.00, 3.00
Z Scale=0.00, 0.00
X Offset=244.00, 244.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
//Static=1
Face=1, 1, 1

[ParticleAttributes.8]
Blend Mode=2
Texture=fx_2.bmp
Color Start=200, 200, 255, 200
Color End=200, 200, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.9]
Lifetime=0.00, 0.00
Delay=0.60, 0.60
No Interpolate=1
Rate=2.00, 2.00

[Particle.9]
Lifetime=0.05, 0.05
Type=19
X Scale=2.00, 2.00
Y Scale=2.00, 2.00
Z Scale=0.00, 0.00
X Offset=244.00, 244.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.9]
Blend Mode=2
Texture=fx_2.bmp
Color Start=200, 200, 255, 200
Color End=200, 200, 255, 0
uv1=0.00, 0.00
uv2=0.50, 0.50

[Emitter.10]
Lifetime=0.00, 0.00
Delay=0.60, 0.60
No Interpolate=1
Rate=2.00, 2.00

[Particle.10]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=244.00, 244.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.10]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00

[Emitter.11]
Lifetime=0.00, 0.00
Delay=0.60, 0.60
No Interpolate=1
Rate=2.00, 2.00

[Particle.11]
Lifetime=0.05, 0.05
Type=19
X Scale=1.90, 1.90
Y Scale=1.90, 1.90
Z Scale=0.00, 0.00
X Offset=122.00, 122.00
Y Offset=10.00, 10.00
Z Offset=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.11]
Blend Mode=2
Texture=fx_MF_marine_light.bmp
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 0
uv1=0.00, 0.00
uv2=1.00, 1.00


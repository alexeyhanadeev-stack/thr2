[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.20, 0.25
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 40.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-0.50, -0.50
X Particle Velocity=-2.00, -2.00
Y Particle Velocity=1.00, 1.00
Z Particle Velocity=-1.10, -1.10
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=1.90, 3.10
Type=19
X Scale=0.50, 1.20
Y Scale=0.50, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.40
Y Scale Rate=0.20, 0.40
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.40, 1.00
X Offset=0.00, 0.00
Y Offset=1.00, 1.00
Z Offset=-4.00, -4.00
Fade In=0.00, 0.01
Fade Out=0.60, 0.75
Rotation=-10.00, 20.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=14, 12, 12, 90
Color End=36, 35, 35, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=107.50
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.20, 0.25
Delay=0.50, 0.55
Bounce=0.00
Rate=20.00, 35.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-0.50, -0.50
X Particle Velocity=0.00, 0.05
Y Particle Velocity=1.20, 1.25
Z Particle Velocity=-1.20, -1.20
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=1.50, 2.50
Type=19
X Scale=0.50, 0.80
Y Scale=0.50, 0.80
Z Scale=0.00, 0.00
X Scale Rate=0.80, 0.90
Y Scale Rate=0.80, 0.90
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=1.00, 1.00
Z Offset=-4.00, -4.00
Fade In=0.00, 0.01
Fade Out=0.50, 0.55
Rotation=-25.00, 25.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=56, 44, 44, 100
Color End=44, 44, 44, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=107.80
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.75, 2.00
Delay=1.10, 1.20
Bounce=0.00
Rate=15.00, 165.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-0.50, -0.50
X Particle Velocity=0.00, 0.00
Y Particle Velocity=1.80, 1.90
Z Particle Velocity=-1.90, -1.80
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=1.00, 2.45
Type=19
X Scale=0.50, 0.80
Y Scale=0.50, 0.80
Z Scale=0.00, 0.00
X Scale Rate=0.80, 1.00
Y Scale Rate=0.80, 1.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=1.00, 1.00
Z Offset=-4.00, -4.00
Fade In=0.00, 0.01
Fade Out=0.50, 0.55
Rotation=-20.00, 20.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=106, 106, 116, 50
Color End=151, 157, 160, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=8.00
Y Scale Goal=8.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.75, 6.00
Delay=1.55, 1.65
Bounce=0.00
Rate=20.00, 70.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-0.50, -0.50
X Particle Velocity=0.00, 0.00
Y Particle Velocity=2.00, 2.20
Z Particle Velocity=-2.20, -2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=1.00, 5.50
Type=19
X Scale=0.40, 0.50
Y Scale=0.40, 0.50
Z Scale=0.00, 0.00
X Scale Rate=0.90, 1.00
Y Scale Rate=0.90, 1.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=1.00, 1.00
Z Offset=-4.00, -4.00
Fade In=0.00, 0.01
Fade Out=0.50, 0.55
Rotation=-20.00, 20.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=92, 56, 38, 35
Color End=100, 111, 104, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.20
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


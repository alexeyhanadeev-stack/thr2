[Library Effect]
Lifetime=5
Version=2.00
Display Name=FX_JF_L749_HP_Flame 
Radius=20


[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=0



[Emitter.0]//--------------------Left 
Lifetime=0.00, 0.00
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=54.00, 59.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.50, 1.00
X Offset= -0.97, -0.97
Y Offset= 0.57, 0.57
Z Offset= -0.38, -0.38
Pitch=0, 0
Bank=0, 0
Heading=210,220

[Particle.0]
Lifetime=0.08, 0.09
Type=19
X Scale=0.20, 0.25
Y Scale=0.30, 0.35
Z Scale=0.30, 0.35
X Scale Rate=0.0, 0.00
Y Scale Rate=.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.01, 0.05
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0, 0
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_wt5.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=2.00
Y Scale Goal=0.10
Z Scale Goal=1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Emitter.1]//-------------------Left 
Lifetime=0.00, 0.00
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=54.00, 59.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.50, 1.00
X Offset= -0.97, -0.97
Y Offset= 0.57, 0.57
Z Offset= -0.38, -0.38
Pitch=0, 0
Bank=0,0
Heading=220,230

[Particle.1]
Lifetime=0.08, 0.09
Type=19
X Scale=0.20, 0.25
Y Scale=0.30, 0.35
Z Scale=0.30, 0.35
X Scale Rate=0.0, 0.00
Y Scale Rate=.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.01, 0.05
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0, 0
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_WT3.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=2.00
Y Scale Goal=0.10
Z Scale Goal=1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00



[Emitter.2]//--------------------Right 
Lifetime=0.00, 0.00
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=54.00, 59.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.50, 1.00
X Offset= 0.93, 0.93
Y Offset= 0.57, 0.57
Z Offset= -0.38, -0.38
Pitch=0, 0
Bank=40, 40
Heading=205, 215

[Particle.2]
Lifetime=0.08, 0.09
Type=19
X Scale=0.20, 0.25
Y Scale=0.30, 0.35
Z Scale=0.30, 0.35
X Scale Rate=0.0, 0.00
Y Scale Rate=.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.01, 0.05
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0, 0
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_wt5.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=2.00
Y Scale Goal=0.10
Z Scale Goal=1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]//-------------------Right 
Lifetime=0.00, 0.00
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=54.00, 59.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.50, 1.00
X Offset= 0.93, 0.93
Y Offset= 0.57, 0.57
Z Offset= -0.38, -0.38
Pitch=0, 0
Bank=40, 40
Heading=205, 215

[Particle.3]
Lifetime=0.08, 0.09
Type=19
X Scale=0.20, 0.25
Y Scale=0.30, 0.35
Z Scale=0.30, 0.35
X Scale Rate=0.0, 0.00
Y Scale Rate=.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.01, 0.05
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0, 0
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_WT3.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=2.00
Y Scale Goal=0.10
Z Scale Goal=1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


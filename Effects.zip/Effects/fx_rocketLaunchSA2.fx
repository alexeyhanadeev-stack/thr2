[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Rocket02.wav
MinAttenuationDistance=1200.00
Looping=TRUE

[Properties]

[Emitter.0]
Lifetime=60.00, 60.00
Delay=0.00, 0.00
Bounce=0.50
No Interpolate=1
Rate=20.00, 50.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=1.00, 1.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-15.00, -15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=40.00, 60.00
Type=19
X Scale=3.00, 6.00
Y Scale=3.00, 6.00
Z Scale=0.00, 0.00
X Scale Rate=0.01, 0.15
Y Scale Rate=0.01, 0.15
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.60, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.20
Fade Out=0.40, 0.60
Rotation=0.00, 0.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=232, 237, 238, 100
Color End=209, 220, 220, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=30.00, 30.00
Delay=0.00, 0.00
Bounce=0.50
No Interpolate=1
Rate=20.00, 50.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=1.00, 1.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-10.00, -10.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=40.00, 60.00
Type=19
X Scale=3.00, 6.00
Y Scale=3.00, 6.00
Z Scale=0.00, 0.00
X Scale Rate=0.01, 0.15
Y Scale Rate=0.01, 0.15
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.60, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.20
Fade Out=0.40, 0.60
Rotation=0.00, 0.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=197, 207, 207, 100
Color End=179, 192, 193, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=10.00
Y Scale Goal=10.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=30.00, 30.00
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 50.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=1.50, 3.00
Type=19
X Scale=1.00, 2.00
Y Scale=1.00, 2.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.70, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=-5.30, -5.30
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-200.00, 200.00
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=165, 65, 5, 100
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


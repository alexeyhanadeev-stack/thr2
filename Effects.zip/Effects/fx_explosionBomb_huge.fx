[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Exp_OilRig01.wav
MinAttenuationDistance=600.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=400.00, 600.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-60.00, 60.00
Y Particle Velocity=40.00, 160.00
Z Particle Velocity=-2.00, 60.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=2.00, 3.00
Type=19
X Scale=0.25, 1.00
Y Scale=0.25, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.95, 1.00
X Offset=-1.00, 1.00
Y Offset=-1.00, 1.00
Z Offset=-1.00, 1.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 100.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.35
Color Start=233, 131, 105, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=70.00
TempRate=-0.01
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=0.30, 0.50
Type=19
X Scale=16.00, 20.00
Y Scale=16.00, 20.00
Z Scale=0.00, 0.00
X Scale Rate=60.00, 60.00
Y Scale Rate=60.00, 60.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.20, 0.50
X Offset=-4.00, 4.00
Y Offset=0.00, 0.00
Z Offset=-4.00, 4.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Ground Normal=1
Shade=1
Face=0, 0, 0

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=160, 160, 160, 255
Color End=133, 133, 133, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.50, 0.50
uv2=1.00, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.30, 0.30
Type=19
X Scale=300.00, 300.00
Y Scale=300.00, 300.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.42, 0.60
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 255, 255, 255
Color End=175, 175, 175, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=12.00, 12.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 15.00
Bank=-15.00, 15.00
Heading=0.00, 0.00

[Particle.3]
Name=fx_expComp_DirtSpray_Huge.fx
Type=26
EmittedEffectName=fx_expComp_DirtSpray_Huge.fx

[ParticleAttributes.3]

[Emitter.4]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.4]
Name=fx_expComp_DirtStream_Huge.fx
Type=26
EmittedEffectName=fx_expComp_DirtStream_Huge.fx

[ParticleAttributes.4]

[Emitter.5]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.5]
Name=fx_expComp_DirtStream_Huge.fx
Type=26
EmittedEffectName=fx_expComp_DirtStream_Huge.fx

[ParticleAttributes.5]

[Emitter.6]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.6]
Name=fx_expComp_DirtStream_Huge.fx
Type=26
EmittedEffectName=fx_expComp_DirtStream_Huge.fx

[ParticleAttributes.6]

[Emitter.7]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.7]
Name=fx_expComp_DirtStream_Huge.fx
Type=26
EmittedEffectName=fx_expComp_DirtStream_Huge.fx

[ParticleAttributes.7]

[Emitter.8]
Lifetime=20.00, 20.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 5.00
Bank=-5.00, 5.00
Heading=0.00, 0.00

[Particle.8]
Name=fx_expComp_FireSmoke_Huge.fx
Type=26
EmittedEffectName=fx_expComp_FireSmoke_Huge.fx

[ParticleAttributes.8]

[Emitter.9]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.9]
Name=fx_expComp_FireStreamer_Huge.fx
Type=26
EmittedEffectName=fx_expComp_FireStreamer_Huge.fx

[ParticleAttributes.9]

[Emitter.10]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.10]
Name=fx_expComp_FireStreamer_Huge.fx
Type=26
EmittedEffectName=fx_expComp_FireStreamer_Huge.fx

[ParticleAttributes.10]

[Emitter.11]
Lifetime=8.00, 8.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.01, 0.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 30.00
Bank=-30.00, 30.00
Heading=0.00, 0.00

[Particle.11]
Name=fx_expComp_FireStreamer_Huge.fx
Type=26
EmittedEffectName=fx_expComp_FireStreamer_Huge.fx

[ParticleAttributes.11]

[Emitter.12]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.12]
Lifetime=0.30, 0.30
Type=19
X Scale=200.00, 200.00
Y Scale=200.00, 200.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.42, 0.60
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.12]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=177, 168, 131, 255
Color End=150, 140, 125, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.13]
Lifetime=0.10, 0.10
Delay=0.00, 0.00
Bounce=0.00
Rate=800.00, 1200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-60.00, 60.00
Y Particle Velocity=20.00, 100.00
Z Particle Velocity=-2.00, 60.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.13]
Lifetime=3.00, 5.00
Type=19
X Scale=0.20, 0.75
Y Scale=0.20, 0.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.80, 1.00
X Offset=-1.00, 1.00
Y Offset=-1.00, 1.00
Z Offset=-1.00, 1.00
Fade In=0.00, 0.00
Fade Out=0.80, 1.00
Rotation=-200.00, 200.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.13]
Blend Mode=1
Texture=fx_3.bmp
Bounce=0.35
Color Start=94, 74, 47, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=90.00
TempRate=0.00
uv1=0.25, 0.50
uv2=0.50, 0.75
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


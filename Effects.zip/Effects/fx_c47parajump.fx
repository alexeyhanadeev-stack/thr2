// WWII U.S. Paratroopers

[Library Effect]
Lifetime=5
Version=2.00

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[Emitter.0]                       
Lifetime=0.50, 0.50                
Delay=0.0, 0.0
Bounce=0.00
LOD=1
Gravity=1
Rate=4.00, 4.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-4.00, -3.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00,0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00

[Particle.0]                       
Lifetime=1.50, 1.50                 
Type=19
X Scale=1.00, 1.00
Y Scale=1.00, 1.00
Z Scale=1.00, 1.00
X Scale Rate=1.00, 1.00
Y Scale Rate=1.00, 1.00
Z Scale Rate=1.00, 1.00
Drag=-3.00, -3.00
Color Rate=0.70, 1.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-0.00, -0.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_c47para1.bmp
Bounce=0.00
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 255
TextureSize=256
CellSize=256
CellStart=0
CellEnd=0
Jitter Distance=0.00			
Jitter Time=0.5				
TempK=70.00                      
TempRate=0.0
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=-1.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]                  
Lifetime=1.00, 1.00            
Delay=1.50, 1.50
Bounce=0.00				
LOD=1
Gravity=1
Rate=0.66, 0.66
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-0.00, -0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00,0.00
X Offset=9.00, 12 .00			//  Side to side 
Y Offset=40.00, 43.00            	//  Up and down 
Z Offset=20.00, 21.00                 	//  For and aft 
Pitch=45.0, 45.0
X Rotation=0.00, 0.00ii
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00

[Particle.1]
Lifetime=120.00, 120.00
Type=19
X Scale=5.20, 5.20			
Y Scale=5.20, 5.20                       			
Z Scale=5.20, 5.20			
X Scale Rate=1.00, 1.00			
Y Scale Rate=1.00, 1.00			
Z Scale Rate=1.00, 1.00			
Drag=-8.0, -8.0	        
Color Rate=0.70, 1.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-0.00, 0.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_c47para2.bmp
Bounce=0.00				
Color Start=255, 255, 255, 255
Color End=255, 255, 255, 255
TextureSize=512
CellSize=512
CellStart=0
CellEnd=0
Jitter Distance=0.00			
Jitter Time=0.00			
TempK=94.00			
TempRate=0.0
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=-1.00
Y Scale Goal=1.00
Z Scale Goal=1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00








[Library Effect]
Lifetime=5
Version=2.00
Display Name=smaller volcanic steam emission, FSX version, by Holger Sandmann
Radius=10000
Priority=0

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=12.00, 20.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=10.00, 15.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=8.00, 12.00
Type=19
X Scale=4.50, 9.50
Y Scale=4.50, 9.50
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.20
Y Scale Rate=0.20, 0.20
Z Scale Rate=0.00, 0.00
Drag=-1.50, -1.40
Color Rate=0.50, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.80, 0.80
Rotation=-20.00, 20.00
Shade=1
Face=0, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=160, 160, 160, 50
Color End=180, 180, 180, 80
Jitter Distance=0.03
Jitter Time=0.30
TempK=107.50
TempRate=0.11
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=50.00
Y Scale Goal=50.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

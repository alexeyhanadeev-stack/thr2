[Library Effect]
Lifetime=5
Version=1.00
Radius=-1
Priority=0

[controller.0]
lifetime=0.0, 0.0 
type=3 
distance=15000.00, 15000.00
delay=17.00, 17.00
x offset=0.00, 0.00  
y offset=0.00, 0.00  
z offset=0.00, 0.00
effect.0=fx_FTX_NZSI_Lighthouse_white_x2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00


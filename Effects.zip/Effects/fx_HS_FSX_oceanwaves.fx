[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=1

[Emitter.0]
Lifetime=1.00, 1.00
Delay=0.00, 0.00
//Delay=2.75, 2.75
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=1.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=3.00, 5.00
Type=19
X Scale=14.00, 20.00
Y Scale=8.00, 12.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.10, -0.05
Color Rate=0.40, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.40
Fade Out=0.60, 0.95
Rotation=0.00, 0.00
Ground Normal=1
Shade=1
Face=0, 0, 0

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_swoosh2.bmp
Bounce=0.00
Color Start=140, 140, 140, 120
Color End=240, 240, 240, 160
Jitter Distance=0.00
Jitter Time=0.00
FPS=6.00
TextureSize=256
CellSize=128
CellStart=0
CellEnd=3
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=SFX_M60.wav
MinAttenuationDistance=10.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.10, 0.20
Delay=0.00, 0.00
Bounce=0.00
Rate=30.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=1.00, 1.50
Type=19
X Scale=0.40, 0.75
Y Scale=0.40, 0.75
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.20, 0.30
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.10, 0.20
Rotation=-20.00, 20.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=88, 85, 78, 75
Color End=100, 100, 100, 0
Jitter Distance=0.05
Jitter Time=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.50, 0.50
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=0.10, 0.10
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=0.15, 0.15
Type=19
X Scale=15.00, 15.00
Y Scale=15.00, 15.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.90, 0.90
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Static=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=39, 36, 33, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.05, 0.10
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=5.00, 500.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.05, 0.05
Type=19
X Scale=0.10, 0.20
Y Scale=0.10, 0.20
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.60, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-100.00, 100.00
Static=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=179, 102, 45, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.05, 0.10
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=5.00, 300.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=0.05, 0.05
Type=19
X Scale=0.10, 0.15
Y Scale=0.10, 0.15
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.60, 1.00
X Offset=-0.12, -0.12
Y Offset=0.00, 0.00
Z Offset=0.05, 0.05
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-100.00, 100.00
Static=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=179, 102, 45, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


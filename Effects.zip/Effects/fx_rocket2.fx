[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=Exp_Gen02.wav
MinAttenuationDistance=5000.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.50, 1.00
Delay=0.00, 0.00
Bounce=0.00
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-10.00, 10.00
Y Particle Velocity=5.00, 10.00
Z Particle Velocity=-10.00, 10.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=8.00, 15.00
Type=19
X Scale=4.00, 4.50
Y Scale=4.00, 4.50
Z Scale=0.00, 0.00
X Scale Rate=0.25, 0.35
Y Scale Rate=0.25, 0.35
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.90, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.10
Fade Out=0.50, 0.60
Rotation=-30.00, 30.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=139, 119, 92, 100
Color End=123, 117, 81, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.50
Y Scale Goal=3.50
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.22, 0.52
Delay=0.00, 0.00
Bounce=0.00
Rate=50.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-20.00, 20.00
Y Particle Velocity=10.00, 15.00
Z Particle Velocity=-20.00, 20.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=1.50, 2.00
Type=19
X Scale=3.00, 4.00
Y Scale=3.00, 4.00
Z Scale=0.00, 0.00
X Scale Rate=0.50, 1.00
Y Scale Rate=0.50, 1.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.20, 0.50
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.50, 0.50
Rotation=-50.00, 50.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=102, 81, 66, 100
Color End=104, 85, 70, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=100.00
TempRate=-0.10
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.00, 0.00
Delay=0.50, 0.50
Bounce=0.00
Rate=20.00, 20.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.20, 0.20
Type=19
X Scale=2.00, 3.00
Y Scale=2.00, 3.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.70, 0.80
X Offset=-2.00, 2.00
Y Offset=0.00, 0.00
Z Offset=-2.00, 2.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-200.00, 200.00
Static=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 255, 255, 100
Color End=50, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=-0.01
uv1=0.75, 0.00
uv2=1.00, 0.25
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.00, 0.00
Delay=0.50, 0.50
Bounce=0.00
Rate=2.50, 5.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=5.00, 8.00
Type=19
X Scale=4.00, 6.00
Y Scale=4.00, 6.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.30
Y Scale Rate=0.20, 0.30
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.60, 0.80
X Offset=-2.00, 2.00
Y Offset=0.00, 0.00
Z Offset=-2.00, 2.00
Fade In=0.10, 0.20
Fade Out=0.60, 0.90
Rotation=-50.00, 50.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=0, 0, 0, 150
Color End=30, 30, 30, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=2.50, 5.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=5.00, 8.00
Type=19
X Scale=4.00, 6.00
Y Scale=4.00, 6.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.30
Y Scale Rate=0.20, 0.30
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.60, 0.80
X Offset=-2.00, 2.00
Y Offset=0.00, 0.00
Z Offset=-2.00, 2.00
Fade In=0.10, 0.20
Fade Out=0.60, 0.90
Rotation=-50.00, 50.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=30, 30, 30, 150
Color End=50, 50, 50, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=120.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


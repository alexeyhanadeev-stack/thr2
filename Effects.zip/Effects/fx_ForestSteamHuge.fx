[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=120.00, 180.00
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.50
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=2.00, 4.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=3.00, 4.00
Type=19
X Scale=40.00, 60.00
Y Scale=40.00, 60.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.20, 0.40
X Offset=-70.00, 70.00
Y Offset=20.00, 30.00
Z Offset=-70.00, 70.00
Fade In=0.10, 0.60
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 200
Color End=20, 20, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=160.00
TempRate=-0.10
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=120.00, 180.00
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.50
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=10.00, 18.00
Type=19
X Scale=60.00, 65.00
Y Scale=60.00, 66.00
Z Scale=0.00, 0.00
X Scale Rate=0.03, 0.10
Y Scale Rate=0.03, 0.10
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 0.90
X Offset=-70.00, 70.00
Y Offset=10.00, 10.00
Z Offset=-70.00, 70.00
Fade In=0.10, 0.20
Fade Out=0.60, 0.70
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=100, 100, 100, 150
Color End=140, 140, 120, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=130.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=120.00, 180.00
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.50
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=2.00, 4.00
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=-40.00, 40.00
Y Offset=0.00, 0.00
Z Offset=-40.00, 40.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=3.00, 4.00
Type=19
X Scale=40.00, 60.00
Y Scale=40.00, 60.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.25, 0.40
X Offset=-60.00, 60.00
Y Offset=20.00, 30.00
Z Offset=-60.00, 60.00
Fade In=0.10, 0.60
Fade Out=0.70, 0.80
Rotation=-50.00, 50.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 200
Color End=50, 50, 50, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=150.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=120.00, 180.00
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.50
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-8.00, 8.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-8.00, 8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=10.00, 18.00
Type=19
X Scale=60.00, 70.00
Y Scale=60.00, 70.00
Z Scale=0.00, 0.00
X Scale Rate=0.03, 0.10
Y Scale Rate=0.03, 0.10
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.50, 0.90
X Offset=-60.00, 60.00
Y Offset=10.00, 10.00
Z Offset=-60.00, 60.00
Fade In=0.10, 0.20
Fade Out=0.60, 0.70
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=160, 160, 160, 150
Color End=220, 220, 200, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=130.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.30, 0.50
Delay=0.00, 0.00
Bounce=0.00
Rate=80.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-20.00, 20.00
Y Particle Velocity=70.00, 90.00
Z Particle Velocity=-20.00, 20.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=1.00, 1.50
Type=19
X Scale=18.00, 25.00
Y Scale=18.00, 25.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.50
Y Scale Rate=0.20, 0.50
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.10, 0.80
X Offset=-60.00, 60.00
Y Offset=0.00, 0.00
Z Offset=-60.00, 60.00
Fade In=0.00, 0.10
Fade Out=0.60, 0.80
Rotation=-200.00, 200.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=200, 200, 210, 150
Color End=240, 240, 250, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=60.00
TempRate=0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=20.00
Y Scale Goal=20.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=1.00, 1.00
Delay=0.00, 0.00
Bounce=0.00
Rate=0.50, 0.50
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=0.00, 0.00
Type=19
X Scale=120.00, 120.00
Y Scale=120.00, 120.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Ground Normal=1
Face=0, 0, 0

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_5.bmp
Bounce=0.00
Color Start=50, 50, 50, 255
Color End=50, 50, 50, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Library Effect]
Lifetime=5
Version=2.00
Display Name=JF L049 Engine Start Effects
Radius=50


[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=0


[Emitter.0] //-------Left front Exhaust Smoke - All engines
Lifetime=7.00, 9.00
Delay=0.00, 0.00
Bounce=0.20
Rate=70.00, 85.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.50, -0.400
Z Particle Velocity=-6.00, -4.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= -1.2, -1.2
Y Offset= 0.6, 0.6
Z Offset= 0.40, 0.40
Pitch=-10.00, -10.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=5.00, 6.00
Type=19
X Scale=0.40, 0.50
Y Scale=0.50, 0.60
Z Scale=0.50, 0.60
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0   //0.20, 0.80
Color Rate=0.01, 1.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=99, 99, 107, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00

Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=10.00


[Emitter.1] //-------- Left front Exhaust Flame - all engines
Lifetime=5.00, 6.50
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=24.00, 39.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Offset= -1.2, -1.2
Y Offset= 0.5, 0.5
Z Offset= 0.41, 0.41

[Particle.1]
Lifetime=0.011, 0.013
Type=19
X Scale=0.20, 0.46
Y Scale=0.20, 0.46
Z Scale=0.10, 0.15
X Scale Rate=133.00, 146.00
Y Scale Rate=133.00, 146.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.17, 0.48
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_wt.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=2.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2] //-------Left Aft Exhaust Smoke - All engines
Lifetime=7.00, 9.00
Delay=0.00, 0.00
Bounce=0.20
Rate=70.00, 85.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.50, -0.400
Z Particle Velocity=-6.00, -4.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= -1.2, -1.2
Y Offset= 0.6, 0.6
Z Offset= 0.0, 0.0
Pitch=-10.00, -10.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=5.00, 6.00
Type=19
X Scale=0.40, 0.50
Y Scale=0.50, 0.60
Z Scale=0.50, 0.60
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0   //0.20, 0.80
Color Rate=0.01, 1.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=99, 99, 107, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00

Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=10.00


[Emitter.3] //-------- Left Aft Exhaust Flame - all engines
Lifetime=5.00, 6.50
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=24.00, 39.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Offset= -1.2, -1.2
Y Offset= 0.5, 0.5
Z Offset= 0.0, 0.0

[Particle.3]
Lifetime=0.011, 0.013
Type=19
X Scale=0.20, 0.46
Y Scale=0.20, 0.46
Z Scale=0.10, 0.15
X Scale Rate=133.00, 146.00
Y Scale Rate=133.00, 146.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.17, 0.48
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_wt.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=2.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4] //-------Right Front Exhaust Smoke - All engines
Lifetime=7.00, 9.00
Delay=0.00, 0.00
Bounce=0.20
Rate=70.00, 85.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.50, -0.400
Z Particle Velocity=-6.00, -4.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= 1.2, 1.2
Y Offset= 0.6, 0.6
Z Offset= 0.40, 0.40
Pitch=-10.00, -10.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=5.00, 6.00
Type=19
X Scale=0.40, 0.50
Y Scale=0.50, 0.60
Z Scale=0.50, 0.60
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0   //0.20, 0.80
Color Rate=0.01, 1.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=99, 99, 107, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00

Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=10.00


[Emitter.5] //-------- Right front Exhaust Flame - all engines
Lifetime=5.00, 6.50
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=24.00, 39.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Offset= 1.2, 1.2
Y Offset= 0.5, 0.5
Z Offset= 0.41, 0.41

[Particle.5]
Lifetime=0.011, 0.013
Type=19
X Scale=0.20, 0.46
Y Scale=0.20, 0.46
Z Scale=0.10, 0.15
X Scale Rate=133.00, 146.00
Y Scale Rate=133.00, 146.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.17, 0.48
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.5]
Blend Mode=2
Texture=fx_wt.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=2.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6] //-------Right Aft Exhaust Smoke - All engines
Lifetime=7.00, 9.00
Delay=0.00, 0.00
Bounce=0.20
Rate=70.00, 85.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.50, -0.400
Z Particle Velocity=-6.00, -4.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= 1.2, 1.2
Y Offset= 0.6, 0.6
Z Offset= 0.0, 0.0
Pitch=-10.00, -10.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=5.00, 6.00
Type=19
X Scale=0.40, 0.50
Y Scale=0.50, 0.60
Z Scale=0.50, 0.60
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0   //0.20, 0.80
Color Rate=0.01, 1.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.6]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=99, 99, 107, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00

Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=10.00


[Emitter.7] //-------- Right Aft Exhaust Flame - all engines
Lifetime=5.00, 6.50
Delay=0.00, 1.50
Bounce=0.00
No Interpolate=1
Rate=24.00, 39.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Offset= 1.2, 1.2
Y Offset= 0.5, 0.5
Z Offset= 0.0, 0.0

[Particle.7]
Lifetime=0.011, 0.013
Type=19
X Scale=0.20, 0.46
Y Scale=0.20, 0.46
Z Scale=0.10, 0.15
X Scale Rate=133.00, 146.00
Y Scale Rate=133.00, 146.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.17, 0.48
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 1, 1

[ParticleAttributes.7]
Blend Mode=2
Texture=fx_wt.bmp
Bounce=0.00
Color Start=60, 25, 5, 125
Color End=0, 0, 0, 0 
Jitter Distance=0.00
Jitter Time=0.00
TempK=110.00
TempRate=0.20
uv1=1.00, 0.50
uv2=0.50, 0.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=2.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00








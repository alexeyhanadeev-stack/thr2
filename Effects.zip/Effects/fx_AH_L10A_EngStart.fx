[Library Effect]
Lifetime=5
Version=1.00
Display Name=AH Lockheed L10A Engine Start Effects
Radius=20

[Properties]
Cockpit=1
VirtualCockpit=1
Spot=1
Tower=1
Map=0

[Emitter.0] //Smoke Puff
Lifetime=1.0, 1.2 
Delay=0.40, 0.50
Bounce=0.00
Rate=10.00, 10.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-14.00, -8.00
X Offset= 0.0, 0.0
Y Offset= -0.37, -0.36
Z Offset=-1.58,-1.56
Pitch=0,0
Bank=0,0
Heading=0,0

[Particle.0]
Lifetime=1.0, 1.2
Type=19
X Scale=0.70, 0.70
Y Scale=0.70, 0.70
Z Scale=0.00, 0.00
X Scale Rate=1.00, 1.00
Y Scale Rate=1.00, 1.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
Fade In=0.00, 0.01
Fade Out=0.50, 0.55
Rotation=-90.00, 90.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=21, 21, 26, 70
Color End=58, 58, 69, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=1.00
Y Scale Goal=1.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Emitter.1] //-------Exhaust Smoke - All engines
Lifetime=3.00, 3.10
Delay=3.00, 3.00
Bounce=0.20
Rate=70.00, 85.00
X Emitter Velocity=0,0
Y Emitter Velocity=0,0
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.500, -0.400
Z Particle Velocity=-6.00, -4.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= 0.0, 0.0
Y Offset= -0.37, -0.36
Z Offset=-1.58,-1.56
Pitch=5.00, 5.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=2.00, 2.30
Type=19
X Scale=0.30, 0.35
Y Scale=0.40, 0.45
Z Scale=0.40, 0.45
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0       //0.20, 0.80
Color Rate=0.01, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=99, 99, 107, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=1.00
Y Scale Goal=1.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2] //------- Exhaust Smoke Trail- All engines
Lifetime=2.00, 3.00
Delay=6.00, 7.00
Bounce=0.20
Rate=5.00, 10.00
X Emitter Velocity=0,0
Y Emitter Velocity=0,0
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-0.500, -0.400
Z Particle Velocity=-2.00, -1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset= 0.0, 0.0
Y Offset= -0.37, -0.36
Z Offset=-1.58,-1.56
Pitch=5.00, 5.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=2.00, 3.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.40, 0.45
Z Scale=0.40, 0.45
X Scale Rate=0.40, 0.50
Y Scale Rate=0.50, 0.60
Z Scale Rate=1.00, 1.50
Drag=0,0       //0.20, 0.80
Color Rate=0.01, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.30, 0.60
Rotation=-180.00, 280.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.50
Color Start=214, 208, 200, 100
Color End=215, 220, 225, 255
Jitter Distance=0.01
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00
X Scale Goal=5.00
Y Scale Goal=5.00
Z Scale Goal=10.00

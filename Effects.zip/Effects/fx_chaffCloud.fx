[Library Effect]
Lifetime=5
Version=2.00
Display Name=Chaff Cloud
Radius=25
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.40, 0.50
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=50.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-15.00, 15.00
Z Particle Velocity=-15.00, 15.00
X Rotation=-180.00, 180.00
Y Rotation=-180.00, 180.00
Z Rotation=-180.00, 180.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=2.10, 4.10
Type=19
X Scale=0.25, 0.75
Y Scale=0.25, 0.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.40, 0.70
X Offset=-10.00, 10.00
Y Offset=-10.00, 10.00
Z Offset=-10.00, 10.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-180.00, 180.00
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_Chaff.bmp
Bounce=0.00
Color Start=230, 232, 250, 255
Color End=230, 232, 250, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-1.00
uv1=0.75, 0.50
uv2=1.00, 0.25
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.40, 0.50
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=50.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-15.00, 15.00
Z Particle Velocity=-15.00, 15.00
X Rotation=-180.00, 180.00
Y Rotation=-180.00, 180.00
Z Rotation=-180.00, 180.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=2.10, 4.10
Type=19
X Scale=0.25, 0.75
Y Scale=0.25, 0.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.40, 0.70
X Offset=-10.00, 10.00
Y Offset=-10.00, 10.00
Z Offset=-10.00, 10.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-180.00, 180.00
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_Chaff.bmp
Bounce=0.00
Color Start=230, 232, 250, 255
Color End=230, 232, 250, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-1.00
uv1=0.75, 0.50
uv2=1.00, 0.25
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.40, 0.50
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=100.00, 150.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-15.00, 15.00
Z Particle Velocity=-15.00, 15.00
X Rotation=-180.00, 180.00
Y Rotation=-180.00, 180.00
Z Rotation=-180.00, 180.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=2.10, 4.10
Type=19
X Scale=0.25, 0.75
Y Scale=0.25, 0.75
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-1.00, -1.00
Color Rate=0.40, 0.70
X Offset=-10.00, 10.00
Y Offset=-10.00, 10.00
Z Offset=-10.00, 10.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-180.00, 180.00
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_Chaff.bmp
Bounce=0.00
Color Start=230, 232, 250, 255
Color End=230, 232, 250, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-2.00
uv1=0.75, 0.50
uv2=1.00, 0.25
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.20, 0.25
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=20.00, 21.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-15.00, 15.00
Z Particle Velocity=-15.00, 15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=10.00, 12.50
Type=19
X Scale=15.00, 15.00
Y Scale=15.00, 15.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.20
Y Scale Rate=0.10, 0.20
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.06
Fade Out=0.40, 0.45
Rotation=-50.00, 50.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=230, 230, 230, 255
Color End=200, 200, 200, 150
Jitter Distance=0.05
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=8.00
Y Scale Goal=8.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.25, 0.25
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=6.00, 7.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-15.00, 15.00
Z Particle Velocity=-15.00, 15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=10.00, 12.50
Type=19
X Scale=17.00, 17.00
Y Scale=17.00, 17.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.20
Y Scale Rate=0.10, 0.20
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.95, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.06
Fade Out=0.50, 0.55
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=230, 230, 230, 255
Color End=200, 200, 200, 150
Jitter Distance=0.05
Jitter Time=1.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=8.00
Y Scale Goal=8.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.10, 0.12
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=10.00, 12.50
Type=19
X Scale=5.00, 8.00
Y Scale=5.00, 8.00
Z Scale=0.00, 0.00
X Scale Rate=6.00, 8.00
Y Scale Rate=6.00, 8.00
Z Scale Rate=0.00, 0.00
Drag=-2.00, -1.95
Color Rate=0.50, 0.80
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.10, 0.15
Fade Out=0.50, 0.52
Rotation=0.00, 0.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_1.bmp
Bounce=1.00
Color Start=230, 230, 230, 255
Color End=200, 200, 200, 150
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.50, 0.50
uv2=0.75, 0.75
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6]
Lifetime=0.20, 0.20
Delay=2.00, 2.00
Bounce=0.00
No Interpolate=1
Rate=200.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=-3.00, -3.00
X Particle Velocity=-15.00, 15.00
Y Particle Velocity=-10.00, 10.00
Z Particle Velocity=-15.00, 15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=10.00, 12.50
Type=19
X Scale=0.10, 0.30
Y Scale=0.10, 0.30
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.10, 0.20
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-500.00, 500.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.6]
Blend Mode=1
Texture=fx_3.bmp
Bounce=0.00
Color Start=230, 230, 230, 255
Color End=200, 200, 200, 150
Jitter Distance=0.00
Jitter Time=0.00
TempK=75.00
TempRate=-0.01
uv1=0.25, 0.75
uv2=0.38, 0.88
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


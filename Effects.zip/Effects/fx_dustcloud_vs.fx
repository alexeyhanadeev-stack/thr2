[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.10, 0.12
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.01
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=2.50, 3.00
Y Particle Velocity=-1.00, 1.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=0.50, 0.55
Type=19
X Scale=0.75, 0.85
Y Scale=0.75, 0.85
Z Scale=0.00, 0.00
X Scale Rate=30.00, 31.50
Y Scale Rate=30.00, 31.50
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.80, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.06
Fade Out=0.40, 0.45
Rotation=-50.00, 50.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=173, 148, 99, 200
Color End=95, 69, 35, 0
Jitter Distance=0.01
Jitter Time=2.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.30, 0.35
Delay=0.00, 0.00
Bounce=0.00
Rate=10.00, 12.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-2.00, 2.00
Y Particle Velocity=2.00, 2.20
Z Particle Velocity=-2.00, 2.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=3.50, 4.00
Type=19
X Scale=1.00, 1.15
Y Scale=1.00, 1.15
Z Scale=0.00, 0.00
X Scale Rate=20.00, 42.50
Y Scale Rate=20.00, 42.50
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.95, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.12
Fade Out=0.50, 0.55
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=125, 104, 85, 150
Color End=125, 106, 79, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=108.00
TempRate=-0.01
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

// fx_flareCountermeasureEffect (Longer, 2x size)
[Emitter.0]
Lifetime=90.00, 110.00
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=20.00, 30.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=0.20, 0.30
Type=19
X Scale=6.00, 8.00
Y Scale=6.00, 8.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.50, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-20.00, 20.00
Static=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=255, 100, 100, 255
Color End=240, 0, 0, 255
Jitter Distance=0.05
Jitter Time=0.00
TempK=100.00
TempRate=0.01
uv1=0.00, 0.00
uv2=0.50, 0.50
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

// fx_smoke_w pieces
[Emitter.1]
Lifetime=30.00, 30.00
Delay=0.00, 0.00
Bounce=0.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=4.00, 12.00
Type=19
X Scale=0.25, 0.38
Y Scale=0.25, 0.38
Z Scale=0.00, 0.00
X Scale Rate=5.00, 10.00
Y Scale Rate=5.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-999.00, -999.00
Color Rate=0.33, 0.45
X Offset=-0.25, 0.25
Y Offset=-0.25, 0.25
Z Offset=-0.50, 0.50
Fade In=0.05, 0.05
Fade Out=0.55, 0.57
Rotation=-100.00, 100.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=213, 213, 213, 70
Color End=254, 254, 254, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=135.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=30.00, 30.00
Delay=0.00, 0.00
Bounce=0.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=4.00, 12.00
Type=19
X Scale=0.25, 0.38
Y Scale=0.25, 0.38
Z Scale=0.00, 0.00
X Scale Rate=5.00, 10.00
Y Scale Rate=5.00, 10.00
Z Scale Rate=0.00, 0.00
Drag=-999.00, -999.00
Color Rate=0.33, 0.45
X Offset=-0.25, 0.25
Y Offset=-0.25, 0.25
Z Offset=-0.50, 0.50
Fade In=0.05, 0.05
Fade Out=0.55, 0.57
Rotation=-100.00, 100.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=213, 213, 213, 70
Color End=254, 254, 254, 0
Jitter Distance=0.05
Jitter Time=1.00
TempK=135.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

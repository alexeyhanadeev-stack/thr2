[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=1

[Properties]

[Emitter.0]
Lifetime=1.00, 1.50
Delay=0.00, 0.00
Bounce=1.00
Rate=90.00, 110.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -4.00
Z Particle Velocity=-9.00, -8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.35, -0.35
Z Offset=-3.30, -3.30
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=1.20, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=3.00, 3.00
Y Scale Rate=3.00, 3.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-50.00, 40.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 30
Color End=70, 70, 70, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=4.00
Y Scale Goal=4.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=1.20, 1.60
Delay=0.00, 0.00
Bounce=1.00
Rate=70.00, 85.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -4.00
Z Particle Velocity=-9.00, -8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.35, -0.35
Z Offset=-3.30, -3.30
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=1.60, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=3.00, 3.00
Y Scale Rate=3.00, 3.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.70, 0.70
Rotation=-60.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 30
Color End=70, 70, 70, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=4.00
Y Scale Goal=4.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=4.00, 5.00
Delay=0.50, 0.70
Bounce=1.00
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -4.00
Z Particle Velocity=-9.00, -8.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.35, -0.35
Z Offset=-3.30, -3.30
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=1.80, 2.00
Type=19
X Scale=0.20, 0.25
Y Scale=0.20, 0.25
Z Scale=0.00, 0.00
X Scale Rate=3.00, 4.00
Y Scale Rate=3.00, 4.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.50, 0.51
Fade Out=0.60, 0.65
Rotation=-60.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=70, 70, 70, 70
Color End=90, 90, 90, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=8.00
Y Scale Goal=8.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=2.00, 2.30
Delay=0.90, 0.90
Bounce=1.00
Rate=70.00, 90.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -5.00
Z Particle Velocity=-9.00, -9.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.35, -0.35
Z Offset=-3.30, -3.30
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=0.16, 0.18
Type=19
X Scale=1.00, 1.50
Y Scale=1.00, 1.50
Z Scale=0.00, 0.00
X Scale Rate=-3.00, -3.00
Y Scale Rate=-3.00, -3.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-50.00, 40.00
Static=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=2
Texture=fx_c130_1.bmp
Bounce=0.00
Color Start=20, 20, 70, 10
Color End=20, 20, 70, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=2.00, 2.30
Delay=0.80, 0.80
Bounce=1.00
Rate=90.00, 110.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -5.00
Z Particle Velocity=-9.00, -9.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.45, -0.45
Z Offset=-3.40, -3.40
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=0.10, 0.14
Type=19
X Scale=0.85, 1.00
Y Scale=0.85, 1.00
Z Scale=0.00, 0.00
X Scale Rate=-3.00, -3.00
Y Scale Rate=-3.00, -3.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-60.00, 60.00
Static=1
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_c130_1.bmp
Bounce=0.00
Color Start=70, 70, 20, 10
Color End=70, 70, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=2.00, 2.30
Delay=0.85, 0.85
Bounce=1.00
Rate=80.00, 100.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-5.00, -5.00
Z Particle Velocity=-9.00, -9.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-0.55, -0.55
Z Offset=-3.50, -3.50
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=0.12, 0.15
Type=19
X Scale=0.65, 0.75
Y Scale=0.65, 0.75
Z Scale=0.00, 0.00
X Scale Rate=-3.00, -3.00
Y Scale Rate=-3.00, -3.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-50.00, 40.00
Static=1
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=2
Texture=fx_c130_1.bmp
Bounce=0.00
Color Start=70, 20, 20, 110
Color End=70, 20, 20, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.20
Y Scale Goal=0.20
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0
[Sound]
FileName=SFX_AK47.wav
MinAttenuationDistance=10.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.10, 0.20
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=10.00, 20.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.20
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-0.20, 0.20
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=1.00, 1.50
Type=19
X Scale=0.10, 0.25
Y Scale=0.10, 0.25
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.15
Y Scale Rate=0.10, 0.15
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.20, 0.30
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.50, 0.70
Rotation=-20.00, 20.00
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=88, 85, 78, 50
Color End=78, 78, 78, 0
Jitter Distance=0.00
Jitter Time=0.00
TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.05, 0.10
Delay=0.00, 0.00
Bounce=0.00
No Interpolate=1
Rate=5.00, 1000.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=0.05, 0.05
Type=19
X Scale=0.03, 0.06
Y Scale=0.03, 0.06
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.60, 1.00
X Offset=-0.05, 0.05
Y Offset=-0.05, 0.05
Z Offset=0.00, 0.20
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Static=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=2
Texture=fx_fireAdd.bmp
Bounce=0.00
Color Start=179, 102, 45, 255
Color End=0, 0, 0, 0
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.00, 0.00
uv2=1.00, 1.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.50, 0.50
Delay=0.00, 0.00
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.15, 0.15
Type=27
X Scale=3.00, 3.00
Y Scale=0.00, 0.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Face=0, 0, 0

[ParticleAttributes.2]
Color Start=30, 22, 20, 140
Color End=30, 22, 20, 140
Bounce=0.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Falloff Exponent=2.00
Inner Cone Angle=20.00
Outer Cone Angle=30.00
Intensity Day=450.00
Intensity Night=450.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=1

[Properties]

[Emitter.0]
Lifetime=5.00, 7.00
Delay=2.00, 3.00
Bounce=1.00
Rate=120.00, 130.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-20.00, -15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.20, -3.20
Z Offset=-1.00, -1.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=1.20, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=4.00, 5.00
Y Scale Rate=4.00, 5.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-50.00, 40.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 50
Color End=20, 20, 20, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=6.00, 8.50
Delay=4.80, 5.90
Bounce=1.00
Rate=90.00, 95.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-23.00, -17.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.20, -3.20
Z Offset=-1.00, -1.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=1.10, 1.90
Type=19
X Scale=0.35, 0.39
Y Scale=0.35, 0.39
Z Scale=0.00, 0.00
X Scale Rate=4.00, 4.00
Y Scale Rate=4.00, 4.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-20.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 60
Color End=20, 20, 20, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=7.00, 9.00
Delay=5.00, 7.00
Bounce=1.00
No Interpolate=1
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-19.00, -18.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.20, -3.20
Z Offset=-3.00, -3.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=2.00, 3.00
Type=19
X Scale=0.40, 0.45
Y Scale=0.40, 0.45
Z Scale=0.00, 0.00
X Scale Rate=3.00, 4.00
Y Scale Rate=3.00, 4.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.50, 0.51
Fade Out=0.60, 0.65
Rotation=-60.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=40, 40, 40, 40
Color End=50, 50, 50, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=12.00
Y Scale Goal=12.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=3.00, 5.20
Delay=0.00, 0.00
Bounce=1.00
Rate=120.00, 130.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-20.00, -15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.50, -3.50
Z Offset=-2.00, -2.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=1.20, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=4.00, 5.00
Y Scale Rate=4.00, 5.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-50.00, 40.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=220, 220, 220, 90
Color End=220, 220, 220, 30
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=5.00, 7.00
Delay=2.00, 3.00
Bounce=1.00
Rate=120.00, 130.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-20.00, -15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.80, -3.80
Z Offset=-1.00, -1.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=1.20, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=4.00, 5.00
Y Scale Rate=4.00, 5.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-50.00, 40.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 50
Color End=20, 20, 20, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=6.00, 8.50
Delay=4.80, 5.90
Bounce=1.00
Rate=90.00, 95.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-23.00, -17.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.80, -3.80
Z Offset=-1.00, -1.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=1.10, 1.90
Type=19
X Scale=0.35, 0.39
Y Scale=0.35, 0.39
Z Scale=0.00, 0.00
X Scale Rate=4.00, 4.00
Y Scale Rate=4.00, 4.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-20.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=10, 10, 10, 60
Color End=20, 20, 20, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6]
Lifetime=7.00, 9.00
Delay=5.00, 7.00
Bounce=1.00
No Interpolate=1
Rate=40.00, 60.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-19.00, -18.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-3.80, -3.80
Z Offset=-3.00, -3.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=2.00, 3.00
Type=19
X Scale=0.40, 0.45
Y Scale=0.40, 0.45
Z Scale=0.00, 0.00
X Scale Rate=3.00, 4.00
Y Scale Rate=3.00, 4.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.50, 0.51
Fade Out=0.60, 0.65
Rotation=-60.00, 60.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.6]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=40, 40, 40, 40
Color End=50, 50, 50, 10
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=12.00
Y Scale Goal=12.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.7]
Lifetime=3.00, 5.20
Delay=0.00, 0.00
Bounce=1.00
Rate=120.00, 130.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=-1.00, -1.00
Z Particle Velocity=-20.00, -15.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=-4.20, -4.20
Z Offset=-2.00, -2.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.7]
Lifetime=1.20, 2.00
Type=19
X Scale=0.30, 0.35
Y Scale=0.30, 0.35
Z Scale=0.00, 0.00
X Scale Rate=4.00, 5.00
Y Scale Rate=4.00, 5.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.10, 1.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.01
Fade Out=0.90, 0.95
Rotation=-50.00, 40.00
Shade=1
Face=1, 0, 1

[ParticleAttributes.7]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=220, 220, 220, 90
Color End=220, 220, 220, 30
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-0.03
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=6.00
Y Scale Goal=6.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=20.00
Rate=110.00, 120.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-70.00, -70.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00

[Particle.0]
Lifetime=3.20, 3.80
Type=19
X Scale=1.00, 1.62
Y Scale=1.00, 1.62
Z Scale=3.00, 4.00
X Scale Rate=0.50, 1.00
Y Scale Rate=0.50, 1.00
Z Scale Rate=0.00, 0.00
Drag=-4.00, -3.98
Color Rate=0.35, 0.47
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=3.11, 3.75
Rotation=-130.00, 140.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=80, 75, 60, 4
Color End=70, 75, 80, 0
Jitter Distance=0.00
Jitter Time=1.00
TempK=106.00
TempRate=-0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=2.30
Y Scale Goal=2.30
Z Scale Goal=2.30
Extrude Length=3.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

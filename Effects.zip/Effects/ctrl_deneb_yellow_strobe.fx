[Library Effect] 
Lifetime=5 
Version=1.00 
Radius=200

Priority=0
 
[controller.0]
lifetime=0.0, 0.0 
type=3 
distance=10000.00, 10000.00
delay=10000000.00, 10000000.00
x offset=0.00, 0.00  
y offset=0.00, 0.00  
z offset=0.00, 0.00
effect.0=fx_deneb_yellow_strobe, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00

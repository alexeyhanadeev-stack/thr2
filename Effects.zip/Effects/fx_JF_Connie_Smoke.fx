[Library Effect]
Lifetime=5
Display Name=JF_Connie_Smoke
Version=1.00
Radius=-1
Priority=0

[Emitter.0]
Lifetime=0.00, 0.00
Delay=7.00, 7.50
Bounce=0.00
Rate=200.00, 200.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-50.00, -50.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00

[Particle.0]
Lifetime=1.50, 2.40
Type=19
X Scale=0.50, 0.80
Y Scale=0.50, 0.80
Z Scale=3.00, 3.50
X Scale Rate=0.50, 0.60
Y Scale Rate=0.50, 0.60
Z Scale Rate=0.10, 0.20
Drag=-4.00, -3.98
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.60, 0.65 
Rotation=-180.00, 180.00
Shade=1
Face=0,0,1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=    75,     75,     75,      11
Color End=      75,     75,     75,      0
Jitter Distance=0.00
Jitter Time=1.00
TempK=107.00
TempRate=0.01
uv1=0.50, 0.75
uv2=0.75, 1.00
X Scale Goal=2.00
Y Scale Goal=1.20
Z Scale Goal=1.00
Extrude Length=3.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00



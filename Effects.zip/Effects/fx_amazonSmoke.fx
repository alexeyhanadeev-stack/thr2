[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=3.00, 8.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=12.00, 15.00
Type=19
X Scale=3.00, 5.00
Y Scale=3.00, 5.00
Z Scale=0.00, 0.00
X Scale Rate=0.05, 0.20
Y Scale Rate=0.05, 0.20
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.02, 0.05
Fade Out=0.60, 0.80
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=105, 105, 90, 50
Color End=148, 148, 131, 150
Jitter Distance=0.03
Jitter Time=0.30
TempK=112.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=100.00
Y Scale Goal=100.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=3.00, 8.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 2.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=12.00, 15.00
Type=19
X Scale=2.00, 4.00
Y Scale=2.00, 4.00
Z Scale=0.00, 0.00
X Scale Rate=0.05, 0.20
Y Scale Rate=0.05, 0.20
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.50
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.02, 0.05
Fade Out=0.60, 0.80
Rotation=-20.00, 20.00
Shade=1
Cast Shadow=1
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=164, 163, 151, 50
Color End=190, 190, 190, 50
Jitter Distance=0.03
Jitter Time=0.30
TempK=112.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=100.00
Y Scale Goal=100.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


[Library Effect]
Lifetime=5
Version=2.00
Radius=-1
Priority=0

[Sound]
FileName=Rocket02.wav
MinAttenuationDistance=1000.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=150.00, 250.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=-500.00, 500.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=10.00, 15.00
Type=19
X Scale=0.50, 1.00
Y Scale=0.50, 1.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=-0.04, -0.03
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.10, 0.15
Rotation=-10.00, 10.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=235, 235, 235, 50
Color End=255, 255, 255, 0
Jitter Distance=0.03
Jitter Time=0.30
TempK=106.99
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=3.00
Y Scale Goal=3.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


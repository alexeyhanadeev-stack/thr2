[Library Effect]
Lifetime=5
Version=2.00
Display Name=fw_red sphere
Radius=125
Priority=0
[Sound]
FileName=firework
MinAttenuationDistance=300.00
Looping=FALSE

[Properties]

[Emitter.0]
Lifetime=0.10, 0.10
Delay=1.40, 1.40
Bounce=0.00
Rate=122.00, 122.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=3.00, 3.00
Type=19
X Scale=80.00, 100.00
Y Scale=80.00, 100.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.20
Y Scale Rate=0.20, 0.20
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.20, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 0, 1

[ParticleAttributes.0]
Blend Mode=2
Texture=fx_fw1.bmp
Bounce=0.00
Color Start=255, 0, 0, 255
Color End=0, 0, 0, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-3.00
uv1=0.50, 0.50
uv2=1.00, 1.00
X Scale Goal=40.50
Y Scale Goal=40.50
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.1]
Lifetime=0.16, 0.18
Delay=0.06, 0.07
Bounce=0.00
Rate=5.00, 6.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.01
X Particle Velocity=-1.00, 1.00
Y Particle Velocity=-1.00, 1.00
Z Particle Velocity=-1.00, 1.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.1]
Lifetime=8.00, 11.50
Type=19
X Scale=22.00, 23.00
Y Scale=22.00, 23.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.20
Y Scale Rate=0.20, 0.20
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.33, 0.66
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.15, 0.15
Fade Out=0.20, 0.30
Rotation=-10.00, 10.00
Face=1, 0, 1

[ParticleAttributes.1]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=192, 125, 63, 80
Color End=49, 49, 49, 255
Jitter Distance=0.03
Jitter Time=2.00
TempK=110.00
TempRate=-0.10
uv1=0.50, 0.50
uv2=0.00, 1.00
X Scale Goal=200.00
Y Scale Goal=200.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.2]
Lifetime=0.10, 0.12
Delay=0.00, 0.00
Bounce=0.00
Light=1
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.2]
Lifetime=0.10, 0.10
Type=19
X Scale=10.00, 10.00
Y Scale=10.00, 10.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.40, 0.90
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-20.00, 20.00
Face=1, 0, 1

[ParticleAttributes.2]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=218, 198, 116, 255
Color End=227, 217, 183, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=0.00
uv1=0.75, 0.00
uv2=1.00, 0.25
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.3]
Lifetime=0.15, 0.16
Delay=0.00, 0.00
Bounce=0.00
Rate=5.00, 6.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.3]
Lifetime=6.00, 8.50
Type=19
X Scale=15.00, 27.00
Y Scale=15.00, 27.00
Z Scale=0.00, 0.00
X Scale Rate=0.10, 0.10
Y Scale Rate=0.10, 0.10
Z Scale Rate=0.00, 0.00
Drag=-1.00, -0.98
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.15, 0.15
Fade Out=0.20, 0.25
Rotation=-12.00, 12.00
Face=1, 0, 1

[ParticleAttributes.3]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=151, 141, 104, 100
Color End=105, 105, 105, 0
Jitter Distance=0.03
Jitter Time=2.00
TempK=109.00
TempRate=-0.01
uv1=0.50, 0.50
uv2=0.00, 1.00
X Scale Goal=200.00
Y Scale Goal=200.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.4]
Lifetime=0.10, 0.10
Delay=1.40, 1.40
Bounce=0.00
Rate=61.00, 61.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.4]
Lifetime=3.00, 3.00
Type=19
X Scale=80.00, 100.00
Y Scale=80.00, 100.00
Z Scale=0.00, 0.00
X Scale Rate=0.30, 0.30
Y Scale Rate=0.30, 0.30
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.20, 0.70
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=0.00, 0.00
Face=1, 0, 1

[ParticleAttributes.4]
Blend Mode=2
Texture=fx_FW2.bmp
Bounce=0.00
Color Start=255, 255, 255, 255
Color End=0, 0, 0, 255
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.00
TempRate=-3.00
uv1=0.50, 0.50
uv2=0.98, 0.98
X Scale Goal=40.50
Y Scale Goal=40.50
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.5]
Lifetime=0.10, 0.12
Delay=0.00, 0.00
Bounce=0.00
Light=1
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.5]
Lifetime=0.10, 0.10
Type=19
X Scale=200.00, 200.00
Y Scale=200.00, 200.00
Z Scale=0.00, 0.00
X Scale Rate=0.00, 0.00
Y Scale Rate=0.00, 0.00
Z Scale Rate=0.00, 0.00
Drag=0.00, 0.00
Color Rate=0.40, 0.90
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Rotation=-20.00, 20.00
Face=1, 0, 1

[ParticleAttributes.5]
Blend Mode=2
Texture=fx_2.bmp
Bounce=0.00
Color Start=218, 198, 116, 255
Color End=227, 217, 183, 255
Jitter Distance=0.00
Jitter Time=0.00
uv1=0.75, 0.00
uv2=1.00, 0.25
X Scale Goal=2.00
Y Scale Goal=2.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00

[Emitter.6]
Lifetime=0.50, 0.50
Delay=1.40, 1.40
Bounce=0.00
Rate=1.00, 1.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=0.00, 0.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=0.00, 0.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.6]
Lifetime=1.50, 1.50
Type=27
X Scale=500.00, 500.00
Y Scale=0.00, 0.00
Z Scale=0.00, 0.00
X Scale Rate=0.01, 0.01
Y Scale Rate=0.01, 0.01
Z Scale Rate=0.01, 0.01
Drag=0.00, 0.00
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.00, 0.00
Fade Out=0.00, 0.00
Static=1
Face=0, 0, 0

[ParticleAttributes.6]
Color Start=255, 0, 0, 130
Color End=255, 0, 0, 130
Bounce=0.00
X Scale Goal=0.00
Y Scale Goal=0.00
Z Scale Goal=0.00
Falloff Exponent=2.00
Inner Cone Angle=0.00
Outer Cone Angle=0.00


//Based on FW_show1
[Library Effect]
Lifetime=5
Version=1.00
Radius=200
Priority=0

[controller.0]
lifetime=0.00, 0.00 
type=0 
delay=10.00, 50.00 
x offset=0.00, 0.00  
y offset=0.00, 0.00  
z offset=0.00, 0.00
random count=0, 0  
effect.0=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 10.00, 30.00
effect.1=fx_Orbx_ShellBlasts_Effect, 150.00, 0.00, 150.00, 300.00, 0.00, 300.00, 20.00, 70.00
effect.2=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 5.00, 10.00
effect.3=fx_Orbx_ShellBlasts_Effect, 150.00, 0.00, 150.00, 300.00, 0.00, 300.00, 1.00, 3.00  
effect.4=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 0.00, 7.00
effect.5=fx_Orbx_ShellBlasts_Effect, 150.00, 0.00, 150.00, 300.00, 0.00, 300.00, 8.00, 20.00
effect.6=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 2.00, 10.00
effect.7=fx_Orbx_ShellBlasts_Effect, 150.00, 0.00, 150.00, 300.00, 0.00, 300.00, 10.00, 30.00
effect.8=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 1.00, 3.00 
effect.9=fx_Orbx_ShellBlasts_Effect, 150.00, 0.00, 150.00, 300.00, 0.00, 300.00, 0.00, 1.00
effect.10=fx_Orbx_ShellBlasts_Effect, 100.00, 0.00, 100.00, 200.00, 0.00, 200.00, 4.00, 5.00 

[Library Effect]
Lifetime=5
Version=2.00
Display Name=water steam, FSX version
Radius=10000
Priority=0

[Properties]

[Emitter.0]
Lifetime=0.00, 0.00
Delay=0.00, 0.00
Bounce=0.00
Rate=5.00, 10.00
X Emitter Velocity=0.00, 0.00
Y Emitter Velocity=0.00, 0.00
Z Emitter Velocity=0.00, 0.00
Drag=0.00, 0.00
X Particle Velocity=-5.00, 5.00
Y Particle Velocity=0.00, 0.00
Z Particle Velocity=-5.00, 5.00
X Rotation=0.00, 0.00
Y Rotation=0.00, 0.00
Z Rotation=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Pitch=0.00, 0.00
Bank=0.00, 0.00
Heading=0.00, 0.00

[Particle.0]
Lifetime=8.00, 12.00
Type=19
X Scale=40.00, 64.00
Y Scale=40.00, 64.00
Z Scale=0.00, 0.00
X Scale Rate=0.20, 0.20
Y Scale Rate=0.20, 0.20
Z Scale Rate=0.00, 0.00
Drag=-0.50, -0.40
Color Rate=0.00, 0.00
X Offset=0.00, 0.00
Y Offset=0.00, 0.00
Z Offset=0.00, 0.00
Fade In=0.05, 0.05
Fade Out=0.80, 0.80
Rotation=-30.00, 30.00
Shade=1
Face=1, 1, 1

[ParticleAttributes.0]
Blend Mode=1
Texture=fx_1.bmp
Bounce=0.00
Color Start=218, 218, 218, 50
Color End=226, 226, 226, 50
Jitter Distance=0.00
Jitter Time=0.00
TempK=108.50
//TempK=107.00
TempRate=0.00
uv1=0.00, 0.50
uv2=0.50, 1.00
X Scale Goal=100.00
Y Scale Goal=100.00
Z Scale Goal=0.00
Extrude Length=0.00
Extrude Pitch Max=0.00
Extrude Heading Max=0.00


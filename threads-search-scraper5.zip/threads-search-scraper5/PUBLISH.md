# How to upload & publish on Apify

1. Install Apify CLI: `npm install -g apify-cli` (or see Apify docs)
2. `apify login`
3. `cd threads-search-scraper`
4. `apify push` (creates/updates the Actor)
5. In Console: run with `examples/input.json`
6. Verify Dataset rows and Key-Value `RUN_SUMMARY`
7. Store listing: copy README sections; add screenshots of input form + sample dataset
8. Pricing: start with pay-per-result after cost test (100 / 1k items)
9. Submit for Store review if required by current Apify policy

## Known limitations

- Public search only; login wall possible on some IPs
- likes/replies/reposts often null on search result cards
- displayName / avatarUrl often null without opening each post
- Date filters require parseable timestamps
- includeReplies is reserved (not expanded in v1.0)
- Not a UGC-specific classifier — universal search only

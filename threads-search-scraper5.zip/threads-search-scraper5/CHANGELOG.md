# Changelog

## 1.1.1

- Stronger `clean_post_text`: strip search-card chrome
  - leading `N views` / relative time (`14h`, `5d`)
  - trailing `Log in or sign up for Threads...` CTAs
- Based on user-fixed 1.1 archive

## 1.1.0

- Detail enrichment, profile fields, retry/backoff
- schemaVersion 1.1

## 1.0.0

- Initial Apify Actor release

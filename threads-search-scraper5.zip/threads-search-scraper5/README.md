# Threads Search Scraper

Search and extract **public Meta Threads posts** by keywords. Built for [Apify Store](https://apify.com/store): one Actor run accepts search parameters, scrapes the Threads web search feed, deduplicates posts, and writes a structured **Dataset**.

> This is a **standalone Apify Actor**, not a Telegram monitor bot.

## Features

- Keyword / phrase / hashtag search on Threads
- Sort: `recent` or `top` (Threads UI filter)
- `maxResults` and `maxPages` limits
- Optional filters: `fromUser`, date range (`after` / `before`), include/exclude keywords, `minLikes`, `hasMedia`
- Multiple queries in one run (`searchQueries`) with **postId deduplication**
- Structured Dataset output (`schemaVersion: 1.1`)
- Empty search → **successful run**, empty dataset, status `empty` in `RUN_SUMMARY`
- Optional Apify Proxy

## Input

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `searchQuery` | string | — | Main search query |
| `searchQueries` | string[] | — | Extra queries in the same run |
| `sort` | `recent` \| `top` | `recent` | Result ordering |
| `maxResults` | integer | 50 | Max unique posts written |
| `maxPages` | integer | 5 | Scroll depth of the results feed |
| `fromUser` | string | — | Keep only this username (no `@`) |
| `after` / `before` | string | — | ISO date/datetime (UTC); applied when timestamp is known |
| `includeKeywords` | string[] | — | All must appear in text |
| `excludeKeywords` | string[] | — | Any match drops the post |
| `minLikes` | integer | 0 | Applied only if likes are known |
| `hasMedia` | boolean | false | Require extracted media URLs |
| `proxyConfiguration` | object | — | Apify Proxy (optional) |
| `enrichDetails` | boolean | true | Open each post for likes, avatar, media |
| `maxDetailEnrich` | integer | 50 | Cap on detail page opens |
| `debug` | boolean | false | Verbose logs |

Provide **at least one** of `searchQuery` or `searchQueries`.

### Example input

```json
{
  "searchQuery": "UGC creator",
  "sort": "recent",
  "maxResults": 30,
  "maxPages": 4
}
```

## Output (Dataset)

Each item:

```json
{
  "postId": "DfmX2zuifn2",
  "postUrl": "https://www.threads.com/@user/post/DfmX2zuifn2",
  "canonicalUrl": "https://www.threads.com/@user/post/DfmX2zuifn2",
  "text": "Looking for a UGC creator...",
  "timestamp": "2026-11-14T12:30:00Z",
  "username": "user",
  "displayName": null,
  "avatarUrl": null,
  "isVerified": null,
  "likesCount": null,
  "repliesCount": null,
  "repostsCount": null,
  "quotesCount": null,
  "mediaUrls": [],
  "mediaType": null,
  "searchQuery": "UGC creator",
  "scrapedAt": "2026-11-14T16:00:00Z",
  "schemaVersion": "1.1",
  "dataCompleteness": 0.556
}
```

Unavailable fields are `null` or `[]` — **never invented**.

Run summary is stored in Key-Value Store as `RUN_SUMMARY` (counts, per-query status). It is **not** mixed into the Dataset.

## Date filtering note

Threads timestamps are taken from `time[datetime]` when present. `after` / `before` are applied **client-side**. Posts without a parseable timestamp are dropped when a date filter is set.

## Authorization & limits

- Uses **public web search** via Playwright (Chromium).
- No bundled personal cookies or browser profiles.
- Threads may show login walls, rate limits, or sparse results depending on IP/geo. Optional **Apify Proxy** can help.
- This Actor does **not** bypass authentication or anti-bot systems.
- Engagement fields (`likesCount`, etc.) are best-effort; often `null` on search cards.

## Empty results

If the query runs successfully but finds nothing:

- Actor finishes **successfully**
- Dataset stays empty
- `RUN_SUMMARY.status` = `"empty"`

## Local development

```bash
pip install -r requirements.txt
playwright install chromium
# Requires Apify environment or `apify run` from Apify CLI
apify run -p
```

## Publish to Apify Store

1. Install [Apify CLI](https://docs.apify.com/cli)
2. `apify login`
3. From this folder: `apify push`
4. Set pricing (recommend **pay per dataset item** / event after measuring cost)
5. Fill Store description from this README
6. Run the three test scenarios (results / empty / maxResults)

## Pricing (recommendation)

Measure real compute + proxy on 100 / 1 000 unique posts before fixing a Store price. Prefer charging for **unique posts written**, not for empty searches.

## Changelog

See [CHANGELOG.md](./CHANGELOG.md).

## License / ethics

Public data only. Respect Threads Terms and applicable laws. No warranty of uninterrupted access.

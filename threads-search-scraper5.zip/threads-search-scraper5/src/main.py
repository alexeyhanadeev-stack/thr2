"""Apify Actor entrypoint: Threads Search Scraper (enriched)."""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from typing import Any

from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

from .threads_source import (
    enrich_post_detail,
    merge_card_and_detail,
    normalize_record,
    passes_filters,
    post_id,
    scrape_search,
)

try:
    from apify import Actor
except ImportError:
    Actor = None  # type: ignore


def _queries_from_input(inp: dict[str, Any]) -> list[str]:
    queries: list[str] = []
    single = (inp.get("searchQuery") or "").strip()
    if single:
        queries.append(single)
    multi = inp.get("searchQueries") or []
    if isinstance(multi, str):
        multi = [multi]
    for q in multi:
        q = (q or "").strip()
        if q and q not in queries:
            queries.append(q)
    return queries


async def run_actor() -> dict[str, Any]:
    if Actor is None:
        raise RuntimeError("apify package is required to run this Actor")

    async with Actor:
        inp = await Actor.get_input() or {}
        debug = bool(inp.get("debug"))
        if debug:
            Actor.log.info(f"Input: {json.dumps(inp, ensure_ascii=False)[:2000]}")

        queries = _queries_from_input(inp)
        if not queries:
            await Actor.fail(status_message="Provide searchQuery or searchQueries")
            return {"status": "failed", "reason": "missing_query"}

        sort = (inp.get("sort") or "recent").lower()
        if sort not in ("recent", "top"):
            sort = "recent"
        max_results = max(1, min(int(inp.get("maxResults") or 50), 1000))
        max_pages = max(1, min(int(inp.get("maxPages") or 5), 20))
        # Default ON: open each post for likes/avatar/media (slower, richer)
        enrich_details = inp.get("enrichDetails")
        if enrich_details is None:
            enrich_details = True
        enrich_details = bool(enrich_details)
        max_detail = max(1, min(int(inp.get("maxDetailEnrich") or max_results), 200))

        filter_opts = {
            "fromUser": inp.get("fromUser"),
            "after": inp.get("after"),
            "before": inp.get("before"),
            "includeKeywords": inp.get("includeKeywords") or [],
            "excludeKeywords": inp.get("excludeKeywords") or [],
            "minLikes": inp.get("minLikes") or 0,
            "hasMedia": bool(inp.get("hasMedia")),
        }

        proxy_cfg = inp.get("proxyConfiguration") or {}
        proxy_url = None
        if proxy_cfg.get("useApifyProxy"):
            try:
                proxy_conf = await Actor.create_proxy_configuration(
                    actor_proxy_input=proxy_cfg
                )
                if proxy_conf:
                    proxy_url = await proxy_conf.new_url()
            except Exception as exc:
                Actor.log.warning(f"Proxy setup failed, continuing without: {exc}")

        seen_ids: set[str] = set()
        written = 0
        duplicates = 0
        filtered_out = 0
        errors = 0
        raw_total = 0
        enriched_ok = 0
        query_stats: list[dict[str, Any]] = []

        launch_args: dict[str, Any] = {"headless": True}
        if proxy_url:
            launch_args["proxy"] = {"server": proxy_url}

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(**launch_args)
            context = await browser.new_context(
                locale="en-US",
                viewport={"width": 1280, "height": 900},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/121.0.0.0 Safari/537.36"
                ),
            )
            page = await context.new_page()

            for q in queries:
                if written >= max_results:
                    break
                q_raw = 0
                q_written = 0
                q_status = "success"
                try:
                    raw_items = await scrape_search(
                        page,
                        q,
                        sort=sort,
                        max_pages=max_pages,
                        per_page_limit=40,
                        log=Actor.log,
                        retries=3,
                    )
                    q_raw = len(raw_items)
                    raw_total += q_raw

                    for raw in raw_items:
                        if written >= max_results:
                            break
                        pid = post_id(raw.get("url") or "")
                        if not pid:
                            filtered_out += 1
                            continue
                        if pid in seen_ids:
                            duplicates += 1
                            continue

                        merged = dict(raw)
                        if enrich_details and enriched_ok + (written - enriched_ok) < max_detail:
                            # enrich up to max_detail posts per run
                            if written < max_detail:
                                detail = await enrich_post_detail(
                                    page, raw.get("url") or "", log=Actor.log, retries=2
                                )
                                merged = merge_card_and_detail(raw, detail)
                                if detail.get("detailEnriched"):
                                    enriched_ok += 1

                        row = normalize_record(merged, q)
                        if not passes_filters(row, filter_opts):
                            filtered_out += 1
                            continue
                        if not row.get("postId") or not row.get("postUrl"):
                            filtered_out += 1
                            continue

                        seen_ids.add(pid)
                        await Actor.push_data(row)
                        written += 1
                        q_written += 1

                    if q_written == 0 and q_raw == 0:
                        q_status = "empty"
                except PlaywrightTimeoutError:
                    errors += 1
                    q_status = "timeout"
                    Actor.log.warning(f"Timeout while searching: {q}")
                except Exception as exc:
                    errors += 1
                    q_status = "error"
                    Actor.log.exception(f"Search failed for '{q}': {exc}")

                query_stats.append(
                    {
                        "query": q,
                        "raw": q_raw,
                        "written": q_written,
                        "status": q_status,
                    }
                )

            await context.close()
            await browser.close()

        if written == 0 and errors == 0:
            status = "empty"
        elif written == 0 and errors > 0:
            status = "failed"
        else:
            status = "success"

        summary = {
            "status": status,
            "queries": len(queries),
            "rawTotal": raw_total,
            "uniqueWritten": written,
            "duplicatesSkipped": duplicates,
            "filteredOut": filtered_out,
            "detailEnriched": enriched_ok,
            "errors": errors,
            "sort": sort,
            "enrichDetails": enrich_details,
            "queryStats": query_stats,
            "finishedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "schemaVersion": "1.1",
        }
        await Actor.set_value("RUN_SUMMARY", summary)
        Actor.log.info(f"Run summary: {json.dumps(summary, ensure_ascii=False)}")

        if status == "failed":
            await Actor.fail(
                status_message=f"No results and {errors} error(s). See logs."
            )
        return summary


def main() -> None:
    try:
        asyncio.run(run_actor())
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)


if __name__ == "__main__":
    main()

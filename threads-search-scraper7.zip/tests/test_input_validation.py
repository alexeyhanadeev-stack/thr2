import unittest
import json
from pathlib import Path
from src.main import validate_input
from src.threads_source import (clean_post_text, clean_display_name, clean_media_urls, normalize_record)

class InputValidationTests(unittest.TestCase):

    def test_all_input_properties_have_descriptions(self):
        schema_path = Path(__file__).resolve().parents[1] / ".actor" / "input_schema.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        for name, prop in schema.get("properties", {}).items():
            with self.subTest(property=name):
                self.assertIsInstance(prop.get("description"), str)
                self.assertTrue(prop["description"].strip())

    def test_legacy_search_defaults_to_posts_search(self):
        self.assertEqual(validate_input({'searchQuery': 'hello'})[0], 'posts_search')
    def test_multiple_queries_deduplicate(self):
        self.assertEqual(validate_input({'searchQuery':'x','searchQueries':['x','y']})[1], ['x','y'])
    def test_modes_require_their_inputs(self):
        samples = [
            ({'mode':'user_search','userQuery':'creator'}, 'user_search'),
            ({'mode':'post_details','postUrl':'https://www.threads.com/@a/post/ABC'}, 'post_details'),
            ({'mode':'replies','postUrls':['https://www.threads.com/@a/post/ABC']}, 'replies'),
            ({'mode':'media','postUrls':['https://www.threads.com/@a/post/ABC']}, 'media'),
        ]
        for value, expected in samples:
            self.assertEqual(validate_input(value)[0], expected)

    def test_post_text_removes_threads_ui_but_keeps_body(self):
        raw = """valeriiabarcelona
2.6K views
11/04/26
Шукаю ugc для бренду косметики
Портфоліо обовʼязково
Log in with username instead
© 2026
Threads Terms
Privacy Policy
Consumer Health Privacy Policy
Cookies Policy
Report a problem"""
        self.assertEqual(
            clean_post_text(raw, "valeriiabarcelona"),
            "Шукаю ugc для бренду косметики\nПортфоліо обовʼязково",
        )

    def test_display_name_rejects_generic_title_and_username(self):
        self.assertIsNone(clean_display_name("Thread", "creator"))
        self.assertIsNone(clean_display_name("creator", "creator"))
        self.assertEqual(clean_display_name("Olena Creator", "creator"), "Olena Creator")

    def test_media_filter_drops_avatar_but_keeps_post_media(self):
        avatar = "https://scontent.cdninstagram.com/v/t51.82787-19/avatar.jpg?stp=dst-jpg_e0_s150x150"
        post_image = "https://scontent.cdninstagram.com/v/t51.82787-15/post-image.jpg"
        self.assertEqual(clean_media_urls([avatar, post_image], avatar), [post_image])

    def test_normalized_post_has_consistent_patch_schema(self):
        avatar = "https://cdn.example/avatar.jpg"
        post_image = "https://cdn.example/post.jpg"
        row = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123",
            "author": "creator",
            "displayName": "Thread",
            "avatarUrl": avatar,
            "text": "2.6K views\n11/04/26\nActual post text\nLog in with username instead\n© 2026",
            "mediaUrls": [avatar, post_image],
            "detailEnriched": True,
        }, "test")
        self.assertEqual(row["schemaVersion"], "1.2.3")
        self.assertIsNone(row["displayName"])
        self.assertEqual(row["text"], "Actual post text")
        self.assertEqual(row["mediaUrls"], [post_image])
        self.assertEqual(row["mediaType"], "image")

    def test_rejects_invalid_mode_and_url(self):
        with self.assertRaises(ValueError): validate_input({'mode':'unknown'})
        with self.assertRaises(ValueError): validate_input({'mode':'media','postUrl':'https://example.com/post/1'})

if __name__ == '__main__': unittest.main()

from apify import Actor
async def main():
    async with Actor:
        actor_input = await Actor.get_input() or {}
        query = actor_input.get('searchQuery', 'test')
        await Actor.push_data({"postId": "test123", "text": f"Scraped for {query}", "searchQuery": query})
        await Actor.set_value("RUN_SUMMARY", {"status": "success"})

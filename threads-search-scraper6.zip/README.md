# Threads Scraper: Search, Users, Posts & Media

Universal Apify Actor for extracting data available through public Meta Threads web pages. Select one of five modes: post search, user search, post details, replies, or media metadata/downloads.

> **Access and reliability:** This Actor uses the public Threads website through Playwright. Threads may change its interface, require login, rate-limit requests, hide metrics, or make content unavailable. The Actor does not bypass authentication, private profiles, access controls, or anti-bot protections. Fields unavailable in the public page are returned as `null` or omitted; counts are not inferred as zero.

## Modes

| `mode` | Purpose | Required input |
|---|---|---|
| `posts_search` (default) | Search public posts by keywords/hashtags | `searchQuery` or `searchQueries` |
| `user_search` | Search public profile links surfaced by Threads search and optionally inspect profiles | `userQuery` or `userQueries` |
| `post_details` | Open supplied post URLs and extract available post details | `postUrl` or `postUrls` |
| `replies` | Inspect a post page and collect reply-like public cards exposed in its DOM | `postUrl` or `postUrls` |
| `media` | Extract image/video URLs; optionally download accessible files to the default Key-Value Store | `postUrl` or `postUrls` |

## 1. Posts Search

Legacy-compatible: an input without `mode` is treated as `posts_search`.

```json
{
  "mode": "posts_search",
  "searchQueries": ["UGC creator", "looking for content creator", "#ugc"],
  "sort": "recent",
  "maxResults": 100,
  "maxPages": 10,
  "enrichDetails": true,
  "maxDetailEnrich": 50,
  "includeKeywords": ["creator"],
  "keywordMatchMode": "any",
  "excludeKeywords": ["unpaid"],
  "hasMedia": false
}
```

Existing inputs are retained: `searchQuery`, `searchQueries`, `sort`, `maxResults`, `maxPages`, `fromUser`, `after`, `before`, `includeKeywords`, `excludeKeywords`, `minLikes`, `hasMedia`, `proxyConfiguration`, `debug`, `enrichDetails`, and `maxDetailEnrich`.

Additional filters: `keywordMatchMode` (`all`/`any`), `maxLikes`, `minReplies`, `minReposts`, `minQuotes`, `mediaTypes`, `minTextLength`, and `maxTextLength`. `includeKeywords` defaults to matching **all** supplied terms. Unknown engagement counts are not treated as zero.

`maxPages` means approximate scroll cycles, not a guaranteed number of server-side pages. Search coverage depends on what Threads loads in the public interface.

## 2. User Search

```json
{
  "mode": "user_search",
  "userQueries": ["ugc creator", "beauty blogger"],
  "maxResults": 50,
  "maxPages": 5,
  "enrichProfiles": true,
  "maxProfileEnrich": 30
}
```

Collects public profile links surfaced by the Threads search page and attempts to extract username, display name, profile URL, avatar, bio/description, verification indicator, and visible counts. Search results may expose posts rather than dedicated user results; therefore this mode is best-effort and does not promise a complete user directory. Profile metrics may be unavailable.

## 3. Post Details

```json
{
  "mode": "post_details",
  "postUrls": ["https://www.threads.com/@example/post/ABC123"]
}
```

Opens each supplied public post URL and returns the normalized post structure, with `sourceInputUrl` and `detailFetchStatus`. An inaccessible/deleted post is recorded as an error in `RUN_SUMMARY`; other URLs continue processing.

## 4. Replies

```json
{
  "mode": "replies",
  "postUrls": ["https://www.threads.com/@example/post/ABC123"],
  "maxReplies": 200,
  "maxDepth": 3,
  "includeNestedReplies": true
}
```

Collects reply-like cards visible in the public post DOM and deduplicates them by post, username and text. **Important limitation:** Threads does not consistently expose stable reply IDs, parent-reply relationships, or full nested-reply pagination in its public DOM. In this version `maxDepth` and `includeNestedReplies` are accepted for forward compatibility, but the current extractor only labels visible collected entries at depth 1; it does not guarantee complete recursive thread capture. `replyId`, `parentReplyId`, and reply URLs can be null.

## 5. Media

```json
{
  "mode": "media",
  "postUrls": ["https://www.threads.com/@example/post/ABC123"],
  "downloadMedia": false,
  "mediaTypes": ["image", "video"],
  "maxMediaPerPost": 10,
  "maxMediaSizeMb": 25
}
```

With `downloadMedia: false`, outputs media URLs and metadata only. With downloads enabled, accessible files are stored in the Actor's default Key-Value Store; Dataset rows contain `storageKey`, MIME type, filename and size. Download success depends on URL accessibility, expiry, content type, and file-size limit. Video variants or protected media may not be downloadable. Binary files are not embedded in Dataset rows.

## Common settings

- `proxyConfiguration`: optional Apify Proxy configuration.
- `proxyFailureMode`: `direct` (default) logs proxy setup failure and continues without proxy, or `fail` stops the run.
- `debug`: enables verbose input logging.

## Output

All Dataset records carry `mode`, `recordType`, `scrapedAt` where applicable, and `schemaVersion: "1.2"`. Post records retain the legacy fields (`postId`, `postUrl`, `canonicalUrl`, `text`, `timestamp`, `username`, `displayName`, `avatarUrl`, `isVerified`, engagement counts, `mediaUrls`, `mediaType`, `searchQuery`, `detailEnriched`, `dataCompleteness`). User, reply and media records have mode-specific fields. Unknown data is not fabricated.

Execution statistics are saved to the Key-Value Store as `RUN_SUMMARY`, including status (`success`, `empty`, `partial`, `failed`), timing, counts, errors, query statistics, proxy state, and media download statistics.

## Examples

See `examples/` for one input per mode. `examples/output.json` is illustrative; actual values depend on public page availability.

## Responsible use

Use only public content you are authorized to access. Respect Meta/Threads terms, privacy requirements, copyright, and applicable laws. Do not use this Actor to collect private data, evade access restrictions, or harass users.

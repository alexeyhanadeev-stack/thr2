# Threads Search Scraper & Post Extractor

Extract public **Meta Threads** posts, engagement metrics, author profiles, and media URLs by keywords, phrases, or hashtags. Built for **lead generation, brand monitoring, UGC creator discovery, and social listening**—with batch keyword search, deep filtering, automatic deduplication, and clean structured JSON/CSV/Excel export.

> **No login or personal cookies required.** Collects strictly public Threads web search data at a fraction of the cost of comparable scrapers.

---

## Why Choose This Threads Scraper?

- **Batch Multi-Query Search (`searchQueries`):** Scrape dozens of keywords, hashtags, or niche phrases in a single Actor run with automatic cross-query deduplication by `postId`.
- **Granular Client-Side Filtering:** Filter posts by specific author (`fromUser`), UTC date range (`after` / `before`), required keywords (`includeKeywords`), negative keywords (`excludeKeywords`), minimum likes (`minLikes`), or media presence (`hasMedia`).
- **Rich Post & Profile Enrichment (`enrichDetails`):** Automatically opens post pages to extract exact engagement counts (`likesCount`, `repliesCount`, `repostsCount`, `quotesCount`), author `displayName`, `avatarUrl`, `isVerified` badge, and high-resolution media links.
- **Clean Text Output:** Built-in text sanitizer strips Threads UI noise (such as view counters, relative timestamps, and login prompts) so your dataset contains pure post copy ready for AI analysis or CRM import.
- **Sort by Latest or Top:** Switch seamlessly between `recent` (chronological feed for real-time lead monitoring) and `top` (most relevant/popular posts).

---

## Use Cases

- **B2B & Freelance Lead Generation:** Monitor real-time requests (e.g., *"looking for UGC creator"*, *"need a video editor"*, *"hiring SMM"*) using `sort: "recent"` and keyword filters.
- **Brand & Competitor Monitoring:** Track brand mentions, product reviews, and competitor campaigns across Threads without manual scrolling.
- **Influencer & Creator Discovery:** Find active creators in specific niches, filter by minimum engagement (`minLikes`), and export verified profile links.
- **Market Research & Sentiment Analysis:** Collect clean, deduplicated datasets for LLM pipelines, trend detection, and content research.

---

## Input Parameters

Provide at least one of `searchQuery` or `searchQueries`.

| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `searchQuery` | String | — | Primary keyword, phrase, or hashtag to search (e.g., `"UGC creator"`, `"#AI"`). |
| `searchQueries` | Array | `[]` | List of additional search queries to execute in one run (deduplicated automatically). |
| `sort` | String | `"recent"` | Feed ordering: `"recent"` (newest posts first) or `"top"` (most relevant posts). |
| `maxResults` | Integer | `50` | Maximum number of unique posts saved to the dataset (`1`–`1000`). |
| `maxPages` | Integer | `5` | Scroll depth per query (`1`–`20`). Higher values load older posts. |
| `fromUser` | String | — | Keep only posts published by this username (without `@`). |
| `after` | String | — | Keep posts published on or after this UTC date/datetime (e.g., `"2026-11-01"`). |
| `before` | String | — | Keep posts published before this UTC date/datetime (ISO 8601). |
| `includeKeywords` | Array | `[]` | Post text must contain **all** specified words/phrases (case-insensitive). |
| `excludeKeywords` | Array | `[]` | Skip posts containing **any** of these negative keywords (case-insensitive). |
| `minLikes` | Integer | `0` | Minimum likes threshold (applied when `likesCount` is available). |
| `hasMedia` | Boolean | `false` | If `true`, keeps only posts containing at least one image or video URL. |
| `enrichDetails` | Boolean | `true` | Opens individual posts to extract likes, replies, reposts, avatar, and verified status. |
| `maxDetailEnrich` | Integer | `50` | Maximum number of posts to open for detail enrichment per run (`1`–`200`). |
| `proxyConfiguration` | Object | `{"useApifyProxy": false}` | Optional Apify Proxy settings to avoid geo-blocks or rate limits. |
| `debug` | Boolean | `false` | Enables verbose execution logs for troubleshooting. |

### Example Input

```json
{
  "searchQuery": "UGC creator",
  "searchQueries": ["looking for UGC", "content creator needed"],
  "sort": "recent",
  "maxResults": 50,
  "maxPages": 5,
  "excludeKeywords": ["crypto", "airdrop", "giveaway"],
  "enrichDetails": true,
  "maxDetailEnrich": 50
}
```

---

## Output Dataset Schema

Results are stored in the default Apify Dataset and can be downloaded in **JSON, CSV, Excel (XLSX), XML, or RSS** formats, or fetched via the Apify API.

### Example Output Item

```json
{
  "postId": "DfmX2zuifn2",
  "postUrl": "[https://www.threads.com/@brand_studio/post/DfmX2zuifn2](https://www.threads.com/@brand_studio/post/DfmX2zuifn2)",
  "canonicalUrl": "[https://www.threads.com/@brand_studio/post/DfmX2zuifn2](https://www.threads.com/@brand_studio/post/DfmX2zuifn2)",
  "text": "Looking for a beauty UGC creator for a paid skincare campaign. Drop your portfolio below!",
  "timestamp": "2026-11-16T12:30:00Z",
  "username": "brand_studio",
  "displayName": "Brand Studio Official",
  "avatarUrl": "[https://scontent.cdninstagram.com/](https://scontent.cdninstagram.com/)...",
  "isVerified": true,
  "likesCount": 24,
  "repliesCount": 11,
  "repostsCount": 3,
  "quotesCount": 1,
  "mediaUrls": [
    "[https://scontent.cdninstagram.com/](https://scontent.cdninstagram.com/)..."
  ],
  "mediaType": "image",
  "searchQuery": "UGC creator",
  "scrapedAt": "2026-11-16T13:05:00Z",
  "schemaVersion": "1.1",
  "detailEnriched": true,
  "dataCompleteness": 0.917
}
```

> **Data Integrity Guarantee:** Unavailable metrics or profile fields are explicitly returned as `null` or `[]`—never guessed or fabricated. A detailed execution report (`RUN_SUMMARY`) with per-query statistics is also saved to the Key-Value Store.

---

## FAQ & Best Practices

**1. Do I need a Threads or Instagram account to run this scraper?**  
No. The Actor extracts publicly accessible web search results without requiring authentication or cookies.

**2. Should I enable Apify Proxy?**  
For small runs (`maxResults` under 50), default datacenter IPs usually work out of the box. For high-volume scraping or frequent scheduled runs, enabling **Apify Proxy** is recommended to prevent temporary rate limits or login walls.

**3. How can I make runs faster and cheaper?**  
Set `"enrichDetails": false` if you only need post text, URL, author handle, timestamp, and search-card media. Keep `"enrichDetails": true` when you need exact like/reply counts, avatars, and verified badges.

**4. What happens if a search returns zero posts?**  
The Actor finishes gracefully with status `SUCCEEDED`, writes an empty dataset, and records `"status": "empty"` in `RUN_SUMMARY`.

---

## Legal & Ethical Compliance

This Actor collects **publicly available data** from Meta Threads. It does not bypass login walls, private account restrictions, or anti-bot protections. Users are responsible for complying with Meta's Terms of Service and applicable data privacy laws (such as GDPR and CCPA) when storing or processing extracted data.
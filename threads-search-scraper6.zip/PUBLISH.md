# Publishing / testing on Apify

1. Run local checks: `python -m compileall -q .` and `python -m unittest discover -s tests -v`.
2. Validate all JSON files under `.actor/` and `examples/`.
3. Build/test with Apify CLI in a development Actor before publishing to Store.
4. Test each `mode` independently against public Threads pages. Confirm the actual availability of profile search, reply cards and media URLs in the target environment.
5. Check the Dataset rows and `RUN_SUMMARY` in Key-Value Store. For `media` with `downloadMedia: true`, verify that files appear in the default Key-Value Store and that Dataset `storageKey` values resolve.
6. Verify proxy behavior with both `proxyFailureMode: direct` and `proxyFailureMode: fail`.
7. Confirm legacy input without `mode` still runs `posts_search`.
8. Only after successful Cloud tests, update the Store listing and publish version 1.2.0.

## Important

Local syntax/unit tests do not prove that Threads currently exposes the expected DOM or that Apify Cloud can access it. Live validation is required before making Store claims about complete user discovery, recursive replies, or successful media downloads.

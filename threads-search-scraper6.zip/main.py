# Shim for platforms that look for ./main.py
from src.main import main

if __name__ == "__main__":
    main()

import unittest
import json
from pathlib import Path
from src.main import validate_input
from src.threads_source import (clean_post_text, clean_display_name, clean_media_urls, normalize_record, data_completeness, merge_card_and_detail)

class InputValidationTests(unittest.TestCase):

    def test_all_input_properties_have_descriptions(self):
        schema_path = Path(__file__).resolve().parents[1] / ".actor" / "input_schema.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        for name, prop in schema.get("properties", {}).items():
            with self.subTest(property=name):
                self.assertIsInstance(prop.get("description"), str)
                self.assertTrue(prop["description"].strip())

    def test_legacy_search_defaults_to_posts_search(self):
        self.assertEqual(validate_input({'searchQuery': 'hello'})[0], 'posts_search')
    def test_multiple_queries_deduplicate(self):
        self.assertEqual(validate_input({'searchQuery':'x','searchQueries':['x','y']})[1], ['x','y'])
    def test_modes_require_their_inputs(self):
        samples = [
            ({'mode':'user_search','userQuery':'creator'}, 'user_search'),
            ({'mode':'post_details','postUrl':'https://www.threads.com/@a/post/ABC'}, 'post_details'),
            ({'mode':'replies','postUrls':['https://www.threads.com/@a/post/ABC']}, 'replies'),
            ({'mode':'media','postUrls':['https://www.threads.com/@a/post/ABC']}, 'media'),
        ]
        for value, expected in samples:
            self.assertEqual(validate_input(value)[0], expected)

    def test_post_text_removes_threads_ui_but_keeps_body(self):
        raw = """valeriiabarcelona
2.6K views
11/04/26
Шукаю ugc для бренду косметики
Портфоліо обовʼязково
Log in with username instead
© 2026
Threads Terms
Privacy Policy
Consumer Health Privacy Policy
Cookies Policy
Report a problem"""
        self.assertEqual(
            clean_post_text(raw, "valeriiabarcelona"),
            "Шукаю ugc для бренду косметики\nПортфоліо обовʼязково",
        )

    def test_display_name_rejects_generic_title_and_username(self):
        self.assertIsNone(clean_display_name("Thread", "creator"))
        self.assertIsNone(clean_display_name("creator", "creator"))
        self.assertEqual(clean_display_name("Olena Creator", "creator"), "Olena Creator")

    def test_media_filter_drops_avatar_but_keeps_post_media(self):
        avatar = "https://scontent.cdninstagram.com/v/t51.82787-19/avatar.jpg?stp=dst-jpg_e0_s150x150"
        post_image = "https://scontent.cdninstagram.com/v/t51.82787-15/post-image.jpg"
        self.assertEqual(clean_media_urls([avatar, post_image], avatar), [post_image])

    def test_normalized_post_has_consistent_patch_schema(self):
        avatar = "https://cdn.example/avatar.jpg"
        post_image = "https://cdn.example/post.jpg"
        row = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123",
            "author": "creator",
            "displayName": "Thread",
            "avatarUrl": avatar,
            "text": "2.6K views\n11/04/26\nActual post text\nLog in with username instead\n© 2026",
            "mediaUrls": [avatar, post_image],
            "detailEnriched": True,
        }, "test")
        self.assertEqual(row["schemaVersion"], "1.2.4")
        self.assertIsNone(row["displayName"])
        self.assertEqual(row["text"], "Actual post text")
        self.assertEqual(row["mediaUrls"], [post_image])
        self.assertEqual(row["mediaType"], "image")


    def test_data_completeness_counts_known_empty_media_but_not_unknown_metrics(self):
        base = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123", "author": "creator",
            "text": "A real post", "timestamp": "2026-11-16T12:00:00Z",
            "avatarUrl": "https://cdn.example/avatar.jpg", "mediaUrls": [],
            "detailEnriched": True, "isVerified": False,
        }, "q")
        self.assertGreater(base["dataCompleteness"], 0.55)
        self.assertLess(base["dataCompleteness"], 0.9)
        with_metrics = dict(base, likesCount=12, repliesCount=3, repostsCount=1, quotesCount=0)
        self.assertGreater(data_completeness(with_metrics), base["dataCompleteness"])

    def test_merge_preserves_real_post_media_and_uses_valid_detail_name(self):
        avatar = "https://cdn.example/avatar.jpg"
        image = "https://cdn.example/t51.82787-15/post.jpg"
        merged = merge_card_and_detail(
            {"url":"https://www.threads.com/@creator/post/ABC123", "author":"creator", "mediaUrls":[image], "displayName":None},
            {"avatarUrl":avatar, "mediaUrls":[avatar, image], "displayName":"Olena K.", "detailEnriched":True}
        )
        self.assertEqual(merged["mediaUrls"], [image])
        self.assertEqual(merged["displayName"], "Olena K.")

    def test_rejects_invalid_mode_and_url(self):
        with self.assertRaises(ValueError): validate_input({'mode':'unknown'})
        with self.assertRaises(ValueError): validate_input({'mode':'media','postUrl':'https://example.com/post/1'})

if __name__ == '__main__': unittest.main()

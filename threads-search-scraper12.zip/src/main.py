"""Universal public Threads scraper Actor. Backwards-compatible with v1.1 inputs."""
from __future__ import annotations
import asyncio, json, re, sys, time
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from .threads_source import (enrich_post_detail, merge_card_and_detail, normalize_record,
    passes_filters, post_id, scrape_search, canonical_url, clean_display_name)
try:
    from apify import Actor
except ImportError:
    Actor = None

SCHEMA_VERSION = "1.2.7"

def now_iso(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
def as_list(v): return [v] if isinstance(v, str) else (v or [])
def clamp(v, default, lo, hi):
    try: return max(lo, min(int(v), hi))
    except (TypeError, ValueError): return default

def validate_input(inp: dict[str, Any]) -> tuple[str, list[str]]:
    mode = (inp.get("mode") or "posts_search").strip().lower()
    allowed = {"posts_search", "user_search", "post_details", "replies", "media"}
    if mode not in allowed: raise ValueError(f"Unknown mode '{mode}'. Choose one of: {', '.join(sorted(allowed))}")
    if mode == "posts_search":
        qs = []
        for q in [*as_list(inp.get("searchQuery")), *as_list(inp.get("searchQueries"))]:
            q = str(q or "").strip()
            if q and q not in qs: qs.append(q)
        if not qs: raise ValueError("posts_search requires searchQuery or searchQueries")
    elif mode == "user_search":
        qs=[]
        for q in [*as_list(inp.get("userQuery")), *as_list(inp.get("userQueries"))]:
            q=str(q or "").strip()
            if q and q not in qs: qs.append(q)
        if not qs: raise ValueError("user_search requires userQuery or userQueries")
    else:
        urls=[]
        for u in [*as_list(inp.get("postUrl")), *as_list(inp.get("postUrls"))]:
            u=str(u or "").strip()
            if u and u not in urls: urls.append(u)
        if not urls: raise ValueError(f"{mode} requires postUrl or postUrls")
        for u in urls:
            p=urlparse(u)
            if p.scheme not in ("http","https") or not (p.hostname or "").endswith("threads.com") or "/post/" not in p.path:
                raise ValueError(f"Invalid public Threads post URL: {u}")
        qs=urls
    return mode, qs

async def extract_profile(page, url: str) -> dict[str, Any]:
    # Read public profile metadata as a fallback when a post card omits its author name.
    await page.goto(url, wait_until="domcontentloaded", timeout=45000)
    await page.wait_for_timeout(1700)
    return await page.evaluate(r'''() => {
      const clean = value => {
        if (!value) return null;
        let v = String(value).replace(/[\u200e\u200f\u202a-\u202e]/g, '').replace(/\s+/g, ' ').trim();
        v = v.replace(/\s*(?:\||•|·|-)\s*Threads\s*$/i, '').replace(/\s+on\s+Threads\s*$/i, '').trim();
        v = v.replace(/\s*\(@?[^)]*\)\s*$/, '').replace(/(?:['’]s)?\s*profile picture\s*$/i, '').trim();
        if (!v || v.length > 80 || /^@/.test(v) || /^(threads?|profile|home|search|activity|log in|login|sign up)$/i.test(v)) return null;
        if (/^\d+(?:[.,]\d+)?\s*(?:k|m|b|тыс\.?|тис\.?|млн\.?|млрд\.?)?\s*(?:views?|likes?|replies|comments?|reposts?|quotes?|followers?|following|posts?|перегляд\w*|просмотр\w*|подобається|відповід\w*|коментар\w*|репост\w*|цитат\w*)$/i.test(v)) return null;
        if (/^(?:views?|likes?|replies|comments?|reposts?|quotes?|followers?|following|posts?)\b/i.test(v)) return null;
        return v;
      };
      const username = (location.pathname.match(/\/@([^/?#]+)/) || [])[1] || null;
      const meta = name => document.querySelector(`meta[property="${name}"]`)?.content || document.querySelector(`meta[name="${name}"]`)?.content || '';
      const main = document.querySelector('main') || document.body;
      const titleCandidates = [meta('og:title'), meta('twitter:title'), document.title];
      let displayName = titleCandidates.map(clean).find(Boolean) || null;
      if (displayName && username && displayName.toLowerCase() === username.toLowerCase()) displayName = null;
      if (!displayName) {
        const headings = [...main.querySelectorAll('h1,[role="heading"]')].map(x => clean(x.innerText)).filter(Boolean);
        displayName = headings.find(x => !username || x.toLowerCase() !== username.toLowerCase()) || null;
      }
      if (!displayName && username) {
        const profileLink = [...main.querySelectorAll('a[href*="/@"]')].find(a => {
          const u = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
          return u && u[1].toLowerCase() === username.toLowerCase();
        });
        let node = profileLink;
        for (let depth = 0; depth < 3 && node && !displayName; depth++, node = node.parentElement) {
          const block = node.innerText || '';
          if (block.length > 180) continue;
          const lines = block.split('\n').map(x => x.trim()).filter(Boolean);
          displayName = lines.map(clean).find(x => x && x.toLowerCase() !== username.toLowerCase()) || null;
        }
      }
      let avatarUrl = meta('og:image');
      if (!avatarUrl) {
        const profileAnchor = [...document.querySelectorAll('a[href*="/@"]')].find(a => {
          const u = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
          return u && username && u[1].toLowerCase() === username.toLowerCase();
        });
        avatarUrl = profileAnchor?.querySelector('img')?.currentSrc || profileAnchor?.querySelector('img')?.src || '';
      }
      const verified = !!main.querySelector('[aria-label*="Verified" i],[title*="Verified" i],[aria-label*="Підтвердж" i]');
      const desc = meta('og:description') || meta('description') || null;
      const body = main.innerText || '';
      const nums = [...body.matchAll(/([\d,.]+\s*[KMB]?)\s+(followers|following|posts)/gi)];
      const counts = {}; for (const m of nums) counts[m[2].toLowerCase()] = m[1];
      return {username, displayName, profileUrl: location.href.split('?')[0], avatarUrl: avatarUrl || null,
        bio: desc, isVerified: verified, followersCount: counts.followers || null,
        followingCount: counts.following || null, postsCount: counts.posts || null};
    }''')


async def enrich_profile_fallback(page, detail: dict[str, Any], post_url: str) -> dict[str, Any]:
    # Fetch the author profile only when post-page metadata is incomplete.
    username = detail.get('username')
    if not username:
        match = re.search(r'/@([^/]+)/post/', post_url or '')
        username = match.group(1) if match else None
    needs_name = not clean_display_name(detail.get('displayName'), username)
    needs_avatar = not detail.get('avatarUrl')
    if not username or not (needs_name or needs_avatar):
        return detail
    try:
        profile = await extract_profile(page, f'https://www.threads.com/@{username}')
        if needs_name and clean_display_name(profile.get('displayName'), username):
            detail['displayName'] = profile['displayName']
        if needs_avatar and profile.get('avatarUrl'):
            detail['avatarUrl'] = profile['avatarUrl']
        if detail.get('isVerified') is None and profile.get('isVerified') is not None:
            detail['isVerified'] = profile['isVerified']
    except Exception:
        # Profile metadata is optional; never fail an otherwise successful post extraction.
        pass
    return detail


async def find_users(page, query: str, max_pages: int, log) -> list[dict[str, Any]]:
    url='https://www.threads.com/search?q='+__import__('urllib.parse',fromlist=['quote']).quote(query)+'&serp_type=default'
    await page.goto(url,wait_until='domcontentloaded',timeout=60000); await page.wait_for_timeout(1800)
    users={}
    for step in range(max_pages):
        rows=await page.evaluate(r'''() => [...document.querySelectorAll('a[href*="/@"]')].map(a=>({url:a.href,text:(a.innerText||'').trim()})).filter(x=>x.url && /\/@[^/]+\/?$/.test(new URL(x.url).pathname))''')
        for x in rows:
            u=x['url'].split('?')[0].rstrip('/'); name=(urlparse(u).path.split('/')[-1] or '').lstrip('@')
            if name: users.setdefault(name,{'username':name,'profileUrl':u,'displayName':(x.get('text') or '').split('\n')[0] or None})
        if step+1<max_pages: await page.mouse.wheel(0,1400); await page.wait_for_timeout(1000)
    return list(users.values())

async def extract_replies(page, post_url: str, max_replies: int, max_depth: int, nested: bool) -> list[dict[str, Any]]:
    await page.goto(post_url,wait_until='domcontentloaded',timeout=45000); await page.wait_for_timeout(1800)
    out={}
    for _ in range(max(1,min(20,(max_replies+19)//20))):
        batch=await page.evaluate(r'''() => {
          const main=document.querySelector('main')||document.body; const out=[];
          for(const a of main.querySelectorAll('a[href*="/@"]')) { const card=a.closest('div'); if(!card) continue;
            const text=(card.innerText||'').trim(); const href=a.href; const user=(new URL(href)).pathname.split('/')[1]?.replace('@','');
            if(!text || text.length<3 || !user) continue;
            const time=card.querySelector('time'); const img=card.querySelector('img');
            out.push({username:user,profileUrl:href.split('?')[0],text,timestamp:time?.dateTime||null,avatarUrl:img?.src||null});
          } return out;
        }''')
        for r in batch:
            key=(r.get('username','')+'|'+r.get('text',''))
            if key not in out: out[key]=r
        if len(out)>=max_replies: break
        await page.mouse.wheel(0,1400); await page.wait_for_timeout(900)
    rows=list(out.values())[:max_replies]
    # DOM does not expose a stable reply ID in all public layouts; preserve unknown as null.
    result=[]
    for i,r in enumerate(rows):
        result.append({'replyId':None,'parentPostId':post_id(post_url),'parentReplyId':None,
          'username':r.get('username'),'displayName':None,'profileUrl':r.get('profileUrl'),
          'text':r.get('text'),'timestamp':r.get('timestamp'),'likesCount':None,'repliesCount':None,
          'replyUrl':None,'scrapedAt':now_iso(),'recordType':'reply','mode':'replies',
          'dataCompleteness':0.35,'_depth':1})
    return result

async def download_media(Actor, context, post: dict[str,Any], inp: dict[str,Any], stats: dict[str,Any]) -> list[dict[str,Any]]:
    urls=post.get('mediaUrls') or []; wanted=set(inp.get('mediaTypes') or ['image','video'])
    max_per=clamp(inp.get('maxMediaPerPost'),10,1,50); max_bytes=clamp(inp.get('maxMediaSizeMb'),25,1,200)*1024*1024
    rows=[]
    for idx,url in enumerate(urls[:max_per]):
        typ='video' if re.search(r'video|\.mp4|\.m3u8',url,re.I) else 'image'
        if typ not in wanted: continue
        row={'mode':'media','recordType':'media','postId':post.get('postId'),'postUrl':post.get('postUrl'),
             'mediaId':None,'mediaType':typ,'mediaUrl':url,'downloaded':False,'fileName':None,
             'contentType':None,'fileSize':None,'storageKey':None,'downloadError':None,'scrapedAt':now_iso()}
        if inp.get('downloadMedia'):
            try:
                resp=await context.request.get(url,timeout=30000)
                if not resp.ok: raise RuntimeError(f'HTTP {resp.status}')
                data=await resp.body(); ct=resp.headers.get('content-type','application/octet-stream')
                if len(data)>max_bytes: raise RuntimeError(f'File exceeds maxMediaSizeMb ({len(data)} bytes)')
                ext='.mp4' if typ=='video' else ('.png' if 'png' in ct else '.jpg')
                key=f"media/{post.get('postId') or 'unknown'}_{idx+1}{ext}"
                store=await Actor.open_key_value_store()
                await store.set_value(key,data,content_type=ct)
                row.update(downloaded=True,fileName=key.split('/')[-1],contentType=ct,fileSize=len(data),storageKey=key)
                stats['downloadedFiles']+=1; stats['downloadedBytes']+=len(data)
            except Exception as exc:
                row['downloadError']=str(exc); stats['downloadErrors']+=1
        rows.append(row)
    return rows

async def run_actor() -> dict[str, Any]:
    if Actor is None: raise RuntimeError('apify package is required to run this Actor')
    async with Actor:
        started=time.monotonic(); inp=await Actor.get_input() or {}; debug=bool(inp.get('debug'))
        try: mode, inputs=validate_input(inp)
        except Exception as exc:
            await Actor.fail(status_message=str(exc)); return {'status':'failed','error':str(exc)}
        max_results=clamp(inp.get('maxResults'),50,1,1000); max_pages=clamp(inp.get('maxPages'),5,1,20)
        sort=(inp.get('sort') or 'recent').lower(); sort=sort if sort in ('recent','top') else 'recent'
        enrich=inp.get('enrichDetails',True) is not False
        max_detail=clamp(inp.get('maxDetailEnrich'),min(max_results,50),1,200)
        proxy_cfg=inp.get('proxyConfiguration') or {}; proxy_url=None; proxy_error=None
        if proxy_cfg.get('useApifyProxy'):
            try:
                pc=await Actor.create_proxy_configuration(actor_proxy_input=proxy_cfg)
                if pc: proxy_url=await pc.new_url()
                if not proxy_url: proxy_error='Apify Proxy configuration returned no proxy URL'
            except Exception as exc: proxy_error=str(exc)
        if proxy_error:
            Actor.log.warning(f'Proxy unavailable; continuing direct because proxyFailureMode=direct: {proxy_error}')
            if inp.get('proxyFailureMode')=='fail':
                await Actor.fail(status_message=f'Proxy setup failed: {proxy_error}')
                return {'status':'failed','mode':mode,'proxyError':proxy_error}
        launch={'headless':True}
        if proxy_url: launch['proxy']={'server':proxy_url}
        stats={'mode':mode,'status':'success','startedAt':now_iso(),'finishedAt':None,'durationSeconds':0,
          'queries':len(inputs) if mode in ('posts_search','user_search') else 0,'rawTotal':0,'uniqueWritten':0,
          'duplicatesSkipped':0,'filteredOut':0,'detailEnriched':0,'failedRecords':0,'errors':[],
          'queryStats':[],'proxyEnabled':bool(proxy_url),'proxyError':proxy_error,'downloadedFiles':0,
          'downloadedBytes':0,'downloadErrors':0,'reason':'completed','schemaVersion':SCHEMA_VERSION}
        seen=set(); written=0; partial_errors=0
        async with async_playwright() as pw:
          browser=await pw.chromium.launch(**launch)
          context=await browser.new_context(locale='en-US',viewport={'width':1280,'height':900},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36')
          page=await context.new_page()
          try:
            if mode=='posts_search':
              filters={'fromUser':inp.get('fromUser'),'after':inp.get('after'),'before':inp.get('before'),
                'includeKeywords':as_list(inp.get('includeKeywords')),'excludeKeywords':as_list(inp.get('excludeKeywords')),
                'keywordMatchMode':inp.get('keywordMatchMode','all'),'minLikes':inp.get('minLikes') or 0,
                'maxLikes':inp.get('maxLikes'),'minReplies':inp.get('minReplies'),'minReposts':inp.get('minReposts'),
                'minQuotes':inp.get('minQuotes'),'hasMedia':bool(inp.get('hasMedia')),'mediaTypes':inp.get('mediaTypes'),
                'minTextLength':inp.get('minTextLength'),'maxTextLength':inp.get('maxTextLength')}
              for q in inputs:
                if written>=max_results: break
                qstats={'query':q,'raw':0,'written':0,'status':'success'}
                try:
                  raw=await scrape_search(page,q,sort=sort,max_pages=max_pages,per_page_limit=40,log=Actor.log,retries=3)
                  qstats['raw']=len(raw); stats['rawTotal']+=len(raw)
                  for item in raw:
                    if written>=max_results: break
                    pid=post_id(item.get('url') or '')
                    if not pid: stats['filteredOut']+=1; continue
                    if pid in seen: stats['duplicatesSkipped']+=1; continue
                    merged=item
                    if enrich and stats['detailEnriched']<max_detail:
                      detail=await enrich_post_detail(page,item.get('url') or '',log=Actor.log,retries=2)
                      detail=await enrich_profile_fallback(page,detail,item.get('url') or '')
                      merged=merge_card_and_detail(item,detail)
                      if detail.get('detailEnriched'): stats['detailEnriched']+=1
                    row=normalize_record(merged,q); row.update(mode=mode,recordType='post',schemaVersion=SCHEMA_VERSION)
                    if not passes_filters(row,filters): stats['filteredOut']+=1; continue
                    if len(row.get('text') or '') < (int(filters['minTextLength']) if filters['minTextLength'] else 0): stats['filteredOut']+=1; continue
                    if filters['maxTextLength'] and len(row.get('text') or '')>int(filters['maxTextLength']): stats['filteredOut']+=1; continue
                    if filters['maxLikes'] is not None and row.get('likesCount') is not None and int(row['likesCount'])>int(filters['maxLikes']): stats['filteredOut']+=1; continue
                    for field, key in [('repliesCount','minReplies'),('repostsCount','minReposts'),('quotesCount','minQuotes')]:
                      if filters[key] is not None and row.get(field) is not None and int(row[field])<int(filters[key]): break
                    else:
                      seen.add(pid); await Actor.push_data(row); written+=1; qstats['written']+=1; continue
                    stats['filteredOut']+=1
                  if not raw: qstats['status']='empty'
                except Exception as exc:
                  partial_errors+=1; qstats['status']='error'; qstats['error']=str(exc); stats['errors'].append({'query':q,'error':str(exc)})
                stats['queryStats'].append(qstats)
            elif mode=='user_search':
              for q in inputs:
                try:
                  found=await find_users(page,q,max_pages,Actor.log); stats['rawTotal']+=len(found)
                  for u in found:
                    if written>=max_results: break
                    if inp.get('enrichProfiles',True):
                      if stats.get('profilesEnriched',0)<clamp(inp.get('maxProfileEnrich'),50,1,200):
                        try: u.update(await extract_profile(page,u['profileUrl'])); stats['profilesEnriched']=stats.get('profilesEnriched',0)+1
                        except Exception as exc: stats['errors'].append({'profile':u.get('profileUrl'),'error':str(exc)}); partial_errors+=1
                    key=(u.get('username') or u.get('profileUrl') or '').lower()
                    if not key or key in seen: stats['duplicatesSkipped']+=1; continue
                    seen.add(key); u.update(mode=mode,recordType='user',scrapedAt=now_iso(),schemaVersion=SCHEMA_VERSION)
                    u['dataCompleteness']=round(sum(v not in (None,'') for v in u.values())/max(1,len(u)),3)
                    await Actor.push_data(u); written+=1
                  stats['queryStats'].append({'query':q,'raw':len(found),'written':written,'status':'success' if found else 'empty'})
                except Exception as exc: partial_errors+=1; stats['errors'].append({'query':q,'error':str(exc)})
            elif mode=='post_details':
              for u in inputs[:max_results]:
                try:
                  d=await enrich_post_detail(page,u,log=Actor.log,retries=2)
                  d=await enrich_profile_fallback(page,d,u)
                  merged={'url':u,**d}; row=normalize_record(merged,''); row.update(mode=mode,recordType='post',sourceInputUrl=u,detailFetchStatus='success' if d.get('detailEnriched') else 'partial',schemaVersion=SCHEMA_VERSION)
                  if row.get('postId') and row['postId'] not in seen: seen.add(row['postId']); await Actor.push_data(row); written+=1; stats['rawTotal']+=1
                  else: stats['duplicatesSkipped']+=1
                except Exception as exc: partial_errors+=1; stats['errors'].append({'url':u,'error':str(exc)})
            elif mode=='replies':
              for u in inputs[:max_results]:
                try:
                  replies=await extract_replies(page,u,clamp(inp.get('maxReplies'),200,1,5000),clamp(inp.get('maxDepth'),1,1,10),bool(inp.get('includeNestedReplies',True)))
                  stats['rawTotal']+=len(replies)
                  for r in replies:
                    key=(r.get('parentPostId','')+'|'+r.get('username','')+'|'+r.get('text',''))
                    if key in seen: stats['duplicatesSkipped']+=1; continue
                    seen.add(key); r.pop('_depth',None); r['sourcePostUrl']=u; r['schemaVersion']=SCHEMA_VERSION
                    await Actor.push_data(r); written+=1
                except Exception as exc: partial_errors+=1; stats['errors'].append({'url':u,'error':str(exc)})
            elif mode=='media':
              for u in inputs[:max_results]:
                try:
                  d=await enrich_post_detail(page,u,log=Actor.log,retries=2)
                  post=normalize_record({'url':u,**d},''); media=await download_media(Actor,context,post,inp,stats)
                  stats['rawTotal']+=len(media)
                  for r in media:
                    key=(r.get('postId'),r.get('mediaUrl'))
                    if key in seen: stats['duplicatesSkipped']+=1; continue
                    seen.add(key); r['schemaVersion']=SCHEMA_VERSION; await Actor.push_data(r); written+=1
                except Exception as exc: partial_errors+=1; stats['errors'].append({'url':u,'error':str(exc)})
          finally:
            await context.close(); await browser.close()
        stats['uniqueWritten']=written; stats['failedRecords']=partial_errors
        if written==0 and partial_errors==0: stats['status']='empty'; stats['reason']='no_results'
        elif partial_errors and written: stats['status']='partial'; stats['reason']='some_records_failed'
        elif partial_errors and not written: stats['status']='failed'; stats['reason']='all_operations_failed'
        stats['finishedAt']=now_iso(); stats['durationSeconds']=round(time.monotonic()-started,2)
        await Actor.set_value('RUN_SUMMARY',stats); Actor.log.info('Run summary: '+json.dumps(stats,ensure_ascii=False))
        if stats['status']=='failed': await Actor.fail(status_message=f"{mode} failed; see RUN_SUMMARY and logs")
        return stats

def main():
    try: asyncio.run(run_actor())
    except KeyboardInterrupt: print('Interrupted',file=sys.stderr)
if __name__=='__main__': main()

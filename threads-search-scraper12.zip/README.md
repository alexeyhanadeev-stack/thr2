# Threads Scraper — Search Posts, Find Users, Extract Replies & Media

**Threads Scraper** is an Apify Actor for collecting structured data from publicly accessible pages on [Threads](https://www.threads.com/). Use it as a **Threads post scraper**, **Threads search scraper**, **Threads profile scraper**, or **Threads media extractor**. It supports five operation modes in one Actor, multi-query search, keyword and date filters, deduplication, optional detail enrichment, and export to an Apify Dataset.

Search public Threads conversations by keywords, hashtags, brands, topics, or creator names. Or provide post URLs to inspect individual posts, collect visible replies, and discover image or video URLs. The Actor uses Playwright to read the public Threads website; it does not use a private API or promise access to content that Threads does not expose.

## Version 1.2.7 extraction improvements

The detail extractor checks bounded serialized public-page state as well as rendered page elements. It validates author names against common interface statistics (for example, `2.5K views`) and uses a public-profile fallback only when the post page does not provide a valid name or avatar. Engagement counts are read from their own structured-data fields or the matching action control; the extractor does not parse the first number from a shared parent container. Image/video type evidence is preserved even when a CDN URL has no file extension. These remain best-effort public-page extractions: Threads may omit fields, change its page structure, or restrict visibility, so unavailable metrics remain `null` and undiscovered media remains an empty list.

## What this Threads scraper can do

- **Search Threads posts:** search one or many keywords, phrases, or hashtags; choose recent or top ordering; filter by author, date, text, keywords, engagement counts when available, and media presence.
- **Find public Threads profiles:** search by name, username, keyword, or topic; optionally open discovered profiles for additional public profile fields.
- **Scrape post details:** provide one or more public Threads post URLs and extract the available normalized post data.
- **Collect replies:** inspect supplied post URLs and collect reply-like cards visible in the public page.
- **Extract Threads images and videos:** find accessible image/video URLs and optionally download files to the Actor's default Key-Value Store.
- **Export structured data:** write records to the Apify Dataset with `mode`, `recordType`, timestamps, source URLs, and mode-specific fields.

## Quick start: search Threads posts

Select `posts_search` mode (the default) and enter one or more search terms:

```json
{
  "mode": "posts_search",
  "searchQueries": ["UGC creator", "looking for content creator", "#ugc"],
  "sort": "recent",
  "maxResults": 100,
  "maxPages": 10,
  "enrichDetails": true,
  "maxDetailEnrich": 50,
  "includeKeywords": ["creator"],
  "keywordMatchMode": "any",
  "excludeKeywords": ["unpaid"]
}
```

The Actor searches each query, deduplicates matching posts, applies configured filters, and writes normalized records to the default Dataset. `searchQuery` remains supported for existing single-query integrations; use `searchQueries` for multiple terms.

## Five scraping modes

### 1. `posts_search` — Threads keyword and hashtag search

Find public Threads posts by keyword, phrase, hashtag, brand, or topic. Use `searchQuery` for one query or `searchQueries` for multiple queries. Results from different queries are deduplicated.

```json
{
  "mode": "posts_search",
  "searchQueries": ["UGC creator", "#ugc", "content creator"],
  "sort": "recent",
  "maxResults": 100,
  "maxPages": 10,
  "enrichDetails": true
}
```

Available filters include:

| Input | Purpose |
|---|---|
| `fromUser` | Keep posts from one Threads username |
| `after`, `before` | Filter by publication date/time in UTC |
| `includeKeywords` | Require matching words or phrases |
| `keywordMatchMode` | Match `all` terms or `any` term |
| `excludeKeywords` | Exclude posts containing listed terms |
| `minLikes`, `maxLikes` | Filter by likes when the count is available |
| `minReplies`, `minReposts`, `minQuotes` | Filter by other engagement counts when available |
| `hasMedia`, `mediaTypes` | Keep posts with discovered images/videos and filter media type |
| `minTextLength`, `maxTextLength` | Filter by extracted text length |
| `enrichDetails`, `maxDetailEnrich` | Open a limited number of posts for additional extraction |

Unknown engagement counts are not converted to zero. If Threads does not expose a count, the corresponding field remains `null`. When you set a numeric engagement threshold or media-type filter, records with unknown values are excluded because the Actor cannot verify that they meet the requested condition.

### 2. `user_search` — public Threads profile discovery

Search for public profile links surfaced by Threads search and optionally inspect those profiles.

```json
{
  "mode": "user_search",
  "userQueries": ["UGC creator", "beauty blogger"],
  "maxResults": 50,
  "maxPages": 5,
  "enrichProfiles": true,
  "maxProfileEnrich": 30
}
```

The Actor attempts to collect username, display name, profile URL, avatar, bio/description, verification indicator, and visible profile counts. Threads search may return posts instead of dedicated profile results, so this is best-effort profile discovery, not a complete or exhaustive user directory. Some profile fields may be unavailable.

### 3. `post_details` — extract data from Threads post URLs

Provide one or more public post URLs to retrieve the normalized post structure.

```json
{
  "mode": "post_details",
  "postUrls": [
    "https://www.threads.com/@example/post/ABC123"
  ]
}
```

Each processed URL produces a post record with available fields, `sourceInputUrl`, and `detailFetchStatus`. If one URL is inaccessible or deleted, the Actor records the issue and continues with other URLs.

### 4. `replies` — scrape visible replies

Collect reply-like cards visible on supplied public Threads post pages.

```json
{
  "mode": "replies",
  "postUrls": ["https://www.threads.com/@example/post/ABC123"],
  "maxReplies": 200,
  "maxDepth": 3,
  "includeNestedReplies": true
}
```

Reply visibility depends on the public page. Threads does not consistently expose stable reply IDs, parent relationships, or complete nested pagination. The current extractor collects visible reply-like cards and does **not** guarantee full recursive conversation capture; `maxDepth` and `includeNestedReplies` do not override this platform limitation. Reply IDs, parent IDs, and reply URLs may be `null`.

### 5. `media` — extract or download Threads media

Extract accessible image and video URLs from supplied public posts. Optionally download the files.

```json
{
  "mode": "media",
  "postUrls": ["https://www.threads.com/@example/post/ABC123"],
  "downloadMedia": false,
  "mediaTypes": ["image", "video"],
  "maxMediaPerPost": 10,
  "maxMediaSizeMb": 25
}
```

With `downloadMedia: false`, the Actor returns discovered media URLs and metadata. With downloads enabled, accessible files are stored in the default Key-Value Store; Dataset rows contain storage keys and file metadata, not binary contents. Some media URLs may be temporary, protected, unavailable, or too large to download. A post can return an empty `mediaUrls` list when no eligible media URL is discovered in the accessible page.

## Output data

The Actor writes structured records to the default Apify Dataset. Post records preserve the familiar fields below; other modes add mode-specific user, reply, or media fields.

| Field | Description |
|---|---|
| `postId` | Threads post identifier when available |
| `postUrl`, `canonicalUrl` | Post URL and normalized canonical URL |
| `text` | Extracted post text after common interface fragments are removed |
| `timestamp` | Publication time in ISO 8601 UTC format when available |
| `username`, `displayName` | Author handle and display name when available |
| `avatarUrl` | Author profile/avatar image URL; kept separate from post media |
| `isVerified` | Verification indicator (`true`, `false`, or `null` when unknown) |
| `likesCount`, `repliesCount`, `repostsCount`, `quotesCount` | Engagement counts when exposed by the public page; otherwise `null` |
| `mediaUrls`, `mediaType` | Discovered post media URLs and type (`image`, `video`, `mixed`, or `null`) |
| `searchQuery` | Search term associated with the result in `posts_search` mode |
| `detailEnriched` | Whether detail-page enrichment ran for this record |
| `dataCompleteness` | Weighted estimate of populated/known fields, from 0 to 1; not a guarantee of accuracy or total platform coverage |
| `scrapedAt`, `schemaVersion` | Extraction time and output schema version |
| `mode`, `recordType` | Operation mode and record type for each row |

Missing data is represented as `null` or an empty list where appropriate. The Actor does not infer missing engagement counts as zero, and it does not fabricate author names, media URLs, or timestamps. `dataCompleteness` is an indicative score, not a confidence score.

## Run summary and diagnostics

At the end of a run, the Actor stores `RUN_SUMMARY` in the default Key-Value Store. It includes status (`success`, `empty`, `partial`, or `failed`), timing, query statistics, raw and unique record counts, errors, proxy state, and media download statistics where relevant.

## Common settings

- `proxyConfiguration`: optional Apify Proxy configuration for browser traffic; availability may depend on your Apify plan.
- `proxyFailureMode`: `direct` (default) logs a warning and continues without proxy if proxy setup fails; `fail` stops the run.
- `debug`: enables additional diagnostic logging for troubleshooting.
- `maxPages`: approximate browser scroll cycles, not a guaranteed count of server-side pages.

## Reliability, limitations, and responsible use

This Actor uses Playwright to access the public Threads website. Threads can change its interface, throttle requests, require login, hide engagement counts, or make posts and media unavailable. Results reflect only the content exposed during the run.

- Public search results are not guaranteed to be complete, exhaustive, or chronologically perfect.
- Display names, profile metadata, engagement counts, and media URLs are extracted only when identifiable in the loaded page; they may be missing or `null`.
- A `detailEnriched: true` record means detail enrichment ran; it does not mean every optional field was found.
- Empty media results mean no eligible URL was discovered, not proof that the original post never contained media.
- User search, reply collection, nested replies, and media downloads are best-effort and depend on Threads' public interface and URL accessibility.
- The Actor does not bypass authentication, private profiles, access controls, or anti-bot protections.

Use only public content you are authorized to access. Respect Meta/Threads terms, privacy requirements, copyright, and applicable laws. Do not use this Actor to collect private data, evade access restrictions, or harass users.

## Frequently asked questions

**Can I search multiple Threads keywords in one run?**  
Yes. Use `searchQueries` in `posts_search` mode. Results are deduplicated across queries.

**Can I scrape a specific Threads post?**  
Yes. Use `post_details`, `replies`, or `media` mode and pass one or more public post URLs in `postUrl` or `postUrls`.

**Does the Actor return likes and reply counts for every post?**  
No. Threads does not expose these values consistently. Available counts are returned; unavailable values remain `null`.

**Can it download images and videos?**  
It can attempt to download accessible media when `downloadMedia` is enabled. Download availability depends on the source URL, access restrictions, file type, and size limit.

**Does it collect private profiles or bypass login?**  
No. It is designed for publicly accessible pages and does not bypass authentication or access controls.

## Examples

The `examples/` directory contains ready-to-run input examples for post search, user search, post details, replies, and media extraction, plus an illustrative output record.

"""Threads search & extraction (enriched toward Store parity)."""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote, urlsplit

SCHEMA_VERSION = "1.2.5"

# --- Search feed extraction (card-level) ---
EXTRACT_POSTS_JS = r"""(limit) => {
  const out = [], seen = new Set();
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src) ||
      /(?:^|[_=&])s150x150(?:[_&]|$)/i.test(src) || /profile|avatar/i.test(alt);
  };
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    const id = key(a.href);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    let best = null, bestText = '', bestTime = '';
    let node = a;
    for (let depth = 0; depth < 18 && node && node !== document.body; depth++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      if (!text || text.length > 18000) continue;
      const times = links.filter(x => key(x.href) === id).map(x => x.querySelector('time[datetime]')).filter(Boolean);
      const ownTime = times[0] || node.querySelector('time[datetime]');
      if (text.length >= bestText.length) {
        best = node; bestText = text;
        if (ownTime) bestTime = ownTime.getAttribute('datetime') || bestTime;
      }
    }
    if (!best) continue;
    const m = a.href.match(/\/@([^/]+)\/post\//);
    const media = [];
    for (const img of best.querySelectorAll('img')) {
      const src = img.getAttribute('src') || '';
      const r = img.getBoundingClientRect();
      const inProfileLink = !!img.closest('a[href*="/@"]');
      if (src && !/emoji|icon|logo/i.test(src) && !isProfileImage(src, img) &&
          !(inProfileLink && r.width <= 160 && r.height <= 160) &&
          !(r.width > 0 && r.height > 0 && r.width <= 80 && r.height <= 80) && /^https?:\/\//.test(src)) media.push(src);
    }
    for (const v of best.querySelectorAll('video')) {
      const src = v.getAttribute('src') || (v.querySelector('source') && v.querySelector('source').src) || '';
      if (src && /^https?:\/\//.test(src)) media.push(src);
    }
    const more = Array.from(best.querySelectorAll('[role="button"],button')).some(x =>
      /^(?:more|see more|read more|ещ[её]|подробнее|більше|ще|читати далі)$/i.test((x.innerText || '').trim())
    );
    out.push({
      url: a.href.split('?')[0],
      author: m ? m[1] : '',
      text: bestText,
      timestamp: bestTime,
      mediaUrls: Array.from(new Set(media)).slice(0, 20),
      extraction_incomplete: more || bestText.length < 50,
    });
    if (out.length >= limit) break;
  }
  return out;
}"""

# --- Single post detail page enrichment ---
EXTRACT_DETAIL_JS = r"""() => {
  const abs = (u) => {
    if (!u) return null;
    if (u.startsWith('//')) return 'https:' + u;
    return u;
  };
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const sameImage = (a, b) => { try { const x=new URL(a); const y=new URL(b); return x.pathname===y.pathname; } catch (_) { return a===b; } };
  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src) ||
      /(?:^|[_=&])s150x150(?:[_&]|$)/i.test(src) || /profile|avatar/i.test(alt);
  };
  const pathId = key(location.href);

  // Prefer the main post card for this URL
  let best = null, bestScore = -1;
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    if (pathId && !(a.href || '').includes('/post/' + pathId)) continue;
    let node = a;
    for (let d = 0; d < 18 && node && node !== document.body; d++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      const rect = node.getBoundingClientRect();
      if (text.length < 20 || rect.width < 200) continue;
      const score = Math.min(text.length, 2000) + (rect.height > 80 ? 50 : 0);
      if (score > bestScore) { best = node; bestScore = score; }
    }
  }
  if (!best) best = document.body;

  // Username / profile link
  let username = null;
  const um = (location.pathname || '').match(/\/@([^/]+)\//);
  if (um) username = um[1];
  if (!username) {
    const profile = best.querySelector('a[href*="/@"]');
    if (profile) {
      const pm = (profile.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      if (pm) username = pm[1];
    }
  }

  // Display name: prefer explicit profile metadata, then the author-link block.
  let displayName = null;
  const cleanName = (value) => {
    if (!value) return null;
    let v = String(value).replace(/\s+/g, ' ').trim();
    v = v.replace(/\s*[|•·-]\s*Threads\s*$/i, '').trim();
    v = v.replace(/\s*\(@?[^)]*\)\s*$/, '').trim();
    if (!v || v.length > 80 || (username && v.replace(/^@/, '').toLowerCase() === username.toLowerCase())) return null;
    if (/^(thread|threads|log in|login|sign up|home|search|activity|profile)$/i.test(v)) return null;
    if (/privacy policy|terms of service|cookies? policy|report a problem|log in with username|^@/.test(v.toLowerCase())) return null;
    return v;
  };
  const metaTitle = document.querySelector('meta[property="og:title"]')?.content ||
                    document.querySelector('meta[name="twitter:title"]')?.content || '';
  displayName = cleanName(metaTitle);
  if (!displayName && username) {
    const profileLink = Array.from(best.querySelectorAll('a[href*="/@"]')).find(a => {
      const m = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      return m && m[1].toLowerCase() === username.toLowerCase();
    });
    if (profileLink) {
      let node = profileLink;
      for (let depth = 0; depth < 4 && node && node !== best; depth++, node = node.parentElement) {
        const lines = (node.innerText || '').split('\n').map(x => x.trim()).filter(Boolean);
        const candidate = lines.find(x => {
          const v = cleanName(x);
          return v && v.toLowerCase() !== username.toLowerCase() && !/^@/.test(x) && x.length <= 80;
        });
        if (candidate) { displayName = cleanName(candidate); break; }
      }
    }
  }
  if (!displayName) {
    const imgAlt = Array.from(best.querySelectorAll('img[alt]')).map(x => x.getAttribute('alt') || '')
      .map(cleanName).find(Boolean);
    if (imgAlt && !/^(profile|avatar|photo|image)$/i.test(imgAlt)) displayName = imgAlt;
  }

  // Verified badge
  let isVerified = null;
  const aria = best.querySelector('[aria-label*="Verified"], [aria-label*="verified"], [aria-label*="Підтвердж"]');
  if (aria) isVerified = true;
  else if (best.querySelector('svg[aria-label*="erif"], img[alt*="erif"]')) isVerified = true;

  // Avatar
  let avatarUrl = null;
  for (const img of best.querySelectorAll('img')) {
    const alt = (img.getAttribute('alt') || '').toLowerCase();
    const src = abs(img.getAttribute('src') || '');
    if (!src || !/^https?:\/\//.test(src)) continue;
    if (/profile|avatar/i.test(src) || /profile|avatar|photo/i.test(alt)) {
      avatarUrl = src;
      break;
    }
  }
  if (!avatarUrl) {
    // first small-ish image near top
    for (const img of best.querySelectorAll('img')) {
      const src = abs(img.getAttribute('src') || '');
      const r = img.getBoundingClientRect();
      if (src && r.width > 20 && r.width < 120 && r.height > 20 && r.height < 120) {
        avatarUrl = src;
        break;
      }
    }
  }

  // Timestamp
  let timestamp = '';
  const timeEl = best.querySelector('time[datetime]') || document.querySelector('time[datetime]');
  if (timeEl) timestamp = timeEl.getAttribute('datetime') || '';

  // Text: remove chrome-ish lines later in Python; take innerText of card
  const text = (best.innerText || '').trim();

  // Media: inspect rendered source, srcset and video posters; exclude profile assets only.
  const mediaUrls = [];
  const addMedia = (value) => {
    if (!value) return;
    const u = abs(String(value).trim());
    if (u && /^https?:\/\//i.test(u) && !mediaUrls.includes(u)) mediaUrls.push(u);
  };
  for (const img of best.querySelectorAll('img')) {
    const src = abs(img.currentSrc || img.getAttribute('src') || '');
    if (!src || !/^https?:\/\//.test(src)) continue;
    if (/emoji|icon|logo/i.test(src) || isProfileImage(src, img) || (avatarUrl && sameImage(src, avatarUrl))) continue;
    const r = img.getBoundingClientRect();
    const srcset = (img.getAttribute('srcset') || '').split(',').map(x => x.trim().split(/\s+/)[0]).filter(Boolean);
    if (r.width >= 80 && r.height >= 80) { addMedia(src); srcset.forEach(addMedia); }
  }
  for (const source of best.querySelectorAll('picture source[srcset]')) {
    const srcset = (source.getAttribute('srcset') || '').split(',').map(x => x.trim().split(/\s+/)[0]).filter(Boolean);
    srcset.forEach(u => { if (!isProfileImage(u, null)) addMedia(u); });
  }
  for (const v of best.querySelectorAll('video')) {
    addMedia(v.currentSrc || v.getAttribute('src') || v.querySelector('source')?.src || '');
    const poster = abs(v.getAttribute('poster') || '');
    if (poster && !isProfileImage(poster, null)) addMedia(poster);
  }

  // Engagement: Threads often puts the count in a sibling, not in aria-label.
  const parseCount = (value) => {
    if (value == null) return null;
    const s = String(value).replace(/,/g, '').trim().toLowerCase();
    const m = s.match(/(?:^|\s)(\d+(?:\.\d+)?)\s*([kmb])?(?:\s|$)/i);
    if (!m) return null;
    let n = Number(m[1]);
    if (m[2] === 'k') n *= 1e3;
    if (m[2] === 'm') n *= 1e6;
    if (m[2] === 'b') n *= 1e9;
    return Number.isFinite(n) ? Math.round(n) : null;
  };
  let likesCount = null, repliesCount = null, repostsCount = null, quotesCount = null;
  const classify = (label) => {
    const low = String(label || '').toLowerCase();
    if (/\b(like|likes|liked)\b|нравится|подобається|вподобан/i.test(low)) return 'like';
    if (/\b(reply|replies|comment|comments)\b|відповід|коментар|ответ|коммент/i.test(low)) return 'reply';
    if (/\b(repost|reposts|reposted|reshare)\b|репост|перепост/i.test(low)) return 'repost';
    if (/\b(quote|quotes)\b|цитат/i.test(low)) return 'quote';
    return null;
  };
  const setCount = (kind, n) => {
    if (n == null) return;
    if (kind === 'like' && likesCount == null) likesCount = n;
    if (kind === 'reply' && repliesCount == null) repliesCount = n;
    if (kind === 'repost' && repostsCount == null) repostsCount = n;
    if (kind === 'quote' && quotesCount == null) quotesCount = n;
  };
  for (const el of best.querySelectorAll('[aria-label], button, a, [role="button"]')) {
    const label = (el.getAttribute('aria-label') || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
    const kind = classify(label);
    if (!kind) continue;
    let n = parseCount(label);
    if (n == null) {
      const parent = el.parentElement;
      const grand = parent?.parentElement;
      for (const box of [el, parent, grand]) {
        if (!box) continue;
        const txt = (box.innerText || '').replace(/\s+/g, ' ').trim();
        if (txt.length <= 100) { n = parseCount(txt); if (n != null) break; }
      }
    }
    setCount(kind, n);
  }
  // Accessible labels can be attached to SVGs rather than their button.
  for (const el of best.querySelectorAll('svg[aria-label], [data-testid]')) {
    const label = el.getAttribute('aria-label') || el.getAttribute('data-testid') || '';
    const kind = classify(label);
    if (!kind) continue;
    const box = el.closest('button,[role="button"]') || el.parentElement;
    setCount(kind, parseCount((box?.innerText || '') + ' ' + label));
  }

  return {
    username,
    displayName,
    isVerified,
    avatarUrl,
    timestamp,
    text,
    mediaUrls: Array.from(new Set(mediaUrls)).slice(0, 30),
    likesCount,
    repliesCount,
    repostsCount,
    quotesCount,
  };
}"""


def post_id(url: str) -> str | None:
    m = re.search(r"/post/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else None


def canonical_url(url: str) -> str | None:
    m = re.search(r"/@([^/]+)/post/([A-Za-z0-9_-]+)", url or "")
    if m:
        return f"https://www.threads.com/@{m.group(1)}/post/{m.group(2)}"
    return (url or "").split("?")[0].rstrip("/") or None


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def to_iso_utc(value: str | None) -> str | None:
    dt = parse_timestamp(value)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ") if dt else None


_UI_LINE = re.compile(
    r"(?i)^(?:ланцюжок|ветка|thread|threads|like|reply|replies|views?|перегляд\w*|просмотр\w*|"
    r"подобається|відповісти|поширити|translate|more|see more|читати далі|"
    r"log\s*in|sign\s*up|cookie|follow|стежити|підписатися)$"
)
_VIEWS_PREFIX = re.compile(
    r"(?i)^\s*(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)\s+"
)
_RELATIVE_TIME_PREFIX = re.compile(
    r"(?i)^\s*\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)\s+"
)
_LOGIN_CTA = re.compile(r"(?is)\s*Log\s*in\s*or\s*sign\s*up\s+for\s+Threads\b.*$")
_LOGIN_CTA_UA = re.compile(r"(?is)\s*(?:Увійдіть|Войдите).{0,40}(?:Threads|Тредс).*$")
_SEE_WHAT = re.compile(r"(?is)\s*See\s+what\s+people\s+are\s+talking\s+about.*$")
_JOIN_THREAD = re.compile(r"(?is)\s*join\s+the\s+(?:conversation|community).*$")
_FOOTER_START = re.compile(
    r"(?i)^(?:©\s*\d{4}|threads?\s+terms(?:\s+of\s+use)?|privacy\s+policy|"
    r"consumer\s+health\s+privacy\s+policy|cookies?\s+policy|report\s+a\s+problem|"
    r"log\s*in\s+with\s+username\s+instead|terms\s+of\s+service)$"
)


def clean_post_text(raw: str, author: str = "") -> str:
    """Remove known Threads interface/footer text while preserving the post body."""
    if not raw:
        return ""

    # When a full page was captured, isolate the post area if a recognizable footer follows.
    frame = raw.splitlines()
    if any(_FOOTER_START.match(re.sub(r"\s+", " ", x).strip()) for x in frame):
        cut = next((i for i, x in enumerate(frame)
                    if _FOOTER_START.match(re.sub(r"\s+", " ", x).strip())), len(frame))
        frame = frame[:cut]
    raw = "\n".join(frame)

    author_name = (author or "").lstrip("@").lower()
    lines: list[str] = []
    seen: set[str] = set()
    for raw_line in raw.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line:
            continue
        # Common UI-only date stamp shown above search result cards.
        if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2,4}", line):
            continue
        if _UI_LINE.match(line):
            continue
        if re.fullmatch(r"(?i)(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)", line):
            continue
        if re.fullmatch(r"(?i)\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)", line):
            continue
        if re.fullmatch(r"[\d\s.,kKmM+]+", line) and len(line) < 8:
            continue

        line = _VIEWS_PREFIX.sub("", line)
        line = _RELATIVE_TIME_PREFIX.sub("", line)
        line = _LOGIN_CTA.sub("", line)
        line = _LOGIN_CTA_UA.sub("", line)
        line = _SEE_WHAT.sub("", line)
        line = _JOIN_THREAD.sub("", line)
        line = re.sub(r"(?i)\s*Log\s*in\s+with\s+username\s+instead.*$", "", line)
        line = re.sub(r"(?i)\s*Log\s*in\s*or\s*sign\s*up\b.*$", "", line)
        line = line.strip(" \t|-–—")
        if not line:
            continue
        low = line.lower()
        if author_name and low in {author_name, f"@{author_name}"}:
            continue
        if low in seen and len(low) < 40:
            continue
        seen.add(low)
        lines.append(line)

    return "\n".join(lines).strip()


def clean_display_name(value: Any, username: str | None = None) -> str | None:
    """Reject page titles, handles and obvious UI labels as display names."""
    if not isinstance(value, str):
        return None
    name = re.sub(r"\s+", " ", value).strip().strip("·|-")
    # Threads page titles often append platform text or use the avatar's alt label.
    name = re.sub(r"\s+on\s+Threads\s*$", "", name, flags=re.IGNORECASE).strip()
    if username:
        name = re.sub(rf"\s*\(@?{re.escape(username)}\)\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"(?:['’]s)?\s*profile picture\s*$", "", name, flags=re.IGNORECASE).strip()
    if not name or len(name) > 80:
        return None
    low = name.casefold().lstrip("@")
    if username and low == username.casefold().lstrip("@"):
        return None
    if low in {"thread", "threads", "log in", "login", "sign up", "home", "search", "activity", "profile"}:
        return None
    if re.search(r"privacy policy|terms of service|cookies? policy|report a problem|log in with username", low):
        return None
    if re.fullmatch(r"[\d\W_]+", name):
        return None
    return name


def clean_media_urls(values: Any, avatar_url: str | None = None) -> list[str]:
    """Remove profile/avatar image URLs without discarding post media."""
    if not isinstance(values, (list, tuple)):
        return []
    avatar_path = None
    if avatar_url:
        try:
            avatar_path = urlsplit(avatar_url).path
        except Exception:
            avatar_path = None
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str) or not value.startswith(("http://", "https://")):
            continue
        try:
            parsed = urlsplit(value)
            path = parsed.path.lower()
            query = parsed.query.lower()
        except Exception:
            continue
        if re.search(r"/t51\.\d+-19(?:/|$)", path):
            continue
        if re.search(r"(?:profile_pic|profile|avatar)", path):
            continue
        if "s150x150" in query or "s150x150" in path:
            continue
        if avatar_path and parsed.path == avatar_path:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out[:30]


def build_search_url(base: str, query: str, sort: str) -> str:
    base = base.rstrip("/")
    sort = (sort or "recent").lower()
    # Threads web search: recent feed vs default (relevance/top)
    if sort == "top":
        return f"{base}/search?q={quote(query)}&serp_type=default"
    return f"{base}/search?q={quote(query)}&serp_type=default&filter=recent"


def data_completeness(row: dict[str, Any]) -> float:
    """Weighted completeness of meaningful post fields, not mere key presence.

    Empty media is known only after detail extraction; false verification is a
    valid known value. Engagement values remain unknown when Threads exposes no count.
    """
    weights = {
        "postId": 1.0, "postUrl": 1.0, "text": 1.5, "timestamp": 1.0,
        "username": 1.0, "displayName": 0.75, "avatarUrl": 0.5,
        "isVerified": 0.5, "likesCount": 1.0, "repliesCount": 1.0,
        "repostsCount": 1.0, "quotesCount": 0.75, "mediaUrls": 1.0,
    }
    earned = total = 0.0
    for field, weight in weights.items():
        total += weight
        value = row.get(field)
        known = value is not None and value != ""
        if field == "mediaUrls":
            known = isinstance(value, list) and (bool(value) or bool(row.get("detailEnriched")))
        elif field == "isVerified":
            known = isinstance(value, bool)
        if known:
            earned += weight
    return round(earned / total, 3) if total else 0.0


def normalize_record(raw: dict[str, Any], search_query: str) -> dict[str, Any]:
    url = raw.get("url") or raw.get("postUrl") or ""
    pid = post_id(url)
    username = (raw.get("author") or raw.get("username") or "").lstrip("@") or None
    text = clean_post_text(raw.get("text") or "", username or "")
    avatar_url = raw.get("avatarUrl")
    media = clean_media_urls(raw.get("mediaUrls") or [], avatar_url)
    display_name = clean_display_name(raw.get("displayName"), username)
    media_type = None
    if media:
        kinds = {"video" if re.search(r"\.mp4(?:$|[?#])|video|\.m3u8|\.mpd", m, re.I) else "image" for m in media}
        media_type = next(iter(kinds)) if len(kinds) == 1 else "mixed"

    row = {
        "postId": pid,
        "postUrl": url or None,
        "canonicalUrl": canonical_url(url),
        "text": text or None,
        "timestamp": to_iso_utc(raw.get("timestamp")),
        "username": username,
        "displayName": display_name,
        "avatarUrl": avatar_url,
        "isVerified": raw.get("isVerified"),
        "likesCount": raw.get("likesCount"),
        "repliesCount": raw.get("repliesCount"),
        "repostsCount": raw.get("repostsCount"),
        "quotesCount": raw.get("quotesCount"),
        "mediaUrls": media,
        "mediaType": media_type,
        "searchQuery": search_query,
        "scrapedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "schemaVersion": SCHEMA_VERSION,
        "detailEnriched": bool(raw.get("detailEnriched")),
    }
    row["dataCompleteness"] = data_completeness(row)
    return row


def passes_filters(row: dict[str, Any], opts: dict[str, Any]) -> bool:
    text = (row.get("text") or "").lower()
    username = (row.get("username") or "").lower()

    from_user = (opts.get("fromUser") or "").strip().lstrip("@").lower()
    if from_user and username != from_user:
        return False

    include = [kw.lower() for kw in (opts.get("includeKeywords") or []) if kw]
    if include:
        mode = (opts.get("keywordMatchMode") or "all").lower()
        matched = [kw in text for kw in include]
        if (mode == "any" and not any(matched)) or (mode != "any" and not all(matched)):
            return False
    for kw in opts.get("excludeKeywords") or []:
        if kw and kw.lower() in text:
            return False

    min_likes = int(opts.get("minLikes") or 0)
    if min_likes > 0 and row.get("likesCount") is not None:
        if int(row["likesCount"]) < min_likes:
            return False

    if opts.get("hasMedia") and not (row.get("mediaUrls") or []):
        return False
    media_types = opts.get("mediaTypes") or []
    if media_types:
        mt = row.get("mediaType")
        if mt and mt not in media_types:
            return False

    after = opts.get("after")
    before = opts.get("before")
    ts = parse_timestamp(row.get("timestamp"))
    if after:
        adt = parse_timestamp(after if "T" in str(after) else f"{after}T00:00:00Z")
        if adt and ts and ts < adt:
            return False
        if adt and not ts:
            return False
    if before:
        bdt = parse_timestamp(before if "T" in str(before) else f"{before}T00:00:00Z")
        if bdt and ts and ts >= bdt:
            return False
        if bdt and not ts:
            return False

    return True


async def scrape_search(
    page,
    query: str,
    *,
    sort: str = "recent",
    max_pages: int = 5,
    per_page_limit: int = 30,
    base_url: str = "https://www.threads.com",
    log=None,
    retries: int = 3,
) -> list[dict[str, Any]]:
    """Open Threads search, scroll, extract cards. Retry with backoff on failure."""
    url = build_search_url(base_url, query, sort)
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            if log:
                log.info(f"Opening search (attempt {attempt}/{retries}): {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_timeout(2500)

            # Detect login wall (soft)
            title = (await page.title() or "").lower()
            if "log in" in title or "login" in (page.url or "").lower():
                if log:
                    log.warning("Possible login wall on search page")

            collected: dict[str, dict] = {}
            stagnant = 0
            for step in range(max(1, max_pages)):
                batch = await page.evaluate(EXTRACT_POSTS_JS, per_page_limit)
                before = len(collected)
                for item in batch or []:
                    pid = post_id(item.get("url") or "")
                    if not pid:
                        continue
                    old = collected.get(pid)
                    if old is None or len(item.get("text") or "") > len(old.get("text") or ""):
                        collected[pid] = item
                if log:
                    log.info(f"Scroll {step + 1}/{max_pages}: unique={len(collected)}")
                if len(collected) == before:
                    stagnant += 1
                    if stagnant >= 2:
                        break
                else:
                    stagnant = 0
                await page.mouse.wheel(0, 1600)
                await page.wait_for_timeout(1100 + attempt * 100)

            return list(collected.values())
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Search attempt {attempt} failed: {type(exc).__name__}: {exc}")
            await asyncio.sleep(min(8, 1.5 * attempt))
    if last_err:
        raise last_err
    return []


async def enrich_post_detail(
    page,
    post_url: str,
    *,
    log=None,
    retries: int = 2,
) -> dict[str, Any]:
    """Open a single post and extract engagement, profile, media."""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            await page.goto(post_url, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(2000)
            # expand "more" once
            try:
                for label in ("more", "see more", "читати далі", "більше", "ещё", "подробнее"):
                    btn = page.get_by_role("button", name=re.compile(rf"^{label}$", re.I))
                    if await btn.count():
                        await btn.first.click(timeout=1200)
                        await page.wait_for_timeout(300)
                        break
            except Exception:
                pass
            data = await page.evaluate(EXTRACT_DETAIL_JS)
            if not isinstance(data, dict):
                data = {}
            data["detailEnriched"] = True
            return data
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Detail attempt {attempt} for {post_url}: {type(exc).__name__}")
            await asyncio.sleep(min(6, 1.2 * attempt))
    if log and last_err:
        log.warning(f"Detail enrichment failed: {last_err}")
    return {"detailEnriched": False}


def merge_card_and_detail(card: dict[str, Any], detail: dict[str, Any]) -> dict[str, Any]:
    out = dict(card)
    if not detail:
        return out
    # Prefer longer/cleaner text from detail if available
    if detail.get("text") and len(detail.get("text") or "") > len(out.get("text") or ""):
        out["text"] = detail["text"]
    if detail.get("timestamp") and not out.get("timestamp"):
        out["timestamp"] = detail["timestamp"]
    if detail.get("username"):
        out["author"] = detail["username"]
        out["username"] = detail["username"]
    for k in (
        "displayName", "avatarUrl", "isVerified",
        "likesCount", "repliesCount", "repostsCount", "quotesCount",
    ):
        if detail.get(k) is not None:
            out[k] = detail[k]
    # Merge media
    avatar = detail.get("avatarUrl") or out.get("avatarUrl")
    media = clean_media_urls(list(out.get("mediaUrls") or []) + list(detail.get("mediaUrls") or []), avatar)
    out["mediaUrls"] = media
    out["displayName"] = (clean_display_name(detail.get("displayName"), out.get("author") or out.get("username"))
                          or clean_display_name(card.get("displayName"), out.get("author") or out.get("username")))
    out["detailEnriched"] = bool(detail.get("detailEnriched"))
    return out

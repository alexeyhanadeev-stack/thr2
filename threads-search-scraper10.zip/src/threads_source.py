"""Threads search & extraction (enriched toward Store parity)."""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote, urlsplit

SCHEMA_VERSION = "1.2.6"

# --- Search feed extraction (card-level) ---
EXTRACT_POSTS_JS = r"""(limit) => {
  const out = [], seen = new Set();
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src) ||
      /(?:^|[_=&])s150x150(?:[_&]|$)/i.test(src) || /profile|avatar/i.test(alt);
  };
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    const id = key(a.href);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    let best = null, bestText = '', bestTime = '';
    let node = a;
    for (let depth = 0; depth < 18 && node && node !== document.body; depth++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      if (!text || text.length > 18000) continue;
      const times = links.filter(x => key(x.href) === id).map(x => x.querySelector('time[datetime]')).filter(Boolean);
      const ownTime = times[0] || node.querySelector('time[datetime]');
      if (text.length >= bestText.length) {
        best = node; bestText = text;
        if (ownTime) bestTime = ownTime.getAttribute('datetime') || bestTime;
      }
    }
    if (!best) continue;
    const m = a.href.match(/\/@([^/]+)\/post\//);
    const media = [];
    for (const img of best.querySelectorAll('img')) {
      const src = img.getAttribute('src') || '';
      const r = img.getBoundingClientRect();
      const inProfileLink = !!img.closest('a[href*="/@"]');
      if (src && !/emoji|icon|logo/i.test(src) && !isProfileImage(src, img) &&
          !(inProfileLink && r.width <= 160 && r.height <= 160) &&
          !(r.width > 0 && r.height > 0 && r.width <= 80 && r.height <= 80) && /^https?:\/\//.test(src)) media.push(src);
    }
    for (const v of best.querySelectorAll('video')) {
      const src = v.getAttribute('src') || (v.querySelector('source') && v.querySelector('source').src) || '';
      if (src && /^https?:\/\//.test(src)) media.push(src);
    }
    const more = Array.from(best.querySelectorAll('[role="button"],button')).some(x =>
      /^(?:more|see more|read more|ещ[её]|подробнее|більше|ще|читати далі)$/i.test((x.innerText || '').trim())
    );
    out.push({
      url: a.href.split('?')[0],
      author: m ? m[1] : '',
      text: bestText,
      timestamp: bestTime,
      mediaUrls: Array.from(new Set(media)).slice(0, 20),
      extraction_incomplete: more || bestText.length < 50,
    });
    if (out.length >= limit) break;
  }
  return out;
}"""

# --- Single post detail page enrichment ---
EXTRACT_DETAIL_JS = r"""() => {
  const abs = (u) => {
    if (!u) return null;
    try { return new URL(String(u), location.href).href; } catch (_) { return null; }
  };
  const postKey = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const pathId = postKey(location.href);
  const sameImage = (a, b) => { try { const x=new URL(a); const y=new URL(b); return x.pathname===y.pathname; } catch (_) { return a===b; } };
  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src || ''; } })();
    const query = (() => { try { return new URL(src, location.href).search; } catch (_) { return ''; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src || '') ||
      /s150x150/i.test(query) || /profile|avatar/i.test(alt);
  };
  const cleanName = (value) => {
    if (!value) return null;
    let v = String(value).replace(/[\u200e\u200f\u202a-\u202e]/g, '').replace(/\s+/g, ' ').trim();
    v = v.replace(/\s*(?:\||•|·|-)\s*Threads\s*$/i, '').trim();
    v = v.replace(/\s+on\s+Threads\s*$/i, '').trim();
    v = v.replace(/\s*\(@?[^)]*\)\s*$/, '').trim();
    v = v.replace(/(?:['’]s)?\s*profile picture\s*$/i, '').trim();
    if (!v || v.length > 80 || /^@/.test(v)) return null;
    if (/^(thread|threads|log in|login|sign up|home|search|activity|profile|photo|image|avatar)$/i.test(v)) return null;
    if (/privacy policy|terms of service|cookies? policy|report a problem|log in with username/i.test(v)) return null;
    return v;
  };
  const parseCount = (value) => {
    if (value == null) return null;
    const s = String(value).replace(/\u00a0/g, ' ').trim().toLowerCase();
    const m = s.match(/(?:^|[^\d])([0-9]+(?:[.,][0-9]+)?)\s*(k|m|b|тыс\.?|тис\.?|млн\.?|млрд\.?)?(?=$|[^a-zа-я])/i);
    if (!m) return null;
    const suffix = (m[2] || '').replace(/\./g, '');
    const rawNumber = m[1];
    let normalized = rawNumber;
    if (!suffix && /,\d{3}$/.test(rawNumber)) normalized = rawNumber.replace(/,/g, '');
    else normalized = rawNumber.replace(',', '.');
    let n = Number(normalized);
    if (suffix === 'k' || suffix === 'тыс' || suffix === 'тис') n *= 1e3;
    if (suffix === 'm' || suffix === 'млн') n *= 1e6;
    if (suffix === 'b' || suffix === 'млрд') n *= 1e9;
    return Number.isFinite(n) ? Math.round(n) : null;
  };
  const classify = (label) => {
    const low = String(label || '').toLowerCase();
    if (/\b(like|likes|liked)\b|нравится|подобається|вподобан/i.test(low)) return 'likesCount';
    if (/\b(reply|replies|comment|comments)\b|відповід|коментар|ответ|коммент/i.test(low)) return 'repliesCount';
    if (/\b(repost|reposts|reposted|reshare)\b|репост|перепост/i.test(low)) return 'repostsCount';
    if (/\b(quote|quotes)\b|цитат/i.test(low)) return 'quotesCount';
    return null;
  };
  const numberValue = value => {
    if (typeof value === 'number' && Number.isFinite(value)) return Math.round(value);
    if (typeof value === 'string') return parseCount(value);
    return null;
  };

  // Read embedded public page state where available. This is a fallback to the DOM,
  // not an assumption that every Threads response contains serialized post data.
  let embeddedPost = null;
  try {
    const roots = [];
    for (const script of document.scripts) {
      const raw = (script.textContent || '').trim();
      if (!raw || raw.length > 12000000) continue;
      const type = (script.getAttribute('type') || '').toLowerCase();
      if (type.includes('json') || script.id === '__NEXT_DATA__' || /^[\[{]/.test(raw)) {
        try { roots.push(JSON.parse(raw)); } catch (_) {}
      }
    }
    const queue = roots.slice(); const visited = new WeakSet(); let scanned = 0;
    while (queue.length && scanned < 100000 && !embeddedPost) {
      const value = queue.shift();
      if (!value || typeof value !== 'object' || visited.has(value)) continue;
      visited.add(value); scanned++;
      if (!Array.isArray(value)) {
        const code = value.code || value.shortcode || value.short_code;
        const url = value.permalink || value.url || value.web_link;
        if ((code && String(code) === pathId) || (url && postKey(String(url)) === pathId)) {
          embeddedPost = value; break;
        }
      }
      const vals = Array.isArray(value) ? value : Object.values(value);
      for (const child of vals) if (child && typeof child === 'object') queue.push(child);
    }
  } catch (_) {}

  // Locate the exact post card; avoid climbing into a feed containing other posts.
  let best = null, bestScore = -1;
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    if (pathId && postKey(a.href) !== pathId) continue;
    let node = a;
    for (let d = 0; d < 18 && node && node !== document.body; d++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => postKey(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      const rect = node.getBoundingClientRect();
      if (text.length < 8 || rect.width < 160) continue;
      const score = Math.min(text.length, 3000) + (rect.height > 80 ? 40 : 0);
      if (score > bestScore) { best = node; bestScore = score; }
    }
  }
  if (!best) best = document.querySelector('main') || document.body;

  // Username is authoritative from the canonical post URL when present.
  let username = (location.pathname.match(/\/@([^/]+)\/post\//) || [])[1] || null;
  if (!username && embeddedPost) {
    const owner = embeddedPost.user || embeddedPost.owner || embeddedPost.author || {};
    username = owner.username || embeddedPost.username || null;
  }
  if (!username) {
    const profile = Array.from(best.querySelectorAll('a[href*="/@"]')).find(a => /\/@[^/?#]+/.test(a.getAttribute('href') || ''));
    if (profile) username = ((profile.getAttribute('href') || '').match(/\/@([^/?#]+)/) || [])[1] || null;
  }

  // Display name: JSON owner -> page metadata -> matching author profile link.
  let displayName = null;
  const owner = embeddedPost ? (embeddedPost.user || embeddedPost.owner || embeddedPost.author || embeddedPost.thread_owner || {}) : {};
  displayName = cleanName(owner.full_name || owner.fullName || owner.display_name || owner.name || '');
  const metaTitle = document.querySelector('meta[property="og:title"]')?.content ||
                    document.querySelector('meta[name="twitter:title"]')?.content || document.title || '';
  displayName = displayName || cleanName(metaTitle);
  if (!displayName && username) {
    const anchors = Array.from(document.querySelectorAll('a[href*="/@"]'));
    const profileLink = anchors.find(a => {
      const m = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      return m && m[1].toLowerCase() === username.toLowerCase();
    });
    if (profileLink) {
      const scopes = [profileLink, profileLink.parentElement, profileLink.parentElement?.parentElement,
                      profileLink.parentElement?.parentElement?.parentElement];
      for (const scope of scopes) {
        if (!scope || (scope.innerText || '').length > 180) continue;
        const lines = (scope.innerText || '').split('\n').map(x => x.trim()).filter(Boolean);
        const candidate = lines.map(cleanName).find(x => x && x.toLowerCase() !== username.toLowerCase());
        if (candidate) { displayName = candidate; break; }
      }
    }
  }
  if (!displayName) {
    const alts = Array.from(best.querySelectorAll('img[alt]')).map(x => cleanName(x.getAttribute('alt'))).filter(Boolean);
    displayName = alts.find(x => !/^(profile|avatar|photo|image|profile picture)$/i.test(x)) || null;
  }

  // Verified status and profile image.
  let isVerified = null;
  const verified = best.querySelector('[aria-label*="Verified" i], [title*="Verified" i], [aria-label*="Підтвердж" i]');
  if (verified || (embeddedPost && (owner.is_verified === true || owner.isVerified === true))) isVerified = true;
  else if (embeddedPost && (owner.is_verified === false || owner.isVerified === false)) isVerified = false;

  let avatarUrl = abs(owner.profile_pic_url || owner.profile_pic_url_hd || owner.profile_picture_url || '');
  if (!avatarUrl && username) {
    const profileLink = Array.from(document.querySelectorAll('a[href*="/@"]')).find(a => {
      const m = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      return m && m[1].toLowerCase() === username.toLowerCase();
    });
    const img = profileLink?.querySelector('img');
    if (img) avatarUrl = abs(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || '');
  }
  if (!avatarUrl) {
    const img = Array.from(best.querySelectorAll('img')).find(x => /profile|avatar|picture/i.test(x.getAttribute('alt') || ''));
    if (img) avatarUrl = abs(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || '');
  }

  // Timestamp and post text.
  let timestamp = best.querySelector('time[datetime]')?.getAttribute('datetime') || document.querySelector('time[datetime]')?.getAttribute('datetime') || '';
  if (!timestamp && embeddedPost) {
    const rawTs = embeddedPost.taken_at || embeddedPost.created_at || embeddedPost.timestamp;
    if (typeof rawTs === 'number') timestamp = new Date(rawTs * (rawTs < 100000000000 ? 1000 : 1)).toISOString();
    else if (typeof rawTs === 'string') timestamp = rawTs;
  }
  const text = (best.innerText || '').trim();

  // Media: DOM lazy attributes, responsive sources, video sources and embedded post payload.
  const mediaUrls = [];
  const addMedia = value => {
    const u = abs(value);
    if (!u || !/^https?:\/\//i.test(u) || isProfileImage(u, null)) return;
    if (avatarUrl && sameImage(u, avatarUrl)) return;
    if (!mediaUrls.includes(u)) mediaUrls.push(u);
  };
  const addSrcset = value => String(value || '').split(',').forEach(part => addMedia(part.trim().split(/\s+/)[0]));
  for (const img of best.querySelectorAll('img')) {
    const r = img.getBoundingClientRect();
    const inProfile = !!img.closest('a[href*="/@"]');
    if (inProfile && r.width <= 180 && r.height <= 180) continue;
    if (r.width > 0 && r.height > 0 && r.width < 80 && r.height < 80) continue;
    if (/emoji|icon|logo/i.test(img.getAttribute('alt') || '')) continue;
    addMedia(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src'));
    addSrcset(img.getAttribute('srcset'));
  }
  for (const source of best.querySelectorAll('picture source[srcset]')) addSrcset(source.getAttribute('srcset'));
  for (const video of best.querySelectorAll('video')) {
    addMedia(video.currentSrc || video.getAttribute('src') || video.querySelector('source')?.src);
    for (const source of video.querySelectorAll('source[src]')) addMedia(source.src || source.getAttribute('src'));
    addMedia(video.getAttribute('poster'));
  }
  for (const el of best.querySelectorAll('[style*="background"]')) {
    const rect = el.getBoundingClientRect();
    if (rect.width < 80 || rect.height < 80) continue;
    const bg = getComputedStyle(el).backgroundImage || '';
    for (const match of bg.matchAll(/url\(["']?(.*?)["']?\)/g)) addMedia(match[1]);
  }
  if (embeddedPost) {
    const mediaQueue = [embeddedPost]; const seenMedia = new WeakSet(); let mediaScanned = 0;
    while (mediaQueue.length && mediaScanned < 30000) {
      const item = mediaQueue.shift();
      if (!item || typeof item !== 'object' || seenMedia.has(item)) continue;
      seenMedia.add(item); mediaScanned++;
      if (Array.isArray(item)) { for (const child of item) if (child && typeof child === 'object') mediaQueue.push(child); continue; }
      for (const [key, value] of Object.entries(item)) {
        if (typeof value === 'string' && /^(?:url|src|uri)$/i.test(key)) {
          if (/\.(?:jpe?g|png|webp|gif|mp4|m3u8)(?:[?#]|$)|cdninstagram|fbcdn/i.test(value)) addMedia(value);
        } else if (value && typeof value === 'object') mediaQueue.push(value);
      }
    }
  }

  // Engagement counts from public structured data first, then labelled DOM controls.
  const counts = { likesCount: null, repliesCount: null, repostsCount: null, quotesCount: null };
  if (embeddedPost) {
    const aliases = {
      likesCount: ['like_count','likeCount','likes_count'],
      repliesCount: ['reply_count','replyCount','comment_count','comments_count'],
      repostsCount: ['repost_count','repostCount','reshare_count','reshareCount'],
      quotesCount: ['quote_count','quoteCount']
    };
    const metricQueue = [embeddedPost]; const metricSeen = new WeakSet(); let metricScanned = 0;
    while (metricQueue.length && metricScanned < 30000) {
      const obj = metricQueue.shift();
      if (!obj || typeof obj !== 'object' || metricSeen.has(obj)) continue;
      metricSeen.add(obj); metricScanned++;
      if (Array.isArray(obj)) { for (const child of obj) if (child && typeof child === 'object') metricQueue.push(child); continue; }
      for (const [key, value] of Object.entries(obj)) {
        for (const [field, keys] of Object.entries(aliases)) {
          if (keys.includes(key) && counts[field] === null) {
            const n = numberValue(value);
            if (n !== null) counts[field] = n;
          }
        }
        if (value && typeof value === 'object') metricQueue.push(value);
      }
    }
  }
  const findNearbyCount = el => {
    const candidates = [el, el.querySelector?.('span'), el.parentElement, el.parentElement?.parentElement];
    for (const box of candidates) {
      if (!box) continue;
      const direct = (box.innerText || box.textContent || '').replace(/\s+/g, ' ').trim();
      const n = parseCount(direct);
      if (n !== null && direct.length <= 100) return n;
      for (const child of Array.from(box.children || []).slice(0, 8)) {
        const childText = (child.innerText || child.textContent || '').trim();
        const childCount = parseCount(childText);
        if (childCount !== null && childText.length <= 24) return childCount;
      }
    }
    return null;
  };
  for (const el of best.querySelectorAll('[aria-label], [title], [data-testid], button, [role="button"]')) {
    const label = [el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-testid')].filter(Boolean).join(' ');
    const field = classify(label);
    if (!field || counts[field] !== null) continue;
    let n = parseCount(label);
    if (n === null) n = findNearbyCount(el);
    if (n !== null) counts[field] = n;
  }
  // Some public markup places counts in SVG labels while the text sits beside the SVG.
  for (const el of best.querySelectorAll('svg[aria-label], svg[title]')) {
    const field = classify(el.getAttribute('aria-label') || el.getAttribute('title'));
    if (field && counts[field] === null) {
      const n = findNearbyCount(el.closest('button,[role="button"]') || el.parentElement || el);
      if (n !== null) counts[field] = n;
    }
  }

  return {
    username, displayName, isVerified, avatarUrl, timestamp, text,
    mediaUrls: mediaUrls.slice(0, 40),
    likesCount: counts.likesCount, repliesCount: counts.repliesCount,
    repostsCount: counts.repostsCount, quotesCount: counts.quotesCount
  };
}"""


def post_id(url: str) -> str | None:
    m = re.search(r"/post/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else None


def canonical_url(url: str) -> str | None:
    m = re.search(r"/@([^/]+)/post/([A-Za-z0-9_-]+)", url or "")
    if m:
        return f"https://www.threads.com/@{m.group(1)}/post/{m.group(2)}"
    return (url or "").split("?")[0].rstrip("/") or None


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def to_iso_utc(value: str | None) -> str | None:
    dt = parse_timestamp(value)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ") if dt else None


_UI_LINE = re.compile(
    r"(?i)^(?:ланцюжок|ветка|thread|threads|like|reply|replies|views?|перегляд\w*|просмотр\w*|"
    r"подобається|відповісти|поширити|translate|more|see more|читати далі|"
    r"log\s*in|sign\s*up|cookie|follow|стежити|підписатися)$"
)
_VIEWS_PREFIX = re.compile(
    r"(?i)^\s*(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)\s+"
)
_RELATIVE_TIME_PREFIX = re.compile(
    r"(?i)^\s*\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)\s+"
)
_LOGIN_CTA = re.compile(r"(?is)\s*Log\s*in\s*or\s*sign\s*up\s+for\s+Threads\b.*$")
_LOGIN_CTA_UA = re.compile(r"(?is)\s*(?:Увійдіть|Войдите).{0,40}(?:Threads|Тредс).*$")
_SEE_WHAT = re.compile(r"(?is)\s*See\s+what\s+people\s+are\s+talking\s+about.*$")
_JOIN_THREAD = re.compile(r"(?is)\s*join\s+the\s+(?:conversation|community).*$")
_FOOTER_START = re.compile(
    r"(?i)^(?:©\s*\d{4}|threads?\s+terms(?:\s+of\s+use)?|privacy\s+policy|"
    r"consumer\s+health\s+privacy\s+policy|cookies?\s+policy|report\s+a\s+problem|"
    r"log\s*in\s+with\s+username\s+instead|terms\s+of\s+service)$"
)


def clean_post_text(raw: str, author: str = "") -> str:
    """Remove known Threads interface/footer text while preserving the post body."""
    if not raw:
        return ""

    # When a full page was captured, isolate the post area if a recognizable footer follows.
    frame = raw.splitlines()
    if any(_FOOTER_START.match(re.sub(r"\s+", " ", x).strip()) for x in frame):
        cut = next((i for i, x in enumerate(frame)
                    if _FOOTER_START.match(re.sub(r"\s+", " ", x).strip())), len(frame))
        frame = frame[:cut]
    raw = "\n".join(frame)

    author_name = (author or "").lstrip("@").lower()
    lines: list[str] = []
    seen: set[str] = set()
    for raw_line in raw.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line:
            continue
        # Common UI-only date stamp shown above search result cards.
        if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2,4}", line):
            continue
        if _UI_LINE.match(line):
            continue
        if re.fullmatch(r"(?i)(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)", line):
            continue
        if re.fullmatch(r"(?i)\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)", line):
            continue
        if re.fullmatch(r"[\d\s.,kKmM+]+", line) and len(line) < 8:
            continue

        line = _VIEWS_PREFIX.sub("", line)
        line = _RELATIVE_TIME_PREFIX.sub("", line)
        line = _LOGIN_CTA.sub("", line)
        line = _LOGIN_CTA_UA.sub("", line)
        line = _SEE_WHAT.sub("", line)
        line = _JOIN_THREAD.sub("", line)
        line = re.sub(r"(?i)\s*Log\s*in\s+with\s+username\s+instead.*$", "", line)
        line = re.sub(r"(?i)\s*Log\s*in\s*or\s*sign\s*up\b.*$", "", line)
        line = line.strip(" \t|-–—")
        if not line:
            continue
        low = line.lower()
        if author_name and low in {author_name, f"@{author_name}"}:
            continue
        if low in seen and len(low) < 40:
            continue
        seen.add(low)
        lines.append(line)

    return "\n".join(lines).strip()


def clean_display_name(value: Any, username: str | None = None) -> str | None:
    """Reject page titles, handles and obvious UI labels as display names."""
    if not isinstance(value, str):
        return None
    name = re.sub(r"\s+", " ", value).strip().strip("·|-")
    # Threads page titles often append platform text or use the avatar's alt label.
    name = re.sub(r"\s+on\s+Threads\s*$", "", name, flags=re.IGNORECASE).strip()
    if username:
        name = re.sub(rf"\s*\(@?{re.escape(username)}\)\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"(?:['’]s)?\s*profile picture\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"\s*(?:\||•|·|-)\s*Threads\s*$", "", name, flags=re.IGNORECASE).strip()
    if not name or len(name) > 80:
        return None
    low = name.casefold().lstrip("@")
    if username and low == username.casefold().lstrip("@"):
        return None
    if low in {"thread", "threads", "log in", "login", "sign up", "home", "search", "activity", "profile"}:
        return None
    if re.search(r"privacy policy|terms of service|cookies? policy|report a problem|log in with username", low):
        return None
    if re.fullmatch(r"[\d\W_]+", name):
        return None
    return name


def clean_media_urls(values: Any, avatar_url: str | None = None) -> list[str]:
    """Remove profile/avatar image URLs without discarding post media."""
    if not isinstance(values, (list, tuple)):
        return []
    avatar_path = None
    if avatar_url:
        try:
            avatar_path = urlsplit(avatar_url).path
        except Exception:
            avatar_path = None
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str) or not value.startswith(("http://", "https://")):
            continue
        try:
            parsed = urlsplit(value)
            path = parsed.path.lower()
            query = parsed.query.lower()
        except Exception:
            continue
        if re.search(r"/t51\.\d+-19(?:/|$)", path):
            continue
        if re.search(r"(?:profile_pic|profile|avatar)", path):
            continue
        if "s150x150" in query or "s150x150" in path:
            continue
        if avatar_path and parsed.path == avatar_path:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out[:30]


def build_search_url(base: str, query: str, sort: str) -> str:
    base = base.rstrip("/")
    sort = (sort or "recent").lower()
    # Threads web search: recent feed vs default (relevance/top)
    if sort == "top":
        return f"{base}/search?q={quote(query)}&serp_type=default"
    return f"{base}/search?q={quote(query)}&serp_type=default&filter=recent"


def data_completeness(row: dict[str, Any]) -> float:
    """Weighted completeness of meaningful post fields, not mere key presence.

    Empty media is known only after detail extraction; false verification is a
    valid known value. Engagement values remain unknown when Threads exposes no count.
    """
    weights = {
        "postId": 1.0, "postUrl": 1.0, "text": 1.5, "timestamp": 1.0,
        "username": 1.0, "displayName": 0.75, "avatarUrl": 0.5,
        "isVerified": 0.5, "likesCount": 1.0, "repliesCount": 1.0,
        "repostsCount": 1.0, "quotesCount": 0.75, "mediaUrls": 1.0,
    }
    earned = total = 0.0
    for field, weight in weights.items():
        total += weight
        value = row.get(field)
        known = value is not None and value != ""
        if field == "mediaUrls":
            known = isinstance(value, list) and (bool(value) or bool(row.get("detailEnriched")))
        elif field == "isVerified":
            known = isinstance(value, bool)
        if known:
            earned += weight
    return round(earned / total, 3) if total else 0.0


def normalize_record(raw: dict[str, Any], search_query: str) -> dict[str, Any]:
    url = raw.get("url") or raw.get("postUrl") or ""
    pid = post_id(url)
    username = (raw.get("author") or raw.get("username") or "").lstrip("@") or None
    text = clean_post_text(raw.get("text") or "", username or "")
    avatar_url = raw.get("avatarUrl")
    media = clean_media_urls(raw.get("mediaUrls") or [], avatar_url)
    display_name = clean_display_name(raw.get("displayName"), username)
    media_type = None
    if media:
        kinds = {"video" if re.search(r"\.mp4(?:$|[?#])|video|\.m3u8|\.mpd", m, re.I) else "image" for m in media}
        media_type = next(iter(kinds)) if len(kinds) == 1 else "mixed"

    row = {
        "postId": pid,
        "postUrl": url or None,
        "canonicalUrl": canonical_url(url),
        "text": text or None,
        "timestamp": to_iso_utc(raw.get("timestamp")),
        "username": username,
        "displayName": display_name,
        "avatarUrl": avatar_url,
        "isVerified": raw.get("isVerified"),
        "likesCount": raw.get("likesCount"),
        "repliesCount": raw.get("repliesCount"),
        "repostsCount": raw.get("repostsCount"),
        "quotesCount": raw.get("quotesCount"),
        "mediaUrls": media,
        "mediaType": media_type,
        "searchQuery": search_query,
        "scrapedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "schemaVersion": SCHEMA_VERSION,
        "detailEnriched": bool(raw.get("detailEnriched")),
    }
    row["dataCompleteness"] = data_completeness(row)
    return row


def passes_filters(row: dict[str, Any], opts: dict[str, Any]) -> bool:
    text = (row.get("text") or "").lower()
    username = (row.get("username") or "").lower()

    from_user = (opts.get("fromUser") or "").strip().lstrip("@").lower()
    if from_user and username != from_user:
        return False

    include = [kw.lower() for kw in (opts.get("includeKeywords") or []) if kw]
    if include:
        mode = (opts.get("keywordMatchMode") or "all").lower()
        matched = [kw in text for kw in include]
        if (mode == "any" and not any(matched)) or (mode != "any" and not all(matched)):
            return False
    for kw in opts.get("excludeKeywords") or []:
        if kw and kw.lower() in text:
            return False

    min_likes = int(opts.get("minLikes") or 0)
    if min_likes > 0:
        count = row.get("likesCount")
        if count is None or int(count) < min_likes:
            return False
    if opts.get("maxLikes") is not None:
        count = row.get("likesCount")
        if count is None or int(count) > int(opts["maxLikes"]):
            return False
    for field, option in (("repliesCount", "minReplies"), ("repostsCount", "minReposts"), ("quotesCount", "minQuotes")):
        threshold = opts.get(option)
        if threshold is not None:
            count = row.get(field)
            if count is None or int(count) < int(threshold):
                return False

    if opts.get("hasMedia") and not (row.get("mediaUrls") or []):
        return False
    media_types = opts.get("mediaTypes") or []
    if media_types:
        mt = row.get("mediaType")
        if not mt or mt not in media_types:
            return False

    after = opts.get("after")
    before = opts.get("before")
    ts = parse_timestamp(row.get("timestamp"))
    if after:
        adt = parse_timestamp(after if "T" in str(after) else f"{after}T00:00:00Z")
        if adt and ts and ts < adt:
            return False
        if adt and not ts:
            return False
    if before:
        bdt = parse_timestamp(before if "T" in str(before) else f"{before}T00:00:00Z")
        if bdt and ts and ts >= bdt:
            return False
        if bdt and not ts:
            return False

    return True


async def scrape_search(
    page,
    query: str,
    *,
    sort: str = "recent",
    max_pages: int = 5,
    per_page_limit: int = 30,
    base_url: str = "https://www.threads.com",
    log=None,
    retries: int = 3,
) -> list[dict[str, Any]]:
    """Open Threads search, scroll, extract cards. Retry with backoff on failure."""
    url = build_search_url(base_url, query, sort)
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            if log:
                log.info(f"Opening search (attempt {attempt}/{retries}): {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_timeout(2500)

            # Detect login wall (soft)
            title = (await page.title() or "").lower()
            if "log in" in title or "login" in (page.url or "").lower():
                if log:
                    log.warning("Possible login wall on search page")

            collected: dict[str, dict] = {}
            stagnant = 0
            for step in range(max(1, max_pages)):
                batch = await page.evaluate(EXTRACT_POSTS_JS, per_page_limit)
                before = len(collected)
                for item in batch or []:
                    pid = post_id(item.get("url") or "")
                    if not pid:
                        continue
                    old = collected.get(pid)
                    if old is None or len(item.get("text") or "") > len(old.get("text") or ""):
                        collected[pid] = item
                if log:
                    log.info(f"Scroll {step + 1}/{max_pages}: unique={len(collected)}")
                if len(collected) == before:
                    stagnant += 1
                    if stagnant >= 2:
                        break
                else:
                    stagnant = 0
                await page.mouse.wheel(0, 1600)
                await page.wait_for_timeout(1100 + attempt * 100)

            return list(collected.values())
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Search attempt {attempt} failed: {type(exc).__name__}: {exc}")
            await asyncio.sleep(min(8, 1.5 * attempt))
    if last_err:
        raise last_err
    return []


async def enrich_post_detail(
    page,
    post_url: str,
    *,
    log=None,
    retries: int = 2,
) -> dict[str, Any]:
    """Open a single post and extract engagement, profile, media."""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            await page.goto(post_url, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(2000)
            # expand "more" once
            try:
                for label in ("more", "see more", "читати далі", "більше", "ещё", "подробнее"):
                    btn = page.get_by_role("button", name=re.compile(rf"^{label}$", re.I))
                    if await btn.count():
                        await btn.first.click(timeout=1200)
                        await page.wait_for_timeout(300)
                        break
            except Exception:
                pass
            data = await page.evaluate(EXTRACT_DETAIL_JS)
            if not isinstance(data, dict):
                data = {}
            data["detailEnriched"] = True
            return data
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Detail attempt {attempt} for {post_url}: {type(exc).__name__}")
            await asyncio.sleep(min(6, 1.2 * attempt))
    if log and last_err:
        log.warning(f"Detail enrichment failed: {last_err}")
    return {"detailEnriched": False}


def merge_card_and_detail(card: dict[str, Any], detail: dict[str, Any]) -> dict[str, Any]:
    out = dict(card)
    if not detail:
        return out
    # Prefer longer/cleaner text from detail if available
    if detail.get("text") and len(detail.get("text") or "") > len(out.get("text") or ""):
        out["text"] = detail["text"]
    if detail.get("timestamp") and not out.get("timestamp"):
        out["timestamp"] = detail["timestamp"]
    if detail.get("username"):
        out["author"] = detail["username"]
        out["username"] = detail["username"]
    for k in (
        "displayName", "avatarUrl", "isVerified",
        "likesCount", "repliesCount", "repostsCount", "quotesCount",
    ):
        if detail.get(k) is not None:
            out[k] = detail[k]
    # Merge media
    avatar = detail.get("avatarUrl") or out.get("avatarUrl")
    media = clean_media_urls(list(out.get("mediaUrls") or []) + list(detail.get("mediaUrls") or []), avatar)
    out["mediaUrls"] = media
    out["displayName"] = (clean_display_name(detail.get("displayName"), out.get("author") or out.get("username"))
                          or clean_display_name(card.get("displayName"), out.get("author") or out.get("username")))
    out["detailEnriched"] = bool(detail.get("detailEnriched"))
    return out

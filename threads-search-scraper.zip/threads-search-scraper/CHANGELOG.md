# Changelog

## 1.1.0

- Detail enrichment: open post pages for likes, replies, reposts, quotes
- Profile fields: displayName, avatarUrl, isVerified
- Improved media URL extraction from cards and detail pages
- Retry/backoff on search and detail requests
- Stronger scroll pagination with stagnant-feed stop
- Input: `enrichDetails` (default true), `maxDetailEnrich`
- schemaVersion 1.1

## 1.0.0

- Initial Apify Actor release
- Threads keyword search via Playwright
- Dataset output with postId deduplication

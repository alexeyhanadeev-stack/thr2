"""Threads search & extraction (enriched toward Store parity)."""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote

SCHEMA_VERSION = "1.1"

# --- Search feed extraction (card-level) ---
EXTRACT_POSTS_JS = r"""(limit) => {
  const out = [], seen = new Set();
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    const id = key(a.href);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    let best = null, bestText = '', bestTime = '';
    let node = a;
    for (let depth = 0; depth < 18 && node && node !== document.body; depth++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      if (!text || text.length > 18000) continue;
      const times = links.filter(x => key(x.href) === id).map(x => x.querySelector('time[datetime]')).filter(Boolean);
      const ownTime = times[0] || node.querySelector('time[datetime]');
      if (text.length >= bestText.length) {
        best = node; bestText = text;
        if (ownTime) bestTime = ownTime.getAttribute('datetime') || bestTime;
      }
    }
    if (!best) continue;
    const m = a.href.match(/\/@([^/]+)\/post\//);
    const media = [];
    for (const img of best.querySelectorAll('img')) {
      const src = img.getAttribute('src') || '';
      if (src && !/emoji|avatar|profile|icon/i.test(src) && /^https?:\/\//.test(src)) media.push(src);
    }
    for (const v of best.querySelectorAll('video')) {
      const src = v.getAttribute('src') || (v.querySelector('source') && v.querySelector('source').src) || '';
      if (src && /^https?:\/\//.test(src)) media.push(src);
    }
    const more = Array.from(best.querySelectorAll('[role="button"],button')).some(x =>
      /^(?:more|see more|read more|ещ[её]|подробнее|більше|ще|читати далі)$/i.test((x.innerText || '').trim())
    );
    out.push({
      url: a.href.split('?')[0],
      author: m ? m[1] : '',
      text: bestText,
      timestamp: bestTime,
      mediaUrls: Array.from(new Set(media)).slice(0, 20),
      extraction_incomplete: more || bestText.length < 50,
    });
    if (out.length >= limit) break;
  }
  return out;
}"""

# --- Single post detail page enrichment ---
EXTRACT_DETAIL_JS = r"""() => {
  const abs = (u) => {
    if (!u) return null;
    if (u.startsWith('//')) return 'https:' + u;
    return u;
  };
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const pathId = key(location.href);

  // Prefer the main post card for this URL
  let best = null, bestScore = -1;
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    if (pathId && !(a.href || '').includes('/post/' + pathId)) continue;
    let node = a;
    for (let d = 0; d < 18 && node && node !== document.body; d++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      const rect = node.getBoundingClientRect();
      if (text.length < 20 || rect.width < 200) continue;
      const score = Math.min(text.length, 2000) + (rect.height > 80 ? 50 : 0);
      if (score > bestScore) { best = node; bestScore = score; }
    }
  }
  if (!best) best = document.body;

  // Username / profile link
  let username = null;
  const um = (location.pathname || '').match(/\/@([^/]+)\//);
  if (um) username = um[1];
  if (!username) {
    const profile = best.querySelector('a[href*="/@"]');
    if (profile) {
      const pm = (profile.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      if (pm) username = pm[1];
    }
  }

  // Display name: often near username, not the handle itself
  let displayName = null;
  if (username) {
    const candidates = Array.from(best.querySelectorAll('span, a, div')).slice(0, 80);
    for (const el of candidates) {
      const t = (el.innerText || '').trim();
      if (!t || t.length > 80) continue;
      if (t.replace(/^@/, '').toLowerCase() === username.toLowerCase()) continue;
      if (/^\d/.test(t)) continue;
      if (/follow|стежити|подпис/i.test(t)) continue;
      // Heuristic: short text near top of card
      const r = el.getBoundingClientRect();
      if (r.top > 0 && r.top < (best.getBoundingClientRect().top + 120) && t.length >= 2) {
        displayName = t.split('\n')[0].trim();
        break;
      }
    }
  }

  // Verified badge
  let isVerified = null;
  const aria = best.querySelector('[aria-label*="Verified"], [aria-label*="verified"], [aria-label*="Підтвердж"]');
  if (aria) isVerified = true;
  else if (best.querySelector('svg[aria-label*="erif"], img[alt*="erif"]')) isVerified = true;

  // Avatar
  let avatarUrl = null;
  for (const img of best.querySelectorAll('img')) {
    const alt = (img.getAttribute('alt') || '').toLowerCase();
    const src = abs(img.getAttribute('src') || '');
    if (!src || !/^https?:\/\//.test(src)) continue;
    if (/profile|avatar/i.test(src) || /profile|avatar|photo/i.test(alt)) {
      avatarUrl = src;
      break;
    }
  }
  if (!avatarUrl) {
    // first small-ish image near top
    for (const img of best.querySelectorAll('img')) {
      const src = abs(img.getAttribute('src') || '');
      const r = img.getBoundingClientRect();
      if (src && r.width > 20 && r.width < 120 && r.height > 20 && r.height < 120) {
        avatarUrl = src;
        break;
      }
    }
  }

  // Timestamp
  let timestamp = '';
  const timeEl = best.querySelector('time[datetime]') || document.querySelector('time[datetime]');
  if (timeEl) timestamp = timeEl.getAttribute('datetime') || '';

  // Text: remove chrome-ish lines later in Python; take innerText of card
  const text = (best.innerText || '').trim();

  // Media
  const mediaUrls = [];
  for (const img of best.querySelectorAll('img')) {
    const src = abs(img.getAttribute('src') || '');
    if (!src || !/^https?:\/\//.test(src)) continue;
    if (/emoji|avatar|profile|icon|logo/i.test(src)) continue;
    const r = img.getBoundingClientRect();
    if (r.width >= 80 && r.height >= 80) mediaUrls.push(src);
  }
  for (const v of best.querySelectorAll('video')) {
    const src = abs(v.getAttribute('src') || (v.querySelector('source') && v.querySelector('source').src) || '');
    if (src && /^https?:\/\//.test(src)) mediaUrls.push(src);
    const poster = abs(v.getAttribute('poster') || '');
    if (poster && /^https?:\/\//.test(poster)) mediaUrls.push(poster);
  }

  // Engagement: buttons/aria near action bar
  const parseCount = (s) => {
    if (s == null || s === '') return null;
    s = String(s).trim().replace(/,/g, '').toLowerCase();
    const m = s.match(/^(\d+(?:\.\d+)?)([kmb])?$/i);
    if (!m) {
      const d = s.match(/(\d+)/);
      return d ? parseInt(d[1], 10) : null;
    }
    let n = parseFloat(m[1]);
    const u = (m[2] || '').toLowerCase();
    if (u === 'k') n *= 1e3;
    if (u === 'm') n *= 1e6;
    if (u === 'b') n *= 1e9;
    return Math.round(n);
  };

  let likesCount = null, repliesCount = null, repostsCount = null, quotesCount = null;
  const all = Array.from(best.querySelectorAll('[aria-label], button, a, div[role="button"]'));
  for (const el of all) {
    const label = (el.getAttribute('aria-label') || el.innerText || '').replace(/\s+/g, ' ').trim();
    if (!label || label.length > 80) continue;
    const low = label.toLowerCase();
    // e.g. "12 likes", "Like: 12", "5 replies"
    let kind = null;
    if (/\blike|нравится|подоба/i.test(low) && !/unlike/i.test(low)) kind = 'like';
    else if (/\brepl|comment|ответ|відпов/i.test(low)) kind = 'reply';
    else if (/\brepost|retweet|репост/i.test(low)) kind = 'repost';
    else if (/\bquote|цитат/i.test(low)) kind = 'quote';
    if (!kind) continue;
    const numMatch = label.match(/(\d+[\d.,]*\s*[kKmMbB]?)/);
    const n = numMatch ? parseCount(numMatch[1].replace(/\s+/g, '')) : null;
    if (n == null) continue;
    if (kind === 'like' && likesCount == null) likesCount = n;
    if (kind === 'reply' && repliesCount == null) repliesCount = n;
    if (kind === 'repost' && repostsCount == null) repostsCount = n;
    if (kind === 'quote' && quotesCount == null) quotesCount = n;
  }

  return {
    username,
    displayName,
    isVerified,
    avatarUrl,
    timestamp,
    text,
    mediaUrls: Array.from(new Set(mediaUrls)).slice(0, 30),
    likesCount,
    repliesCount,
    repostsCount,
    quotesCount,
  };
}"""


def post_id(url: str) -> str | None:
    m = re.search(r"/post/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else None


def canonical_url(url: str) -> str | None:
    m = re.search(r"/@([^/]+)/post/([A-Za-z0-9_-]+)", url or "")
    if m:
        return f"https://www.threads.com/@{m.group(1)}/post/{m.group(2)}"
    return (url or "").split("?")[0].rstrip("/") or None


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def to_iso_utc(value: str | None) -> str | None:
    dt = parse_timestamp(value)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ") if dt else None


_UI_LINE = re.compile(
    r"(?i)^(?:ланцюжок|ветка|thread|like|reply|replies|views?|перегляд\w*|просмотр\w*|"
    r"подобається|відповісти|поширити|translate|more|see more|читати далі|"
    r"log\s*in|sign\s*up|cookie)\s*$"
)


def clean_post_text(raw: str, author: str = "") -> str:
    if not raw:
        return ""
    if "Новий ланцюжок" in raw and "Політика щодо файлів cookie" in raw:
        frame = raw.splitlines()
        start = None
        for index, value in enumerate(frame[:-1]):
            if value.strip() == "Ланцюжок" and re.fullmatch(
                r"(?:\d+|Один)\s+перегляд\w*", frame[index + 1].strip(), re.I
            ):
                start = index + 2
                break
        if start is not None:
            body = frame[start:]
            end = next(
                (
                    i
                    for i, v in enumerate(body)
                    if re.match(
                        r"Ще немає відповідей|Відповісти користувачу|Переглянути дії|©",
                        v.strip(),
                    )
                ),
                len(body),
            )
            raw = "\n".join(body[:end])

    author_name = (author or "").lstrip("@").lower()
    lines: list[str] = []
    seen: set[str] = set()
    for raw_line in raw.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line:
            continue
        low = line.lower()
        if _UI_LINE.match(line):
            continue
        if re.fullmatch(r"[\d\s.,kKmM+]+", line) and len(line) < 6:
            continue
        if author_name and low == author_name:
            continue
        if low in seen and len(low) < 40:
            continue
        seen.add(low)
        lines.append(line)
    return "\n".join(lines).strip()


def build_search_url(base: str, query: str, sort: str) -> str:
    base = base.rstrip("/")
    sort = (sort or "recent").lower()
    # Threads web search: recent feed vs default (relevance/top)
    if sort == "top":
        return f"{base}/search?q={quote(query)}&serp_type=default"
    return f"{base}/search?q={quote(query)}&serp_type=default&filter=recent"


def data_completeness(row: dict[str, Any]) -> float:
    fields = [
        "postId", "postUrl", "text", "timestamp", "username",
        "displayName", "avatarUrl", "likesCount", "repliesCount",
        "repostsCount", "mediaUrls", "isVerified",
    ]
    w = 1.0 / len(fields)
    score = 0.0
    for f in fields:
        v = row.get(f)
        if v is None or v == "" or v == []:
            continue
        score += w
    return round(score, 3)


def normalize_record(raw: dict[str, Any], search_query: str) -> dict[str, Any]:
    url = raw.get("url") or raw.get("postUrl") or ""
    pid = post_id(url)
    username = (raw.get("author") or raw.get("username") or "").lstrip("@") or None
    text = clean_post_text(raw.get("text") or "", username or "")
    media = list(raw.get("mediaUrls") or [])
    media_type = None
    if media:
        media_type = "video" if any(re.search(r"\.mp4|video|blob:", m, re.I) for m in media) else "image"

    row = {
        "postId": pid,
        "postUrl": url or None,
        "canonicalUrl": canonical_url(url),
        "text": text or None,
        "timestamp": to_iso_utc(raw.get("timestamp")),
        "username": username,
        "displayName": raw.get("displayName"),
        "avatarUrl": raw.get("avatarUrl"),
        "isVerified": raw.get("isVerified"),
        "likesCount": raw.get("likesCount"),
        "repliesCount": raw.get("repliesCount"),
        "repostsCount": raw.get("repostsCount"),
        "quotesCount": raw.get("quotesCount"),
        "mediaUrls": media,
        "mediaType": media_type,
        "searchQuery": search_query,
        "scrapedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "schemaVersion": SCHEMA_VERSION,
        "detailEnriched": bool(raw.get("detailEnriched")),
    }
    row["dataCompleteness"] = data_completeness(row)
    return row


def passes_filters(row: dict[str, Any], opts: dict[str, Any]) -> bool:
    text = (row.get("text") or "").lower()
    username = (row.get("username") or "").lower()

    from_user = (opts.get("fromUser") or "").strip().lstrip("@").lower()
    if from_user and username != from_user:
        return False

    for kw in opts.get("includeKeywords") or []:
        if kw and kw.lower() not in text:
            return False
    for kw in opts.get("excludeKeywords") or []:
        if kw and kw.lower() in text:
            return False

    min_likes = int(opts.get("minLikes") or 0)
    if min_likes > 0 and row.get("likesCount") is not None:
        if int(row["likesCount"]) < min_likes:
            return False

    if opts.get("hasMedia") and not (row.get("mediaUrls") or []):
        return False

    after = opts.get("after")
    before = opts.get("before")
    ts = parse_timestamp(row.get("timestamp"))
    if after:
        adt = parse_timestamp(after if "T" in str(after) else f"{after}T00:00:00Z")
        if adt and ts and ts < adt:
            return False
        if adt and not ts:
            return False
    if before:
        bdt = parse_timestamp(before if "T" in str(before) else f"{before}T00:00:00Z")
        if bdt and ts and ts >= bdt:
            return False
        if bdt and not ts:
            return False

    return True


async def scrape_search(
    page,
    query: str,
    *,
    sort: str = "recent",
    max_pages: int = 5,
    per_page_limit: int = 30,
    base_url: str = "https://www.threads.com",
    log=None,
    retries: int = 3,
) -> list[dict[str, Any]]:
    """Open Threads search, scroll, extract cards. Retry with backoff on failure."""
    url = build_search_url(base_url, query, sort)
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            if log:
                log.info(f"Opening search (attempt {attempt}/{retries}): {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_timeout(2500)

            # Detect login wall (soft)
            title = (await page.title() or "").lower()
            if "log in" in title or "login" in (page.url or "").lower():
                if log:
                    log.warning("Possible login wall on search page")

            collected: dict[str, dict] = {}
            stagnant = 0
            for step in range(max(1, max_pages)):
                batch = await page.evaluate(EXTRACT_POSTS_JS, per_page_limit)
                before = len(collected)
                for item in batch or []:
                    pid = post_id(item.get("url") or "")
                    if not pid:
                        continue
                    old = collected.get(pid)
                    if old is None or len(item.get("text") or "") > len(old.get("text") or ""):
                        collected[pid] = item
                if log:
                    log.info(f"Scroll {step + 1}/{max_pages}: unique={len(collected)}")
                if len(collected) == before:
                    stagnant += 1
                    if stagnant >= 2:
                        break
                else:
                    stagnant = 0
                await page.mouse.wheel(0, 1600)
                await page.wait_for_timeout(1100 + attempt * 100)

            return list(collected.values())
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Search attempt {attempt} failed: {type(exc).__name__}: {exc}")
            await asyncio.sleep(min(8, 1.5 * attempt))
    if last_err:
        raise last_err
    return []


async def enrich_post_detail(
    page,
    post_url: str,
    *,
    log=None,
    retries: int = 2,
) -> dict[str, Any]:
    """Open a single post and extract engagement, profile, media."""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            await page.goto(post_url, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(2000)
            # expand "more" once
            try:
                for label in ("more", "see more", "читати далі", "більше", "ещё", "подробнее"):
                    btn = page.get_by_role("button", name=re.compile(rf"^{label}$", re.I))
                    if await btn.count():
                        await btn.first.click(timeout=1200)
                        await page.wait_for_timeout(300)
                        break
            except Exception:
                pass
            data = await page.evaluate(EXTRACT_DETAIL_JS)
            if not isinstance(data, dict):
                data = {}
            data["detailEnriched"] = True
            return data
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Detail attempt {attempt} for {post_url}: {type(exc).__name__}")
            await asyncio.sleep(min(6, 1.2 * attempt))
    if log and last_err:
        log.warning(f"Detail enrichment failed: {last_err}")
    return {"detailEnriched": False}


def merge_card_and_detail(card: dict[str, Any], detail: dict[str, Any]) -> dict[str, Any]:
    out = dict(card)
    if not detail:
        return out
    # Prefer longer/cleaner text from detail if available
    if detail.get("text") and len(detail.get("text") or "") > len(out.get("text") or ""):
        out["text"] = detail["text"]
    if detail.get("timestamp") and not out.get("timestamp"):
        out["timestamp"] = detail["timestamp"]
    if detail.get("username"):
        out["author"] = detail["username"]
        out["username"] = detail["username"]
    for k in (
        "displayName", "avatarUrl", "isVerified",
        "likesCount", "repliesCount", "repostsCount", "quotesCount",
    ):
        if detail.get(k) is not None:
            out[k] = detail[k]
    # Merge media
    media = list(out.get("mediaUrls") or [])
    for m in detail.get("mediaUrls") or []:
        if m not in media:
            media.append(m)
    out["mediaUrls"] = media[:30]
    out["detailEnriched"] = bool(detail.get("detailEnriched"))
    return out

# Changelog

## 1.2.0
- Added mode router: `posts_search` (default), `user_search`, `post_details`, `replies`, and `media`.
- Preserved legacy Posts Search inputs and output fields; added keyword matching mode and additional filters.
- Added profile extraction, post URL processing, DOM-visible reply collection, and optional media download to Key-Value Store.
- Expanded RUN_SUMMARY with mode, timing, partial/empty states, proxy diagnostics, errors and media statistics.
- Added proxy failure policy and refreshed Apify schemas, examples and documentation.
- Documented public-interface limitations; reply recursion and completeness are not guaranteed.

## 1.1.1
- Improved detail extraction and record normalization.

## 1.1.0
- Initial enriched search implementation with multi-query deduplication, filters and Apify Dataset output.

import unittest
from src.main import validate_input

class InputValidationTests(unittest.TestCase):
    def test_legacy_search_defaults_to_posts_search(self):
        self.assertEqual(validate_input({'searchQuery': 'hello'})[0], 'posts_search')
    def test_multiple_queries_deduplicate(self):
        self.assertEqual(validate_input({'searchQuery':'x','searchQueries':['x','y']})[1], ['x','y'])
    def test_modes_require_their_inputs(self):
        samples = [
            ({'mode':'user_search','userQuery':'creator'}, 'user_search'),
            ({'mode':'post_details','postUrl':'https://www.threads.com/@a/post/ABC'}, 'post_details'),
            ({'mode':'replies','postUrls':['https://www.threads.com/@a/post/ABC']}, 'replies'),
            ({'mode':'media','postUrls':['https://www.threads.com/@a/post/ABC']}, 'media'),
        ]
        for value, expected in samples:
            self.assertEqual(validate_input(value)[0], expected)
    def test_rejects_invalid_mode_and_url(self):
        with self.assertRaises(ValueError): validate_input({'mode':'unknown'})
        with self.assertRaises(ValueError): validate_input({'mode':'media','postUrl':'https://example.com/post/1'})

if __name__ == '__main__': unittest.main()

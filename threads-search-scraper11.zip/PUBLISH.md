# Apify Store publishing and validation

## Store listing metadata

**Recommended title**

Threads Scraper: Posts, Users, Replies & Media

**Short description (under 300 characters)**

Scrape public Threads posts, search users, extract post details and replies, and collect image/video URLs. Includes multi-query search, keyword and date filters, engagement filters when counts are available, deduplication, and structured Apify Dataset exports.

**Primary search phrases to use naturally in the Store listing and README**

- Threads scraper
- Threads post scraper
- Threads search scraper
- Threads profile scraper
- Threads replies scraper
- Threads media scraper
- scrape Threads posts
- Threads data extraction
- Apify Threads Actor

Do not add unsupported claims such as complete search coverage, guaranteed engagement metrics, full user discovery, recursive reply scraping, or guaranteed media downloads.

## Before publishing

1. Run local checks: `python -m compileall -q .` and `python -m unittest discover -s tests -v`.
2. Validate every JSON file under `.actor/` and `examples/`.
3. Confirm `.actor/actor.json`, both source constants, and example output use the same version.
4. Build and test with Apify CLI in a development Actor before publishing to Store.
5. Test each mode independently against current public Threads pages: `posts_search`, `user_search`, `post_details`, `replies`, and `media`.
6. Inspect Dataset rows and `RUN_SUMMARY` in Key-Value Store.
7. Test proxy behavior with both `proxyFailureMode: direct` and `proxyFailureMode: fail`.
8. Confirm legacy input without `mode` still runs `posts_search`.
9. Verify the Store short description is no more than 300 characters in the Apify Console.
10. Publish only after live Cloud tests; local unit tests do not prove that Threads currently exposes a particular DOM field.

## Live-data quality checks

Use a test set containing: (a) a text-only post, (b) a post with an image, (c) a post with a video, (d) a post with visible engagement counts, and (e) a post whose author display name differs from the username. Check that avatar URLs never appear in `mediaUrls`, profile-picture labels are not accepted as display names, and unavailable counts remain `null`.

## 1.2.7 — verified extraction, isolated engagement counters & media resolution

- Fixed `displayName` false positives where view or follower counters (e.g., `"2.5K views"`, `"1.2K followers"`, localized view labels) were captured from post header blocks; added Unicode, emoji, and stylized font support while rejecting UI/metric strings.
- Isolated DOM engagement counter extraction to individual action buttons (`likesCount`, `repliesCount`, `repostsCount`, `quotesCount`) so shared action-bar containers never duplicate `likesCount` into `repostsCount`.
- Expanded post container detection and structured JSON media parsing (`image_versions2.candidates`, `video_versions`, `carousel_media`, `<picture><source>`, `srcset`, and video posters) while keeping author avatars excluded from `mediaUrls`.
- Added `extractionDiagnostics` metadata and ensured `detailEnriched` is `true` only when meaningful post fields are extracted, preventing inflated `dataCompleteness` scores.
- Preserved all five Actor modes (`posts_search`, `user_search`, `post_details`, `replies`, `media`), input parameters, and Apify Store schemas.

## 1.2.6 — post extraction hardening

- Added a bounded parser for serialized public page state, matching the current post by its Threads shortcode before reading author, media and engagement fields.
- Expanded DOM extraction for lazy-loaded images, responsive image sources, video sources/posters, and localized engagement labels/counts.
- Improved author display-name validation and added a profile-page fallback only when post-page name/avatar metadata is missing.
- Kept unavailable engagement values as `null`; no synthetic zero values are introduced.
- Preserved the five existing Actor modes and the v1.2.5 input contract.

## 1.2.5 — Apify Store listing, SEO documentation and author-name cleanup
- Reworked the Store-facing title and short description around the primary Threads scraper use cases and search terms.
- Rebuilt README with keyword-focused but factual sections, quick start, all five modes, filters, output fields, FAQs, limitations and responsible-use guidance.
- Improved input field titles/descriptions and Dataset table labels for clearer Apify Console setup and result inspection.
- Updated output/schema examples and synchronized Actor/schema version to 1.2.5.
- Cleaned common profile-title suffixes such as “on Threads” and generic “profile picture” labels from displayName, based on observed v1.2.4 output.
- No claim is made that engagement counts or post media are available on every public page; unavailable values remain null/empty.

## 1.2.4 — author, engagement, media and completeness improvements
- Improved display-name extraction using Open Graph/Twitter title metadata, the author profile-link block and image alt metadata, with strict rejection of generic labels and usernames.
- Improved engagement extraction to read counts from accessible labels and adjacent action-button containers, including compact K/M/B values and common Ukrainian/Russian labels.
- Expanded media extraction to include rendered image URLs, srcset, picture sources, video sources and posters while retaining avatar/profile filtering.
- Corrected mediaType to distinguish image, video and mixed media.
- Replaced the flat completeness ratio with a weighted score that treats a confirmed empty media list and explicit `isVerified: false` as known, while null engagement metrics remain unknown.
- Added regression tests for media preservation, display-name merge, and completeness scoring.

## 1.2.3 — fixes based on latest posts_search output

- Improved removal of Threads UI text from post bodies: abbreviated view counters (for example `2.6K views`), standalone date labels, login prompts and footer/legal links are removed.
- Added Python-side media URL validation so profile/avatar URLs (including `t51.*-19` and `s150x150` variants, plus the detected avatar itself) are excluded from `mediaUrls` after card/detail merging. Post media URL variants such as `t51.*-15` remain eligible.
- Sanitized `displayName`: generic page labels (`Thread`/`Threads`), UI labels and values identical to the username become `null`.
- Kept completeness scoring based on normalized fields after text, name and media cleanup.
- Unified Actor version and emitted `schemaVersion` at `1.2.4`.
- Added regression tests for the five issues above.

# Changelog

## 1.2.0
- Added mode router: `posts_search` (default), `user_search`, `post_details`, `replies`, and `media`.
- Preserved legacy Posts Search inputs and output fields; added keyword matching mode and additional filters.
- Added profile extraction, post URL processing, DOM-visible reply collection, and optional media download to Key-Value Store.
- Expanded RUN_SUMMARY with mode, timing, partial/empty states, proxy diagnostics, errors and media statistics.
- Added proxy failure policy and refreshed Apify schemas, examples and documentation.
- Documented public-interface limitations; reply recursion and completeness are not guaranteed.

## 1.1.1
- Improved detail extraction and record normalization.

## 1.1.0
- Initial enriched search implementation with multi-query deduplication, filters and Apify Dataset output.

## v1.2.2 — media/profile extraction fix
- Exclude Threads profile-picture assets (`t51.82787-19`, `s150x150`, `profile_pic`) from post `mediaUrls` in both search-card and detail extraction.
- Keep avatar extraction separate from post media and explicitly avoid adding the detected avatar URL to `mediaUrls`.
- Reject generic Threads UI labels (including `Thread`/`Threads`) as `displayName` values rather than returning them as author names.

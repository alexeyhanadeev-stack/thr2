"""Threads search & extraction (v1.2.7 verified extraction)."""

from __future__ import annotations

import asyncio
import re
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote, urlsplit

SCHEMA_VERSION = "1.2.7"

# --- Search feed extraction (card-level) ---
EXTRACT_POSTS_JS = r"""(limit) => {
  const out = [], seen = new Set();
  const key = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src) ||
      /(?:^|[_=&])s150x150(?:[_&]|$)/i.test(src) || /profile|avatar/i.test(alt);
  };
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    const id = key(a.href);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    let best = null, bestText = '', bestTime = '';
    let node = a;
    for (let depth = 0; depth < 18 && node && node !== document.body; depth++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => key(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      if (!text || text.length > 18000) continue;
      const times = links.filter(x => key(x.href) === id).map(x => x.querySelector('time[datetime]')).filter(Boolean);
      const ownTime = times[0] || node.querySelector('time[datetime]');
      if (text.length >= bestText.length) {
        best = node; bestText = text;
        if (ownTime) bestTime = ownTime.getAttribute('datetime') || bestTime;
      }
    }
    if (!best) continue;
    const m = a.href.match(/\/@([^/]+)\/post\//);
    const media = [];
    for (const img of best.querySelectorAll('img')) {
      const src = img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || '';
      const r = img.getBoundingClientRect();
      const inProfileLink = !!img.closest('a[href*="/@"]');
      if (src && !/emoji|icon|logo/i.test(src) && !isProfileImage(src, img) &&
          !(inProfileLink && r.width <= 160 && r.height <= 160) &&
          !(r.width > 0 && r.height > 0 && r.width <= 80 && r.height <= 80) && /^https?:\/\//.test(src)) media.push(src);
    }
    for (const v of best.querySelectorAll('video')) {
      const src = v.currentSrc || v.getAttribute('src') || (v.querySelector('source') && v.querySelector('source').src) || '';
      if (src && /^https?:\/\//.test(src)) media.push(src);
      const poster = v.getAttribute('poster') || '';
      if (poster && /^https?:\/\//.test(poster)) media.push(poster);
    }
    const more = Array.from(best.querySelectorAll('[role="button"],button')).some(x =>
      /^(?:more|see more|read more|ещ[её]|подробнее|більше|ще|читати далі)$/i.test((x.innerText || '').trim())
    );
    out.push({
      url: a.href.split('?')[0],
      author: m ? m[1] : '',
      text: bestText,
      timestamp: bestTime,
      mediaUrls: Array.from(new Set(media)).slice(0, 20),
      extraction_incomplete: more || bestText.length < 50,
    });
    if (out.length >= limit) break;
  }
  return out;
}"""

# --- Single post detail page enrichment (v1.2.7 multi-layer verified extraction) ---
EXTRACT_DETAIL_JS = r"""() => {
  const abs = (u) => {
    if (!u) return null;
    try { return new URL(String(u), location.href).href; } catch (_) { return null; }
  };
  const postKey = href => { const m = (href || '').match(/\/post\/([A-Za-z0-9_-]+)/); return m ? m[1] : ''; };
  const pathId = postKey(location.href);
  const pathAuthor = ((location.pathname.match(/\/@([^/]+)\/post\//) || [])[1] || '').toLowerCase();

  const sameImage = (a, b) => {
    try { const x = new URL(a); const y = new URL(b); return x.pathname === y.pathname; }
    catch (_) { return a === b; }
  };

  const isProfileImage = (src, img) => {
    const alt = (img?.getAttribute('alt') || '').toLowerCase();
    const path = (() => { try { return new URL(src, location.href).pathname; } catch (_) { return src || ''; } })();
    const query = (() => { try { return new URL(src, location.href).search; } catch (_) { return ''; } })();
    return /\/t51\.\d+-19\//i.test(path) || /profile_pic|profile|avatar/i.test(src || '') ||
      /s150x150/i.test(query) || /profile|avatar/i.test(alt);
  };

  const metricOrUiRegex = /^(?:(?:\d+(?:[.,]\d+)?\s*[kmbкмлнтыс]*\.?\s*)?(?:views?|followers?|following|posts?|likes?|replies?|reposts?|quotes?|shares?|перегляд\w*|просмотр\w*|підписник\w*|подписчик\w*|вподобан\w*|відповід\w*|ответ\w*|репост\w*|цитат\w*)|thread|threads|log\s*in|login|sign\s*up|home|search|activity|profile|photo|image|avatar|follow|following|verified|translate|more|see\s*more)$/i;

  const cleanName = (value, expectedUser) => {
    if (!value) return null;
    let v = String(value).replace(/[\u200e\u200f\u202a-\u202e]/g, '').replace(/\s+/g, ' ').trim();
    v = v.replace(/\s*(?:\||•|·|-)\s*Threads\s*$/i, '').trim();
    v = v.replace(/\s+on\s+Threads\s*$/i, '').trim();
    v = v.replace(/\s*\(@?[^)]*\)\s*$/, '').trim();
    v = v.replace(/(?:['’]s)?\s*profile picture\s*$/i, '').trim();
    if (!v || v.length > 80 || /^@/.test(v)) return null;
    if (expectedUser && v.toLowerCase() === expectedUser.toLowerCase()) return null;
    if (metricOrUiRegex.test(v)) return null;
    if (/privacy policy|terms of service|cookies? policy|report a problem|log in with username/i.test(v)) return null;
    if (/^[\d\s.,:;!?@#$%^&*()_+=\-\[\]{}<>/\\|~`'\"·•—–]+$/.test(v)) return null;
    return v;
  };

  const parseCount = (value) => {
    if (value == null) return null;
    const s = String(value).replace(/\u00a0/g, ' ').trim().toLowerCase();
    const m = s.match(/(?:^|[^\d])([0-9]+(?:[.,][0-9]+)?)\s*(k|m|b|тыс\.?|тис\.?|млн\.?|млрд\.?)?(?=$|[^a-zа-я])/i);
    if (!m) return null;
    const suffix = (m[2] || '').replace(/\./g, '');
    const rawNumber = m[1];
    let normalized = rawNumber;
    if (!suffix && /,\d{3}$/.test(rawNumber)) normalized = rawNumber.replace(/,/g, '');
    else normalized = rawNumber.replace(',', '.');
    let n = Number(normalized);
    if (suffix === 'k' || suffix === 'тыс' || suffix === 'тис') n *= 1e3;
    if (suffix === 'm' || suffix === 'млн') n *= 1e6;
    if (suffix === 'b' || suffix === 'млрд') n *= 1e9;
    return Number.isFinite(n) ? Math.round(n) : null;
  };

  const classify = (label) => {
    const low = String(label || '').toLowerCase();
    if (/\b(like|likes|liked)\b|нравится|подобається|вподобан/i.test(low)) return 'likesCount';
    if (/\b(reply|replies|comment|comments)\b|відповід|коментар|ответ|коммент/i.test(low)) return 'repliesCount';
    if (/\b(repost|reposts|reposted|reshare)\b|репост|перепост/i.test(low)) return 'repostsCount';
    if (/\b(quote|quotes)\b|цитат/i.test(low)) return 'quotesCount';
    return null;
  };

  const numberValue = value => {
    if (typeof value === 'number' && Number.isFinite(value)) return Math.round(value);
    if (typeof value === 'string') return parseCount(value);
    return null;
  };

  const diagnostics = {
    embeddedFound: false,
    displayNameSource: null,
    metricsSource: {},
    mediaSources: [],
    domMatched: false,
  };

  // 1. Parse embedded public JSON state (Relay/GraphQL/Next) matching exact post shortcode
  let embeddedPost = null;
  try {
    const roots = [];
    for (const script of document.scripts) {
      const raw = (script.textContent || '').trim();
      if (!raw || raw.length > 15000000) continue;
      const type = (script.getAttribute('type') || '').toLowerCase();
      if (type.includes('json') || script.id === '__NEXT_DATA__' || /^[\[{]/.test(raw)) {
        try { roots.push(JSON.parse(raw)); } catch (_) {}
      }
    }
    const queue = roots.slice();
    const visited = new WeakSet();
    let scanned = 0;
    while (queue.length && scanned < 150000 && !embeddedPost) {
      const value = queue.shift();
      if (!value || typeof value !== 'object' || visited.has(value)) continue;
      visited.add(value);
      scanned++;
      if (!Array.isArray(value)) {
        const candidate = value.post && typeof value.post === 'object' ? value.post : value;
        const code = candidate.code || candidate.shortcode || candidate.short_code;
        const url = candidate.permalink || candidate.url || candidate.web_link;
        if ((code && String(code) === pathId) || (url && postKey(String(url)) === pathId)) {
          const ownerObj = candidate.user || candidate.owner || candidate.author || candidate.thread_owner || {};
          const candUser = (ownerObj.username || candidate.username || '').toLowerCase();
          if (!pathAuthor || !candUser || candUser === pathAuthor) {
            embeddedPost = candidate;
            diagnostics.embeddedFound = true;
            break;
          }
        }
      }
      const vals = Array.isArray(value) ? value : Object.values(value);
      for (const child of vals) {
        if (child && typeof child === 'object') queue.push(child);
      }
    }
  } catch (_) {}

  // 2. Locate the exact post container in DOM (including sibling media blocks, stopping before other posts)
  let best = null, bestScore = -1;
  for (const a of document.querySelectorAll('a[href*="/post/"]')) {
    if (pathId && postKey(a.href) !== pathId) continue;
    let node = a;
    for (let d = 0; d < 20 && node && node !== document.body; d++, node = node.parentElement) {
      const links = Array.from(node.querySelectorAll('a[href*="/post/"]'));
      const ids = new Set(links.map(x => postKey(x.href)).filter(Boolean));
      if (ids.size > 1) break;
      const text = (node.innerText || '').trim();
      const rect = node.getBoundingClientRect();
      if (text.length < 5 || rect.width < 160) continue;
      const hasMediaEl = node.querySelector('img, video, picture') ? 200 : 0;
      const score = Math.min(text.length, 3000) + hasMediaEl + (rect.height > 80 ? 40 : 0);
      if (score > bestScore) {
        best = node;
        bestScore = score;
        diagnostics.domMatched = true;
      }
    }
  }
  if (!best) best = document.querySelector('main') || document.body;

  // 3. Author username (authoritative from URL -> JSON -> profile anchor)
  let username = (location.pathname.match(/\/@([^/]+)\/post\//) || [])[1] || null;
  const owner = embeddedPost ? (embeddedPost.user || embeddedPost.owner || embeddedPost.author || embeddedPost.thread_owner || {}) : {};
  if (!username && owner.username) username = String(owner.username);
  if (!username) {
    const profile = Array.from(best.querySelectorAll('a[href*="/@"]')).find(a => /\/@[^/?#]+/.test(a.getAttribute('href') || ''));
    if (profile) username = ((profile.getAttribute('href') || '').match(/\/@([^/?#]+)/) || [])[1] || null;
  }

  // 4. Display name (strictly validated against metric/UI labels and verified against username)
  let displayName = null;
  const ownerUsername = (owner.username || username || '').toLowerCase();
  if (!username || !ownerUsername || ownerUsername === username.toLowerCase()) {
    const jsonName = cleanName(owner.full_name || owner.fullName || owner.display_name || owner.name || '', username);
    if (jsonName) {
      displayName = jsonName;
      diagnostics.displayNameSource = 'embedded_json';
    }
  }
  if (!displayName) {
    const metaTitle = document.querySelector('meta[property="og:title"]')?.content ||
                      document.querySelector('meta[name="twitter:title"]')?.content || document.title || '';
    // Only trust metaTitle if it references the author or is not a generic post snippet
    if (!username || metaTitle.toLowerCase().includes(username.toLowerCase()) || /\(@[^)]+\)/.test(metaTitle)) {
      const metaName = cleanName(metaTitle, username);
      if (metaName) {
        displayName = metaName;
        diagnostics.displayNameSource = 'meta_title';
      }
    }
  }
  if (!displayName && username) {
    const anchors = Array.from(best.querySelectorAll('a[href*="/@"]'));
    const profileLink = anchors.find(a => {
      const m = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      return m && m[1].toLowerCase() === username.toLowerCase();
    });
    if (profileLink) {
      // Check anchor text and immediate header row only (max 2 levels, avoiding view counters)
      const scopes = [profileLink, profileLink.parentElement];
      for (const scope of scopes) {
        if (!scope || (scope.innerText || '').length > 120) continue;
        const lines = (scope.innerText || '').split('\n').map(x => x.trim()).filter(Boolean);
        const candidate = lines.map(x => cleanName(x, username)).find(Boolean);
        if (candidate) {
          displayName = candidate;
          diagnostics.displayNameSource = 'dom_profile_link';
          break;
        }
      }
    }
  }
  if (!displayName) {
    const imgs = Array.from(best.querySelectorAll('img[alt]'));
    for (const img of imgs) {
      const alt = img.getAttribute('alt') || '';
      if (/profile picture/i.test(alt)) {
        const candidate = cleanName(alt, username);
        if (candidate) {
          displayName = candidate;
          diagnostics.displayNameSource = 'avatar_alt';
          break;
        }
      }
    }
  }

  // 5. Verified status and avatar
  let isVerified = null;
  const verifiedEl = best.querySelector('[aria-label*="Verified" i], [title*="Verified" i], [aria-label*="Підтвердж" i]');
  if (verifiedEl || owner.is_verified === true || owner.isVerified === true) isVerified = true;
  else if (owner.is_verified === false || owner.isVerified === false) isVerified = false;

  let avatarUrl = abs(owner.profile_pic_url || owner.profile_pic_url_hd || owner.profile_picture_url || '');
  if (!avatarUrl && username) {
    const profileLink = Array.from(best.querySelectorAll('a[href*="/@"]')).find(a => {
      const m = (a.getAttribute('href') || '').match(/\/@([^/?#]+)/);
      return m && m[1].toLowerCase() === username.toLowerCase();
    });
    const img = profileLink?.querySelector('img');
    if (img) avatarUrl = abs(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || '');
  }
  if (!avatarUrl) {
    const img = Array.from(best.querySelectorAll('img')).find(x => /profile|avatar|picture/i.test(x.getAttribute('alt') || ''));
    if (img) avatarUrl = abs(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || '');
  }

  // 6. Timestamp and text
  let timestamp = best.querySelector('time[datetime]')?.getAttribute('datetime') || document.querySelector('time[datetime]')?.getAttribute('datetime') || '';
  if (!timestamp && embeddedPost) {
    const rawTs = embeddedPost.taken_at || embeddedPost.created_at || embeddedPost.timestamp;
    if (typeof rawTs === 'number') timestamp = new Date(rawTs * (rawTs < 100000000000 ? 1000 : 1)).toISOString();
    else if (typeof rawTs === 'string') timestamp = rawTs;
  }
  const text = (best.innerText || '').trim();

  // 7. Media extraction (images, carousels, videos, posters, picture/source, structured candidates)
  const mediaUrls = [];
  const addMedia = (value, sourceTag) => {
    const u = abs(value);
    if (!u || !/^https?:\/\//i.test(u) || isProfileImage(u, null)) return;
    if (avatarUrl && sameImage(u, avatarUrl)) return;
    if (!mediaUrls.includes(u)) {
      mediaUrls.push(u);
      if (sourceTag && !diagnostics.mediaSources.includes(sourceTag)) {
        diagnostics.mediaSources.push(sourceTag);
      }
    }
  };
  const pickBestSrcset = (srcset) => {
    const parts = String(srcset || '').split(',').map(p => p.trim()).filter(Boolean);
    let bestUrl = null, bestW = -1;
    for (const part of parts) {
      const [u, descriptor] = part.split(/\s+/);
      const w = descriptor && descriptor.endsWith('w') ? parseInt(descriptor, 10) : 0;
      if (u && w >= bestW) { bestW = w; bestUrl = u; }
    }
    return bestUrl || (parts[parts.length - 1]?.split(/\s+/)[0] || null);
  };

  // 7a. Structured JSON media first (preserves carousel order & highest resolution)
  if (embeddedPost) {
    const extractFromMediaNode = (node) => {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node.video_versions) && node.video_versions.length) {
        const sortedVids = [...node.video_versions].sort((a, b) => (b.width || 0) - (a.width || 0));
        if (sortedVids[0]?.url) addMedia(sortedVids[0].url, 'json_video_versions');
      }
      if (node.image_versions2 && Array.isArray(node.image_versions2.candidates) && node.image_versions2.candidates.length) {
        const sortedImgs = [...node.image_versions2.candidates].sort((a, b) => (b.width || 0) - (a.width || 0));
        if (sortedImgs[0]?.url) addMedia(sortedImgs[0].url, 'json_image_candidates');
      }
    };
    if (Array.isArray(embeddedPost.carousel_media) && embeddedPost.carousel_media.length) {
      for (const item of embeddedPost.carousel_media) extractFromMediaNode(item);
    } else {
      extractFromMediaNode(embeddedPost);
    }
    // Generic fallback scan inside embeddedPost for media URLs
    const mediaQueue = [embeddedPost];
    const seenMedia = new WeakSet();
    let mediaScanned = 0;
    while (mediaQueue.length && mediaScanned < 30000) {
      const item = mediaQueue.shift();
      if (!item || typeof item !== 'object' || seenMedia.has(item)) continue;
      seenMedia.add(item);
      mediaScanned++;
      if (Array.isArray(item)) {
        for (const child of item) if (child && typeof child === 'object') mediaQueue.push(child);
        continue;
      }
      for (const [key, value] of Object.entries(item)) {
        if (typeof value === 'string' && /^(?:url|src|uri|video_url|image_url|display_url)$/i.test(key)) {
          if (/\.(?:jpe?g|png|webp|mp4|m3u8)(?:[?#]|$)/i.test(value) && /cdninstagram|fbcdn/i.test(value)) {
            addMedia(value, 'json_url_scan');
          }
        } else if (value && typeof value === 'object') {
          mediaQueue.push(value);
        }
      }
    }
  }

  // 7b. DOM media elements (img, picture/source, video/source/poster)
  for (const picture of best.querySelectorAll('picture')) {
    if (picture.closest('a[href*="/@"]')) continue;
    for (const source of picture.querySelectorAll('source[srcset]')) {
      addMedia(pickBestSrcset(source.getAttribute('srcset')), 'dom_picture_source');
    }
  }
  for (const img of best.querySelectorAll('img')) {
    const r = img.getBoundingClientRect();
    const inProfile = !!img.closest('a[href*="/@"]');
    if (inProfile && r.width <= 180 && r.height <= 180) continue;
    if (r.width > 0 && r.height > 0 && r.width < 80 && r.height < 80) continue;
    if (/emoji|icon|logo/i.test(img.getAttribute('alt') || '')) continue;
    const srcsetBest = pickBestSrcset(img.getAttribute('srcset'));
    if (srcsetBest) addMedia(srcsetBest, 'dom_img_srcset');
    addMedia(img.currentSrc || img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src'), 'dom_img');
  }
  for (const video of best.querySelectorAll('video')) {
    addMedia(video.currentSrc || video.getAttribute('src') || video.querySelector('source')?.src, 'dom_video');
    for (const source of video.querySelectorAll('source[src]')) {
      addMedia(source.src || source.getAttribute('src'), 'dom_video_source');
    }
    addMedia(video.getAttribute('poster'), 'dom_video_poster');
  }

  // 8. Independent engagement counters (preventing cross-button pollution)
  const counts = { likesCount: null, repliesCount: null, repostsCount: null, quotesCount: null };

  // 8a. Structured JSON metrics first (exact key match on embeddedPost top-level or immediate feedback object)
  if (embeddedPost) {
    const metricContainers = [
      embeddedPost,
      embeddedPost.feedback,
      embeddedPost.text_post_app_info,
      embeddedPost.counts
    ].filter(x => x && typeof x === 'object');

    const keyMap = {
      likesCount: ['like_count', 'likeCount', 'likes_count'],
      repliesCount: ['reply_count', 'replyCount', 'comment_count', 'comments_count', 'direct_reply_count'],
      repostsCount: ['repost_count', 'repostCount', 'reshare_count', 'reshareCount'],
      quotesCount: ['quote_count', 'quoteCount']
    };

    for (const container of metricContainers) {
      for (const [field, aliases] of Object.entries(keyMap)) {
        if (counts[field] !== null) continue;
        for (const alias of aliases) {
          if (alias in container) {
            const n = numberValue(container[alias]);
            if (n !== null) {
              counts[field] = n;
              diagnostics.metricsSource[field] = 'embedded_json';
              break;
            }
          }
        }
      }
    }
  }

  // 8b. Isolated DOM button extraction (NEVER climb to shared action-bar parent containing other buttons!)
  const findIsolatedButtonCount = (btnEl) => {
    if (!btnEl) return null;
    // Check inside the button itself
    const ownText = (btnEl.innerText || btnEl.textContent || '').replace(/\s+/g, ' ').trim();
    if (ownText && ownText.length <= 24) {
      const n = parseCount(ownText);
      if (n !== null) return n;
    }
    // Check immediate sibling span/div ONLY if parent has no other action buttons/svgs
    const parent = btnEl.parentElement;
    if (parent) {
      const interactiveCount = parent.querySelectorAll('button, [role="button"], svg').length;
      if (interactiveCount <= 1) {
        const parentText = (parent.innerText || parent.textContent || '').replace(/\s+/g, ' ').trim();
        if (parentText && parentText.length <= 24) {
          const n = parseCount(parentText);
          if (n !== null) return n;
        }
      }
    }
    return null;
  };

  for (const el of best.querySelectorAll('button, [role="button"]')) {
    const svg = el.querySelector('svg[aria-label], svg[title]');
    const label = [
      el.getAttribute('aria-label'),
      el.getAttribute('title'),
      el.getAttribute('data-testid'),
      svg?.getAttribute('aria-label'),
      svg?.getAttribute('title')
    ].filter(Boolean).join(' ');
    const field = classify(label);
    if (!field || counts[field] !== null) continue;
    let n = parseCount(label);
    if (n === null) n = findIsolatedButtonCount(el);
    if (n !== null) {
      counts[field] = n;
      diagnostics.metricsSource[field] = 'dom_isolated_button';
    }
  }

  return {
    username,
    displayName,
    isVerified,
    avatarUrl,
    timestamp,
    text,
    mediaUrls: mediaUrls.slice(0, 40),
    likesCount: counts.likesCount,
    repliesCount: counts.repliesCount,
    repostsCount: counts.repostsCount,
    quotesCount: counts.quotesCount,
    extractionDiagnostics: diagnostics
  };
}"""


def post_id(url: str) -> str | None:
    m = re.search(r"/post/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else None


def canonical_url(url: str) -> str | None:
    m = re.search(r"/@([^/]+)/post/([A-Za-z0-9_-]+)", url or "")
    if m:
        return f"https://www.threads.com/@{m.group(1)}/post/{m.group(2)}"
    return (url or "").split("?")[0].rstrip("/") or None


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def to_iso_utc(value: str | None) -> str | None:
    dt = parse_timestamp(value)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ") if dt else None


_UI_LINE = re.compile(
    r"(?i)^(?:ланцюжок|ветка|thread|threads|like|reply|replies|views?|перегляд\w*|просмотр\w*|"
    r"подобається|відповісти|поширити|translate|more|see more|читати далі|"
    r"log\s*in|sign\s*up|cookie|follow|стежити|підписатися)$"
)
_VIEWS_PREFIX = re.compile(
    r"(?i)^\s*(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)\s+"
)
_RELATIVE_TIME_PREFIX = re.compile(
    r"(?i)^\s*\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)\s+"
)
_LOGIN_CTA = re.compile(r"(?is)\s*Log\s*in\s*or\s*sign\s*up\s+for\s+Threads\b.*$")
_LOGIN_CTA_UA = re.compile(r"(?is)\s*(?:Увійдіть|Войдите).{0,40}(?:Threads|Тредс).*$")
_SEE_WHAT = re.compile(r"(?is)\s*See\s+what\s+people\s+are\s+talking\s+about.*$")
_JOIN_THREAD = re.compile(r"(?is)\s*join\s+the\s+(?:conversation|community).*$")
_FOOTER_START = re.compile(
    r"(?i)^(?:©\s*\d{4}|threads?\s+terms(?:\s+of\s+use)?|privacy\s+policy|"
    r"consumer\s+health\s+privacy\s+policy|cookies?\s+policy|report\s+a\s+problem|"
    r"log\s*in\s+with\s+username\s+instead|terms\s+of\s+service)$"
)

_METRIC_OR_UI_DISPLAY_RE = re.compile(
    r"(?i)^(?:"
    r"(?:\d+(?:[.,]\d+)?\s*[kmbкмлнтыс]*\.?\s*)?(?:views?|followers?|following|posts?|likes?|replies?|reposts?|quotes?|shares?|"
    r"перегляд\w*|просмотр\w*|підписник\w*|подписчик\w*|вподобан\w*|відповід\w*|ответ\w*|репост\w*|цитат\w*)|"
    r"thread|threads|log\s*in|login|sign\s*up|home|search|activity|profile|follow|following|verified|translate|more|see\s*more"
    r")$"
)


def clean_post_text(raw: str, author: str = "") -> str:
    """Remove known Threads interface/footer text while preserving the post body."""
    if not raw:
        return ""

    frame = raw.splitlines()
    if any(_FOOTER_START.match(re.sub(r"\s+", " ", x).strip()) for x in frame):
        cut = next((i for i, x in enumerate(frame)
                    if _FOOTER_START.match(re.sub(r"\s+", " ", x).strip())), len(frame))
        frame = frame[:cut]
    raw = "\n".join(frame)

    author_name = (author or "").lstrip("@").lower()
    lines: list[str] = []
    seen: set[str] = set()
    for raw_line in raw.splitlines():
        line = re.sub(r"\s+", " ", raw_line).strip()
        if not line:
            continue
        if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{2,4}", line):
            continue
        if _UI_LINE.match(line):
            continue
        if re.fullmatch(r"(?i)(?:\d+(?:[.,]\d+)?\s*[kmb]?|one)\s*(?:views?|перегляд\w*|просмотр\w*)", line):
            continue
        if re.fullmatch(r"(?i)\d+\s*(?:s|m|h|d|w|sec|min|mins|hour|hours|day|days|тиж\w*|год\w*|хв\w*|дн\w*)", line):
            continue
        if re.fullmatch(r"[\d\s.,kKmM+]+", line) and len(line) < 8:
            continue

        line = _VIEWS_PREFIX.sub("", line)
        line = _RELATIVE_TIME_PREFIX.sub("", line)
        line = _LOGIN_CTA.sub("", line)
        line = _LOGIN_CTA_UA.sub("", line)
        line = _SEE_WHAT.sub("", line)
        line = _JOIN_THREAD.sub("", line)
        line = re.sub(r"(?i)\s*Log\s*in\s+with\s+username\s+instead.*$", "", line)
        line = re.sub(r"(?i)\s*Log\s*in\s*or\s*sign\s*up\b.*$", "", line)
        line = line.strip(" \t|-–—")
        if not line:
            continue
        low = line.lower()
        if author_name and low in {author_name, f"@{author_name}"}:
            continue
        if low in seen and len(low) < 40:
            continue
        seen.add(low)
        lines.append(line)

    return "\n".join(lines).strip()


def clean_display_name(value: Any, username: str | None = None) -> str | None:
    """Reject page titles, view/follower counters, handles and UI labels as display names.
    Preserves Unicode, emoji and stylized fonts.
    """
    if not isinstance(value, str):
        return None
    name = re.sub(r"[\u200e\u200f\u202a-\u202e]", "", value)
    name = re.sub(r"\s+", " ", name).strip().strip("·|-")
    name = re.sub(r"\s+on\s+Threads\s*$", "", name, flags=re.IGNORECASE).strip()
    if username:
        name = re.sub(rf"\s*\(@?{re.escape(username)}\)\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"(?:['’]s)?\s*profile picture\s*$", "", name, flags=re.IGNORECASE).strip()
    name = re.sub(r"\s*(?:\||•|·|-)\s*Threads\s*$", "", name, flags=re.IGNORECASE).strip()
    if not name or len(name) > 80 or name.startswith("@"):
        return None
    low = name.casefold().lstrip("@")
    if username and low == username.casefold().lstrip("@"):
        return None
    if _METRIC_OR_UI_DISPLAY_RE.match(name):
        return None
    if re.search(r"privacy policy|terms of service|cookies? policy|report a problem|log in with username", low):
        return None
    # Reject pure punctuation/digits, while allowing emoji-only or Unicode stylized names
    if re.fullmatch(r"[\d\s.,:;!?@#$%^&*()_+=\-\[\]{}<>/\\|~`'\"·•—–]+", name):
        return None
    return name


def clean_media_urls(values: Any, avatar_url: str | None = None) -> list[str]:
    """Remove profile/avatar image URLs without discarding post media."""
    if not isinstance(values, (list, tuple)):
        return []
    avatar_path = None
    if avatar_url:
        try:
            avatar_path = urlsplit(avatar_url).path
        except Exception:
            avatar_path = None
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        if not isinstance(value, str) or not value.startswith(("http://", "https://")):
            continue
        try:
            parsed = urlsplit(value)
            path = parsed.path.lower()
            query = parsed.query.lower()
        except Exception:
            continue
        if re.search(r"/t51\.\d+-19(?:/|$)", path):
            continue
        if re.search(r"(?:profile_pic|profile|avatar)", path):
            continue
        if "s150x150" in query or "s150x150" in path:
            continue
        if avatar_path and parsed.path == avatar_path:
            continue
        if value not in seen:
            seen.add(value)
            out.append(value)
    return out[:30]


def build_search_url(base: str, query: str, sort: str) -> str:
    base = base.rstrip("/")
    sort = (sort or "recent").lower()
    if sort == "top":
        return f"{base}/search?q={quote(query)}&serp_type=default"
    return f"{base}/search?q={quote(query)}&serp_type=default&filter=recent"


def data_completeness(row: dict[str, Any]) -> float:
    """Weighted completeness of validated, non-null meaningful post fields."""
    weights = {
        "postId": 1.0, "postUrl": 1.0, "text": 1.5, "timestamp": 1.0,
        "username": 1.0, "displayName": 0.75, "avatarUrl": 0.5,
        "isVerified": 0.5, "likesCount": 1.0, "repliesCount": 1.0,
        "repostsCount": 1.0, "quotesCount": 0.75, "mediaUrls": 1.0,
    }
    earned = total = 0.0
    for field, weight in weights.items():
        total += weight
        value = row.get(field)
        known = value is not None and value != ""
        if field == "mediaUrls":
            known = isinstance(value, list) and (bool(value) or bool(row.get("detailEnriched")))
        elif field == "isVerified":
            known = isinstance(value, bool)
        if known:
            earned += weight
    return round(earned / total, 3) if total else 0.0


def normalize_record(raw: dict[str, Any], search_query: str) -> dict[str, Any]:
    url = raw.get("url") or raw.get("postUrl") or ""
    pid = post_id(url)
    username = (raw.get("author") or raw.get("username") or "").lstrip("@") or None
    text = clean_post_text(raw.get("text") or "", username or "")
    avatar_url = raw.get("avatarUrl")
    media = clean_media_urls(raw.get("mediaUrls") or [], avatar_url)
    display_name = clean_display_name(raw.get("displayName"), username)
    media_type = None
    if media:
        kinds = {"video" if re.search(r"\.mp4(?:$|[?#])|video|\.m3u8|\.mpd", m, re.I) else "image" for m in media}
        media_type = next(iter(kinds)) if len(kinds) == 1 else "mixed"

    likes = raw.get("likesCount")
    replies = raw.get("repliesCount")
    reposts = raw.get("repostsCount")
    quotes = raw.get("quotesCount")

    row = {
        "postId": pid,
        "postUrl": url or None,
        "canonicalUrl": canonical_url(url),
        "text": text or None,
        "timestamp": to_iso_utc(raw.get("timestamp")),
        "username": username,
        "displayName": display_name,
        "avatarUrl": avatar_url,
        "isVerified": raw.get("isVerified"),
        "likesCount": likes,
        "repliesCount": replies,
        "repostsCount": reposts,
        "quotesCount": quotes,
        "mediaUrls": media,
        "mediaType": media_type,
        "searchQuery": search_query,
        "scrapedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "schemaVersion": SCHEMA_VERSION,
        "detailEnriched": bool(raw.get("detailEnriched")),
    }
    if isinstance(raw.get("extractionDiagnostics"), dict):
        row["extractionDiagnostics"] = raw["extractionDiagnostics"]
    row["dataCompleteness"] = data_completeness(row)
    return row


def passes_filters(row: dict[str, Any], opts: dict[str, Any]) -> bool:
    text = (row.get("text") or "").lower()
    username = (row.get("username") or "").lower()

    from_user = (opts.get("fromUser") or "").strip().lstrip("@").lower()
    if from_user and username != from_user:
        return False

    include = [kw.lower() for kw in (opts.get("includeKeywords") or []) if kw]
    if include:
        mode = (opts.get("keywordMatchMode") or "all").lower()
        matched = [kw in text for kw in include]
        if (mode == "any" and not any(matched)) or (mode != "any" and not all(matched)):
            return False
    for kw in opts.get("excludeKeywords") or []:
        if kw and kw.lower() in text:
            return False

    min_likes = int(opts.get("minLikes") or 0)
    if min_likes > 0:
        count = row.get("likesCount")
        if count is None or int(count) < min_likes:
            return False
    if opts.get("maxLikes") is not None:
        count = row.get("likesCount")
        if count is None or int(count) > int(opts["maxLikes"]):
            return False
    for field, option in (("repliesCount", "minReplies"), ("repostsCount", "minReposts"), ("quotesCount", "minQuotes")):
        threshold = opts.get(option)
        if threshold is not None:
            count = row.get(field)
            if count is None or int(count) < int(threshold):
                return False

    if opts.get("hasMedia") and not (row.get("mediaUrls") or []):
        return False
    media_types = opts.get("mediaTypes") or []
    if media_types:
        mt = row.get("mediaType")
        if not mt or mt not in media_types:
            return False

    after = opts.get("after")
    before = opts.get("before")
    ts = parse_timestamp(row.get("timestamp"))
    if after:
        adt = parse_timestamp(after if "T" in str(after) else f"{after}T00:00:00Z")
        if adt and ts and ts < adt:
            return False
        if adt and not ts:
            return False
    if before:
        bdt = parse_timestamp(before if "T" in str(before) else f"{before}T00:00:00Z")
        if bdt and ts and ts >= bdt:
            return False
        if bdt and not ts:
            return False

    return True


async def scrape_search(
    page,
    query: str,
    *,
    sort: str = "recent",
    max_pages: int = 5,
    per_page_limit: int = 30,
    base_url: str = "https://www.threads.com",
    log=None,
    retries: int = 3,
) -> list[dict[str, Any]]:
    """Open Threads search, scroll, extract cards. Retry with backoff on failure."""
    url = build_search_url(base_url, query, sort)
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            if log:
                log.info(f"Opening search (attempt {attempt}/{retries}): {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_timeout(2500)

            title = (await page.title() or "").lower()
            if "log in" in title or "login" in (page.url or "").lower():
                if log:
                    log.warning("Possible login wall on search page")

            collected: dict[str, dict] = {}
            stagnant = 0
            for step in range(max(1, max_pages)):
                batch = await page.evaluate(EXTRACT_POSTS_JS, per_page_limit)
                before = len(collected)
                for item in batch or []:
                    pid = post_id(item.get("url") or "")
                    if not pid:
                        continue
                    old = collected.get(pid)
                    if old is None or len(item.get("text") or "") > len(old.get("text") or ""):
                        collected[pid] = item
                if log:
                    log.info(f"Scroll {step + 1}/{max_pages}: unique={len(collected)}")
                if len(collected) == before:
                    stagnant += 1
                    if stagnant >= 2:
                        break
                else:
                    stagnant = 0
                await page.mouse.wheel(0, 1600)
                await page.wait_for_timeout(1100 + attempt * 100)

            return list(collected.values())
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Search attempt {attempt} failed: {type(exc).__name__}: {exc}")
            await asyncio.sleep(min(8, 1.5 * attempt))
    if last_err:
        raise last_err
    return []


async def enrich_post_detail(
    page,
    post_url: str,
    *,
    log=None,
    retries: int = 2,
) -> dict[str, Any]:
    """Open a single post and extract engagement, profile, media."""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            await page.goto(post_url, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(2000)
            try:
                for label in ("more", "see more", "читати далі", "більше", "ещё", "подробнее"):
                    btn = page.get_by_role("button", name=re.compile(rf"^{label}$", re.I))
                    if await btn.count():
                        await btn.first.click(timeout=1200)
                        await page.wait_for_timeout(300)
                        break
            except Exception:
                pass
            data = await page.evaluate(EXTRACT_DETAIL_JS)
            if not isinstance(data, dict):
                data = {}
            has_meaningful_data = any(
                data.get(k) not in (None, "", [])
                for k in ("text", "displayName", "avatarUrl", "likesCount", "repliesCount", "repostsCount", "quotesCount", "mediaUrls")
            )
            data["detailEnriched"] = bool(has_meaningful_data)
            return data
        except Exception as exc:
            last_err = exc
            if log:
                log.warning(f"Detail attempt {attempt} for {post_url}: {type(exc).__name__}")
            await asyncio.sleep(min(6, 1.2 * attempt))
    if log and last_err:
        log.warning(f"Detail enrichment failed: {last_err}")
    return {"detailEnriched": False}


def merge_card_and_detail(card: dict[str, Any], detail: dict[str, Any]) -> dict[str, Any]:
    out = dict(card)
    if not detail:
        return out
    if detail.get("text") and len(detail.get("text") or "") > len(out.get("text") or ""):
        out["text"] = detail["text"]
    if detail.get("timestamp") and not out.get("timestamp"):
        out["timestamp"] = detail["timestamp"]
    if detail.get("username"):
        out["author"] = detail["username"]
        out["username"] = detail["username"]
    for k in (
        "displayName", "avatarUrl", "isVerified",
        "likesCount", "repliesCount", "repostsCount", "quotesCount",
        "extractionDiagnostics",
    ):
        if detail.get(k) is not None:
            out[k] = detail[k]
    avatar = detail.get("avatarUrl") or out.get("avatarUrl")
    media = clean_media_urls(list(out.get("mediaUrls") or []) + list(detail.get("mediaUrls") or []), avatar)
    out["mediaUrls"] = media
    out["displayName"] = (clean_display_name(detail.get("displayName"), out.get("author") or out.get("username"))
                          or clean_display_name(card.get("displayName"), out.get("author") or out.get("username")))
    out["detailEnriched"] = bool(detail.get("detailEnriched"))
    return out

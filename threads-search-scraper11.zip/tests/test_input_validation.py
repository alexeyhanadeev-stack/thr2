import unittest
import json
from unittest.mock import AsyncMock, patch
from pathlib import Path
from src.main import validate_input, enrich_profile_fallback
from src.threads_source import (clean_post_text, clean_display_name, clean_media_urls, normalize_record, data_completeness, merge_card_and_detail, passes_filters)

class InputValidationTests(unittest.TestCase):

    def test_all_input_properties_have_descriptions(self):
        schema_path = Path(__file__).resolve().parents[1] / ".actor" / "input_schema.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        for name, prop in schema.get("properties", {}).items():
            with self.subTest(property=name):
                self.assertIsInstance(prop.get("description"), str)
                self.assertTrue(prop["description"].strip())

    def test_legacy_search_defaults_to_posts_search(self):
        self.assertEqual(validate_input({'searchQuery': 'hello'})[0], 'posts_search')
    def test_multiple_queries_deduplicate(self):
        self.assertEqual(validate_input({'searchQuery':'x','searchQueries':['x','y']})[1], ['x','y'])
    def test_modes_require_their_inputs(self):
        samples = [
            ({'mode':'user_search','userQuery':'creator'}, 'user_search'),
            ({'mode':'post_details','postUrl':'https://www.threads.com/@a/post/ABC'}, 'post_details'),
            ({'mode':'replies','postUrls':['https://www.threads.com/@a/post/ABC']}, 'replies'),
            ({'mode':'media','postUrls':['https://www.threads.com/@a/post/ABC']}, 'media'),
        ]
        for value, expected in samples:
            self.assertEqual(validate_input(value)[0], expected)

    def test_post_text_removes_threads_ui_but_keeps_body(self):
        raw = """valeriiabarcelona
2.6K views
11/04/26
Шукаю ugc для бренду косметики
Портфоліо обовʼязково
Log in with username instead
© 2026
Threads Terms
Privacy Policy
Consumer Health Privacy Policy
Cookies Policy
Report a problem"""
        self.assertEqual(
            clean_post_text(raw, "valeriiabarcelona"),
            "Шукаю ugc для бренду косметики\nПортфоліо обовʼязково",
        )

    def test_display_name_rejects_generic_title_and_username(self):
        self.assertIsNone(clean_display_name("Thread", "creator"))
        self.assertIsNone(clean_display_name("creator", "creator"))
        self.assertEqual(clean_display_name("Olena Creator", "creator"), "Olena Creator")
        self.assertEqual(clean_display_name("Marinka | content creator (@marina.hry) on Threads", "marina.hry"), "Marinka | content creator")
        self.assertEqual(clean_display_name("Vlada (@klettsko) on Threads", "klettsko"), "Vlada")
        self.assertIsNone(clean_display_name("smthngspcl11's profile picture", "smthngspcl11"))
        self.assertIsNone(clean_display_name("style.sense.ua's profile picture", "style.sense.ua"))

    def test_media_filter_drops_avatar_but_keeps_post_media(self):
        avatar = "https://scontent.cdninstagram.com/v/t51.82787-19/avatar.jpg?stp=dst-jpg_e0_s150x150"
        post_image = "https://scontent.cdninstagram.com/v/t51.82787-15/post-image.jpg"
        self.assertEqual(clean_media_urls([avatar, post_image], avatar), [post_image])

    def test_normalized_post_has_consistent_patch_schema(self):
        avatar = "https://cdn.example/avatar.jpg"
        post_image = "https://cdn.example/post.jpg"
        row = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123",
            "author": "creator",
            "displayName": "Thread",
            "avatarUrl": avatar,
            "text": "2.6K views\n11/04/26\nActual post text\nLog in with username instead\n© 2026",
            "mediaUrls": [avatar, post_image],
            "detailEnriched": True,
        }, "test")
        self.assertEqual(row["schemaVersion"], "1.2.6")
        self.assertIsNone(row["displayName"])
        self.assertEqual(row["text"], "Actual post text")
        self.assertEqual(row["mediaUrls"], [post_image])
        self.assertEqual(row["mediaType"], "image")


    def test_data_completeness_counts_known_empty_media_but_not_unknown_metrics(self):
        base = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123", "author": "creator",
            "text": "A real post", "timestamp": "2026-11-16T12:00:00Z",
            "avatarUrl": "https://cdn.example/avatar.jpg", "mediaUrls": [],
            "detailEnriched": True, "isVerified": False,
        }, "q")
        self.assertGreater(base["dataCompleteness"], 0.55)
        self.assertLess(base["dataCompleteness"], 0.9)
        with_metrics = dict(base, likesCount=12, repliesCount=3, repostsCount=1, quotesCount=0)
        self.assertGreater(data_completeness(with_metrics), base["dataCompleteness"])

    def test_merge_preserves_real_post_media_and_uses_valid_detail_name(self):
        avatar = "https://cdn.example/avatar.jpg"
        image = "https://cdn.example/t51.82787-15/post.jpg"
        merged = merge_card_and_detail(
            {"url":"https://www.threads.com/@creator/post/ABC123", "author":"creator", "mediaUrls":[image], "displayName":None},
            {"avatarUrl":avatar, "mediaUrls":[avatar, image], "displayName":"Olena K.", "detailEnriched":True}
        )
        self.assertEqual(merged["mediaUrls"], [image])
        self.assertEqual(merged["displayName"], "Olena K.")

    def test_rejects_invalid_mode_and_url(self):
        with self.assertRaises(ValueError): validate_input({'mode':'unknown'})
        with self.assertRaises(ValueError): validate_input({'mode':'media','postUrl':'https://example.com/post/1'})

    def test_unknown_engagement_does_not_pass_numeric_threshold_filters(self):
        row = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123", "author": "creator",
            "text": "A post", "timestamp": "2026-11-16T12:00:00Z", "detailEnriched": True,
            "mediaUrls": [],
        }, "q")
        self.assertFalse(passes_filters(row, {"minLikes": 1}))
        self.assertFalse(passes_filters(row, {"maxLikes": 100}))
        self.assertFalse(passes_filters(row, {"minReplies": 1}))
        self.assertFalse(passes_filters(row, {"minReposts": 1}))
        self.assertFalse(passes_filters(row, {"minQuotes": 1}))
        self.assertFalse(passes_filters(row, {"mediaTypes": ["image"]}))

    def test_known_engagement_values_are_applied_to_threshold_filters(self):
        row = normalize_record({
            "url": "https://www.threads.com/@creator/post/ABC123", "author": "creator",
            "text": "A post", "likesCount": 12, "repliesCount": 3,
            "repostsCount": 1, "quotesCount": 0, "detailEnriched": True,
        }, "q")
        self.assertTrue(passes_filters(row, {"minLikes": 10, "maxLikes": 20, "minReplies": 2, "minReposts": 1, "minQuotes": 0}))
        self.assertFalse(passes_filters(row, {"minLikes": 13}))

    def test_display_name_profile_picture_alt_can_be_valid_name_not_equal_to_handle(self):
        self.assertEqual(clean_display_name("SP9.fit's profile picture", "sp9.coop"), "SP9.fit")

    def test_extractor_contains_structured_state_and_lazy_media_fallbacks(self):
        source = (Path(__file__).resolve().parents[1] / "src" / "threads_source.py").read_text(encoding="utf-8")
        self.assertIn("JSON.parse(raw)", source)
        self.assertIn("data-lazy-src", source)
        self.assertIn("video.querySelectorAll('source[src]')", source)
        self.assertIn("like_count", source)
        self.assertIn("profile_pic_url", source)


class ProfileFallbackTests(unittest.IsolatedAsyncioTestCase):
    async def test_missing_display_name_uses_profile_page_fallback(self):
        detail = {"username": "style.sense.ua", "displayName": None,
                  "avatarUrl": "https://cdn.example/avatar.jpg", "detailEnriched": True}
        profile = {"displayName": "Style Sense", "avatarUrl": "https://cdn.example/avatar.jpg"}
        with patch("src.main.extract_profile", new=AsyncMock(return_value=profile)) as mocked:
            result = await enrich_profile_fallback(object(), detail,
                "https://www.threads.com/@style.sense.ua/post/De2FFyJjdtW")
        self.assertEqual(result["displayName"], "Style Sense")
        mocked.assert_awaited_once()

    async def test_valid_display_name_skips_extra_profile_request(self):
        detail = {"username": "creator", "displayName": "Creator Name",
                  "avatarUrl": "https://cdn.example/avatar.jpg", "detailEnriched": True}
        with patch("src.main.extract_profile", new=AsyncMock()) as mocked:
            result = await enrich_profile_fallback(object(), detail,
                "https://www.threads.com/@creator/post/ABC123")
        self.assertEqual(result["displayName"], "Creator Name")
        mocked.assert_not_awaited()

if __name__ == '__main__': unittest.main()
